/**
 * Tipos Compartidos del Sistema de Facturación
 * Todos los módulos deben importar desde aquí para mantener consistencia
 */

// ==================== CLIENT ====================
export interface PaymentRecord {
  id: string
  amount: number
  date: string  // ISO date string
  note?: string
  initialDebt?: number  // Deuda inicial al momento del abono
  remainingBalance?: number  // Saldo remaining después del abono
}

export interface Client {
  id: string
  name: string
  email?: string
  phone?: string
  nit?: string
  address?: string
  debtAmount?: number
  initialDebt?: number  // Deuda original/inicial (para evidencia)
  debtNote?: string  // Observación/nota sobre la deuda
  paymentHistory?: PaymentRecord[]  // Historial de abonos
}

// ==================== PRODUCT ====================
export interface Product {
  id: string
  name: string
  price: number
  stock: number
  category?: string
  costPrice?: number
  provider?: string
  image?: string  // Base64 image data con fondo transparente
}

// ==================== CART ITEM ====================
export interface CartItem {
  productId: string
  name: string
  qty: number
  price: number
  originalPrice?: number
  discount?: number
  discountType?: 'percentage' | 'fixed'
  reference?: string
}

// ==================== SALE ====================
export interface Sale {
  id: string
  client: string
  clientId?: string
  clientName?: string
  clientDocument?: string
  date: string
  total: number
  subtotal: number
  tax: number
  discount: number
  items: CartItem[]
  paymentMethod?: 'efectivo' | 'nequi' | 'daviplata' | 'breb' | 'transferencia' | 'tarjeta'
  timestamp?: string
  reference?: string
}

// ==================== PAYMENT ====================
export interface Payment {
  id?: string
  clientId: string
  amount: number
  date: string
  description?: string
  timestamp?: string
}

// ==================== USER PROFILE ====================
export interface UserProfile {
  name: string
  email: string
  phone?: string
  nit?: string
  address?: string
  photo?: string
}

// ==================== COMPANY CONFIG ====================
export interface CompanyConfig {
  companyName: string
  companyNIT: string
  taxRate: number
  applyTax: boolean
  currency: string
  invoiceFormat: 'ticket80' | 'ticket57' | 'carta'
  logo?: string
  invoiceFooter?: string  // Pie de página personalizado
  invoiceFontSize?: number // Tamaño de letra de la factura
  address?: string // Dirección de la empresa
  phone?: string // Teléfono de la empresa
  email?: string // Email de la empresa
  // Opciones de impresión
  autoPrint?: boolean // Imprimir automáticamente después de venta
  saveToFolder?: boolean // Guardar en carpeta Facturas
  printSilent?: boolean // Impresión silenciosa (sin diálogo)
  inventoryPassword?: string // Clave para ver valores del inventario
}

// ==================== PRINTER CONFIG ====================
export interface PrinterConfig {
  printerName?: string
  printerType?: 'network' | 'usb' | 'virtual'
  ipAddress?: string
  port?: number
  paperSize?: '80mm' | '57mm' | 'A4' | 'Letter' | 'Oficio'
  defaultCopies?: number
  autoPrintAfterSale?: boolean
  savePdfToFolder?: boolean
}

// ==================== INVOICE ====================
export interface Invoice {
  id: string
  saleId: string
  html: string
  format: 'ticket80' | 'ticket57' | 'carta'
  createdAt: string
}

// ==================== BACKUP DATA ====================
export interface BackupData {
  version: string
  createdAt: string
  clients: Client[]
  products: Product[]
  salesHistory: Sale[]
  userProfile: UserProfile
  companyConfig: CompanyConfig
}
