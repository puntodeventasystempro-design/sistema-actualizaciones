import React from 'react'
import { useReports } from './useReports'
import { Sale } from '../common/types'

export default function Reports() {
  const {
    totalRevenue,
    totalSales,
    averageTicket,
    totalDiscount,
    totalTax,
    dateFrom,
    setDateFrom,
    dateTo,
    setDateTo,
    clientFilter,
    setClientFilter,
    filteredSales,
    topProducts,
    topClients,
    salesByDay,
    exportToCSV,
    resetFilters,
  } = useReports()

  const formatCurrency = (amount: number) => {
    return `$ ${amount.toLocaleString('es-CO')}`
  }

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    return date.toLocaleDateString('es-CO', { 
      day: '2-digit', 
      month: '2-digit', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const hasFilters = dateFrom || dateTo || clientFilter

  return (
    <div className="module-body" style={{ overflowY: 'auto', maxHeight: 'calc(100vh - 100px)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <button 
          onClick={exportToCSV}
          style={{
            background: '#27ae60',
            color: 'white',
            border: 'none',
            padding: '10px 20px',
            borderRadius: '8px',
            cursor: 'pointer',
            fontSize: '14px'
          }}
        >
          Exportar CSV
        </button>
      </div>

      {/* Filters */}
      <div style={{ 
        background: 'var(--card-bg, #fff)', 
        padding: '20px', 
        borderRadius: '12px',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
        marginBottom: '20px'
      }}>
        <h3 style={{ marginTop: 0 }}>Filtros</h3>
        <div style={{ display: 'flex', gap: '15px', flexWrap: 'wrap', alignItems: 'flex-end' }}>
          <div>
            <label style={{ display: 'block', marginBottom: '5px', fontSize: '12px' }}>Desde</label>
            <input
              type="date"
              value={dateFrom}
              onChange={e => setDateFrom(e.target.value)}
              style={{ padding: '10px', borderRadius: '6px', border: '1px solid #ddd' }}
            />
          </div>
          <div>
            <label style={{ display: 'block', marginBottom: '5px', fontSize: '12px' }}>Hasta</label>
            <input
              type="date"
              value={dateTo}
              onChange={e => setDateTo(e.target.value)}
              style={{ padding: '10px', borderRadius: '6px', border: '1px solid #ddd' }}
            />
          </div>
          <div style={{ flex: 1, minWidth: '200px' }}>
            <label style={{ display: 'block', marginBottom: '5px', fontSize: '12px' }}>Cliente</label>
            <input
              type="text"
              placeholder="Buscar cliente..."
              value={clientFilter}
              onChange={e => setClientFilter(e.target.value)}
              style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #ddd' }}
            />
          </div>
          {hasFilters && (
            <button
              onClick={resetFilters}
              style={{
                padding: '10px 20px',
                borderRadius: '6px',
                border: '1px solid #ddd',
                background: '#f5f5f5',
                cursor: 'pointer'
              }}
            >
              Limpiar
            </button>
          )}
        </div>
      </div>

      {/* KPI Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '20px', marginBottom: '30px' }}>
        <div className="kpi-card" style={{ 
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', 
          color: 'white',
          padding: '20px',
          borderRadius: '12px',
          textAlign: 'center'
        }}>
          <p style={{ margin: '0 0 10px 0', fontSize: '14px', opacity: 0.9 }}>Ingresos Totales</p>
          <p style={{ margin: 0, fontSize: '24px', fontWeight: 'bold' }}>{formatCurrency(totalRevenue)}</p>
        </div>
        
        <div className="kpi-card" style={{ 
          background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)', 
          color: 'white',
          padding: '20px',
          borderRadius: '12px',
          textAlign: 'center'
        }}>
          <p style={{ margin: '0 0 10px 0', fontSize: '14px', opacity: 0.9 }}>Total Ventas</p>
          <p style={{ margin: 0, fontSize: '24px', fontWeight: 'bold' }}>{totalSales}</p>
        </div>
        
        <div className="kpi-card" style={{ 
          background: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)', 
          color: 'white',
          padding: '20px',
          borderRadius: '12px',
          textAlign: 'center'
        }}>
          <p style={{ margin: '0 0 10px 0', fontSize: '14px', opacity: 0.9 }}>Ticket Promedio</p>
          <p style={{ margin: 0, fontSize: '24px', fontWeight: 'bold' }}>{formatCurrency(averageTicket)}</p>
        </div>

        <div className="kpi-card" style={{ 
          background: 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)', 
          color: 'white',
          padding: '20px',
          borderRadius: '12px',
          textAlign: 'center'
        }}>
          <p style={{ margin: '0 0 10px 0', fontSize: '14px', opacity: 0.9 }}>Descuentos</p>
          <p style={{ margin: 0, fontSize: '24px', fontWeight: 'bold' }}>{formatCurrency(totalDiscount)}</p>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '30px' }}>
        {/* Top Products */}
        <div style={{ 
          background: 'var(--card-bg, #fff)', 
          padding: '20px', 
          borderRadius: '12px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <h3>Top 10 Productos</h3>
          {topProducts.length === 0 ? (
            <p style={{ color: '#666' }}>No hay datos</p>
          ) : (
            <ol style={{ paddingLeft: '20px' }}>
              {topProducts.map((item, i) => (
                <li key={item.id} style={{ marginBottom: '8px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span>{item.name}</span>
                    <span>
                      <strong>{item.qty}</strong> uds - {formatCurrency(item.revenue)}
                    </span>
                  </div>
                </li>
              ))}
            </ol>
          )}
        </div>

        {/* Top Clients */}
        <div style={{ 
          background: 'var(--card-bg, #fff)', 
          padding: '20px', 
          borderRadius: '12px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <h3>Top 10 Clientes</h3>
          {topClients.length === 0 ? (
            <p style={{ color: '#666' }}>No hay datos</p>
          ) : (
            <ol style={{ paddingLeft: '20px' }}>
              {topClients.map((item, i) => (
                <li key={item.id} style={{ marginBottom: '8px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span>{item.name}</span>
                    <span>
                      <strong>{item.count}</strong> ventas - {formatCurrency(item.revenue)}
                    </span>
                  </div>
                </li>
              ))}
            </ol>
          )}
        </div>
      </div>

      {/* Sales by Day Chart */}
      <div style={{ 
        background: 'var(--card-bg, #fff)', 
        padding: '20px', 
        borderRadius: '12px',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
        marginBottom: '20px'
      }}>
        <h3>Ventas por Dia</h3>
        {salesByDay.length === 0 ? (
          <p style={{ color: '#666' }}>No hay datos para el periodo seleccionado</p>
        ) : (
          <div>
            {salesByDay.map(day => (
              <div key={day.date} style={{ 
                display: 'flex', 
                alignItems: 'center', 
                padding: '10px 0',
                borderBottom: '1px solid #eee'
              }}>
                <span style={{ width: '100px', fontSize: '12px' }}>
                  {new Date(day.date).toLocaleDateString('es-CO', { day: '2-digit', month: '2-digit' })}
                </span>
                <div style={{ 
                  flex: 1, 
                  height: '24px', 
                  background: '#f0f0f0',
                  borderRadius: '4px',
                  overflow: 'hidden',
                  margin: '0 15px'
                }}>
                  <div style={{ 
                    width: `${Math.min((day.revenue / Math.max(...salesByDay.map(d => d.revenue))) * 100, 100)}%`,
                    height: '100%',
                    background: 'linear-gradient(90deg, #667eea, #764ba2)',
                    borderRadius: '4px'
                  }} />
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontWeight: 'bold' }}>{formatCurrency(day.revenue)}</div>
                  <div style={{ fontSize: '12px', color: '#666' }}>{day.count} ventas</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Sales Table */}
      <div style={{ 
        background: 'var(--card-bg, #fff)', 
        borderRadius: '12px',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
        overflow: 'hidden'
      }}>
        <div style={{ padding: '20px', borderBottom: '1px solid #eee' }}>
          <h3>Detalle de Ventas ({filteredSales.length})</h3>
        </div>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: 'var(--accent, #0066cc)', color: 'white' }}>
              <th style={{ padding: '12px', textAlign: 'left' }}>ID</th>
              <th style={{ padding: '12px', textAlign: 'left' }}>Fecha</th>
              <th style={{ padding: '12px', textAlign: 'left' }}>Cliente</th>
              <th style={{ padding: '12px', textAlign: 'right' }}>Items</th>
              <th style={{ padding: '12px', textAlign: 'right' }}>Subtotal</th>
              <th style={{ padding: '12px', textAlign: 'right' }}>Descuento</th>
              <th style={{ padding: '12px', textAlign: 'right' }}>IVA</th>
              <th style={{ padding: '12px', textAlign: 'right' }}>Total</th>
            </tr>
          </thead>
          <tbody>
            {filteredSales.length === 0 ? (
              <tr>
                <td colSpan={8} style={{ padding: '40px', textAlign: 'center', color: '#666' }}>
                  No hay ventas en el periodo seleccionado
                </td>
              </tr>
            ) : (
              filteredSales.map((sale: Sale) => (
                <tr key={sale.id} style={{ borderBottom: '1px solid #eee' }}>
                  <td style={{ padding: '12px', fontFamily: 'monospace', fontSize: '12px' }}>{sale.id}</td>
                  <td style={{ padding: '12px', fontSize: '12px' }}>{formatDate(sale.timestamp || sale.date)}</td>
                  <td style={{ padding: '12px' }}>{sale.client || '-'}</td>
                  <td style={{ padding: '12px', textAlign: 'center' }}>{sale.items.length}</td>
                  <td style={{ padding: '12px', textAlign: 'right' }}>{formatCurrency(sale.subtotal)}</td>
                  <td style={{ padding: '12px', textAlign: 'right', color: '#e74c3c' }}>
                    -{formatCurrency(sale.discount)}
                  </td>
                  <td style={{ padding: '12px', textAlign: 'right' }}>{formatCurrency(sale.tax)}</td>
                  <td style={{ padding: '12px', textAlign: 'right', fontWeight: 'bold' }}>
                    {formatCurrency(sale.total)}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
