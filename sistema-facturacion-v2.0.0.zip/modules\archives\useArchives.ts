import { useState, useEffect, useMemo } from 'react'
import { Sale, Invoice } from '../common/types'
import { saveToVirtualFile, loadFromVirtualFile, exportModuleData } from '../common/utils'
import { invoiceEventEmitter, salesEventEmitter } from '../common/eventEmitter'

const SALES_HISTORY_KEY = 'pos_sales_history'
const INVOICES_KEY = 'pos_invoices'
const MODULE_NAME = 'archives'

export function useArchives() {
  const [salesHistory, setSalesHistory] = useState<Sale[]>(() => {
    // Intentar cargar desde archivo virtual primero
    const fromFile = loadFromVirtualFile<Sale[]>(MODULE_NAME, 'salesHistory.json')
    if (fromFile && Array.isArray(fromFile)) {
      return fromFile
    }
    // Luego intentar localStorage
    try {
      const data = localStorage.getItem(SALES_HISTORY_KEY)
      return data ? JSON.parse(data) : []
    } catch {
      return []
    }
  })

  const [invoices, setInvoices] = useState<Invoice[]>(() => {
    // Siempre cargar desde localStorage
    try {
      const data = localStorage.getItem(INVOICES_KEY)
      if (data) {
        const parsed = JSON.parse(data)
        if (Array.isArray(parsed)) {
          return parsed
        }
      }
    } catch {}
    return []
  })

  // Sincronizar con localStorage al montar el componente
  useEffect(() => {
    console.log('[Archives] Hook mounted, iniciando sincronización')
    
    const syncInvoices = () => {
      try {
        console.log('[Archives] Sincronizando facturas...')
        const localInvoices = localStorage.getItem(INVOICES_KEY)
        console.log('[Archives] Facturas en localStorage:', localInvoices ? JSON.parse(localInvoices).length : 0)
        if (localInvoices) {
          const parsed = JSON.parse(localInvoices)
          // Siempre actualizar con lo que hay en localStorage
          console.log('[Archives] Actualizando facturas:', parsed.length)
          setInvoices(parsed)
        }
      } catch (e) {
        console.error('[Archives] Error sincronizando facturas:', e)
      }
    }

    const syncSales = () => {
      try {
        const localSales = localStorage.getItem(SALES_HISTORY_KEY)
        if (localSales) {
          const parsed = JSON.parse(localSales)
          setSalesHistory(prev => {
            if (parsed.length > prev.length) {
              return parsed
            }
            return prev
          })
        }
      } catch {}
    }

    // Sincronizar al montar
    syncInvoices()
    syncSales()

    // Escuchar eventos de nuevas facturas/ventas
    invoiceEventEmitter.on('invoice-added', syncInvoices)
    console.log('[Archives] Listener registrado para invoice-added')
    salesEventEmitter.on('sale-added', syncSales)

    // También verificar periódicamente (para detectar cambios en la misma pestaña)
    const interval = setInterval(() => {
      syncInvoices()
      syncSales()
    }, 2000)

    return () => {
      clearInterval(interval)
      invoiceEventEmitter.off('invoice-added', syncInvoices)
      salesEventEmitter.off('sale-added', syncSales)
    }
  }, [])

  // Persistir cambios en archivo virtual y localStorage
  useEffect(() => {
    saveToVirtualFile(MODULE_NAME, 'salesHistory.json', salesHistory)
    localStorage.setItem(SALES_HISTORY_KEY, JSON.stringify(salesHistory))
  }, [salesHistory])

  useEffect(() => {
    saveToVirtualFile(MODULE_NAME, 'invoices.json', invoices)
    localStorage.setItem(INVOICES_KEY, JSON.stringify(invoices))
  }, [invoices])

  // Escuchar cambios en localStorage para mantener sincronizado
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === INVOICES_KEY && e.newValue) {
        try {
          const newInvoices = JSON.parse(e.newValue)
          // Solo actualizar si hay nuevas facturas
          setInvoices(prev => {
            if (newInvoices.length > prev.length) {
              return newInvoices
            }
            return prev
          })
        } catch {}
      }
      if (e.key === SALES_HISTORY_KEY && e.newValue) {
        try {
          const newSales = JSON.parse(e.newValue)
          setSalesHistory(prev => {
            if (newSales.length > prev.length) {
              return newSales
            }
            return prev
          })
        } catch {}
      }
    }

    window.addEventListener('storage', handleStorageChange)
    return () => window.removeEventListener('storage', handleStorageChange)
  }, [])

  // ==================== CRUD ====================

  const addInvoice = (invoice: Invoice) => {
    setInvoices(prev => {
      // Verificar si ya existe
      if (prev.find(inv => inv.id === invoice.id)) {
        return prev
      }
      return [...prev, invoice]
    })
  }

  const getInvoice = (id: string) => {
    return invoices.find(inv => inv.id === id)
  }

  const deleteInvoice = (id: string) => {
    setInvoices(prev => prev.filter(inv => inv.id !== id))
  }

  // ==================== Búsqueda ====================

  const searchInvoices = (query: string) => {
    if (!query.trim()) return invoices
    
    const lowerQuery = query.toLowerCase()
    return invoices.filter(inv =>
      inv.id.toLowerCase().includes(lowerQuery) ||
      inv.saleId.toLowerCase().includes(lowerQuery)
    )
  }

  const getInvoicesByDateRange = (from: string, to: string) => {
    return invoices.filter(inv => {
      const invDate = new Date(inv.createdAt)
      return invDate >= new Date(from) && invDate <= new Date(to + 'T23:59:59')
    })
  }

  // ==================== Generación HTML ====================

  const generateInvoiceHTML = (sale: Sale, companyConfig: any, userProfile: any): string => {
    const formatCurrency = (amount: number) => {
      return `$ ${amount.toLocaleString('es-CO')}`
    }

    const formatDate = (dateStr: string) => {
      const date = new Date(dateStr)
      return date.toLocaleDateString('es-CO', {
        day: '2-digit',
        month: 'long',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      })
    }

    const itemsHTML = sale.items.map(item => `
      <tr>
        <td style="padding: 8px; border: 1px solid #ddd;">${item.name}</td>
        <td style="padding: 8px; border: 1px solid #ddd; text-align: center;">${item.qty}</td>
        <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${formatCurrency(item.price)}</td>
        <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${formatCurrency(item.price * item.qty)}</td>
      </tr>
    `).join('')

    return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Factura ${sale.id}</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 0; padding: 20px; color: #333; }
    .invoice { max-width: 800px; margin: 0 auto; border: 2px solid #333; padding: 20px; }
    .header { display: flex; justify-content: space-between; margin-bottom: 20px; border-bottom: 2px solid #333; padding-bottom: 10px; }
    .company-info h1 { margin: 0; color: #0066cc; }
    .invoice-info { text-align: right; }
    table { width: 100%; border-collapse: collapse; margin: 20px 0; }
    th { background: #0066cc; color: white; padding: 10px; }
    .totals { margin-top: 20px; text-align: right; }
    .total { font-size: 18px; font-weight: bold; margin: 5px 0; }
    .footer { margin-top: 30px; text-align: center; font-size: 12px; color: #666; border-top: 1px solid #ddd; padding-top: 10px; }
    @media print { body { padding: 0; } .invoice { border: none; } }
  </style>
</head>
<body>
  <div class="invoice">
    <div class="header">
      <div class="company-info">
        <h1>${companyConfig?.companyName || 'Mi Empresa'}</h1>
        <p>NIT: ${companyConfig?.companyNIT || 'N/A'}</p>
        <p>${userProfile?.address || ''}</p>
        <p>Tel: ${userProfile?.phone || ''}</p>
      </div>
      <div class="invoice-info">
        <h2>FACTURA</h2>
        <p><strong>No:</strong> ${sale.id}</p>
        <p><strong>Fecha:</strong> ${formatDate(sale.timestamp || sale.date)}</p>
        <p><strong>Vendedor:</strong> ${userProfile?.name || 'Admin'}</p>
      </div>
    </div>

    <div style="margin-bottom: 20px;">
      <strong>Cliente:</strong> ${sale.client || 'Consumidor Final'}
    </div>

    <table>
      <thead>
        <tr>
          <th>Producto</th>
          <th>Cantidad</th>
          <th>Precio Unitario</th>
          <th>Subtotal</th>
        </tr>
      </thead>
      <tbody>
        ${itemsHTML}
      </tbody>
    </table>

    <div class="totals">
      <p class="total">Subtotal: ${formatCurrency(sale.subtotal)}</p>
      ${sale.discount > 0 ? `<p class="total" style="color: #e74c3c;">Descuento: -${formatCurrency(sale.discount)}</p>` : ''}
      ${sale.tax > 0 ? `<p class="total">IVA (${companyConfig?.taxRate || 19}%): ${formatCurrency(sale.tax)}</p>` : ''}
      <p class="total" style="font-size: 24px; color: #0066cc;">TOTAL: ${formatCurrency(sale.total)}</p>
    </div>

    <div class="footer">
      <p>Gracias por su compra</p>
      <p>Esta factura fue generada el ${formatDate(new Date().toISOString())}</p>
    </div>
  </div>
</body>
</html>
    `
  }

  // ==================== Export ====================

  const downloadHTML = (sale: Sale, companyConfig: any, userProfile: any) => {
    const html = generateInvoiceHTML(sale, companyConfig, userProfile)
    const blob = new Blob([html], { type: 'text/html' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `factura_${sale.id}.html`
    link.click()
    URL.revokeObjectURL(url)
  }

  const downloadInvoiceHTML = (invoiceId: string, companyConfig: any, userProfile: any) => {
    const invoice = getInvoice(invoiceId)
    if (!invoice) return

    // Si la factura tiene HTML guardado en localStorage, descargarlo directamente
    if (invoice.html) {
      const blob = new Blob([invoice.html], { type: 'text/html' })
      const url = URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = `factura_${invoice.id}.html`
      link.click()
      URL.revokeObjectURL(url)
      return
    }

    // Si no hay HTML en localStorage, intentar obtenerlo del servidor
    fetch(`http://localhost:4000/invoice/${invoiceId}`)
      .then(res => res.json())
      .then(data => {
        if (data.ok && data.html) {
          const blob = new Blob([data.html], { type: 'text/html' })
          const url = URL.createObjectURL(blob)
          const link = document.createElement('a')
          link.href = url
          link.download = `factura_${invoiceId}.html`
          link.click()
          URL.revokeObjectURL(url)
        } else {
          throw new Error('Factura no encontrada en servidor')
        }
      })
      .catch(() => {
        // Si no se puede obtener del servidor, regenerar
        const sale = salesHistory.find(s => s.id === invoice.saleId)
        if (!sale) return
        downloadHTML(sale, companyConfig, userProfile)
      })
  }

  const printInvoiceHTML = (invoiceId: string, companyConfig: any, userProfile: any) => {
    const invoice = getInvoice(invoiceId)
    if (!invoice) {
      alert('Factura no encontrada')
      return
    }

    // Si la factura tiene HTML guardado en localStorage, usarlo directamente
    if (invoice.html) {
      const printWindow = window.open('', '_blank')
      if (printWindow) {
        printWindow.document.write(invoice.html)
        printWindow.document.close()
        printWindow.onload = () => {
          printWindow.print()
        }
      }
      return
    }

    // Si no hay HTML en localStorage, intentar obtenerlo del servidor
    fetch(`http://localhost:4000/invoice/${invoiceId}`)
      .then(res => res.json())
      .then(data => {
        if (data.ok && data.html) {
          const printWindow = window.open('', '_blank')
          if (printWindow) {
            printWindow.document.write(data.html)
            printWindow.document.close()
            printWindow.onload = () => {
              printWindow.print()
            }
          }
        } else {
          throw new Error('Factura no encontrada en servidor')
        }
      })
      .catch(() => {
        // Si no se puede obtener del servidor, regenerar
        const sale = salesHistory.find(s => s.id === invoice.saleId)
        if (!sale) {
          alert('No se encontró la venta asociada a esta factura')
          return
        }

        const html = generateInvoiceHTML(sale, companyConfig, userProfile)
        const printWindow = window.open('', '_blank')
        if (printWindow) {
          printWindow.document.write(html)
          printWindow.document.close()
          printWindow.onload = () => {
            printWindow.print()
          }
        }
      })
  }

  // ==================== Utilidades ====================

  const getInvoiceCount = useMemo(() => {
    return invoices.length
  }, [invoices])

  const getTotalInvoiced = useMemo(() => {
    return invoices.reduce((sum, inv) => {
      const sale = salesHistory.find(s => s.id === inv.saleId)
      return sum + (sale?.total || 0)
    }, 0)
  }, [invoices, salesHistory])

  // ==================== Export/Import a Archivo ====================

  const exportArchivesToFile = async () => {
    await exportModuleData(MODULE_NAME, 'archives.json')
  }

  const importArchivesFromFile = (file: File): Promise<boolean> => {
    return new Promise((resolve) => {
      const reader = new FileReader()
      reader.onload = (event) => {
        try {
          const data = JSON.parse(event.target?.result as string)
          if (data.salesHistory && Array.isArray(data.salesHistory)) {
            setSalesHistory(data.salesHistory)
          }
          if (data.invoices && Array.isArray(data.invoices)) {
            setInvoices(data.invoices)
          }
          resolve(true)
        } catch {
          resolve(false)
        }
      }
      reader.readAsText(file)
    })
  }

  return {
    // Estado
    salesHistory,
    setSalesHistory,
    invoices,
    setInvoices,
    // CRUD
    addInvoice,
    getInvoice,
    deleteInvoice,
    // Búsqueda
    searchInvoices,
    getInvoicesByDateRange,
    // Generación
    generateInvoiceHTML,
    downloadHTML,
    downloadInvoiceHTML,
    printInvoiceHTML,
    // Utilidades
    getInvoiceCount,
    getTotalInvoiced,
    // Export/Import a Archivo
    exportArchivesToFile,
    importArchivesFromFile,
  }
}
