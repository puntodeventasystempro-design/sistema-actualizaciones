import { useState, useEffect, useMemo } from 'react'
import { Sale } from '../common/types'

const SALES_HISTORY_KEY = 'pos_sales_history'
const CLIENTS_KEY = 'pos_clients'
const PRODUCTS_KEY = 'pos_products'

export function useReports() {
  const [salesHistory, setSalesHistory] = useState<Sale[]>(() => {
    try {
      const data = localStorage.getItem(SALES_HISTORY_KEY)
      return data ? JSON.parse(data) : []
    } catch {
      return []
    }
  })

  // Persistir cambios
  useEffect(() => {
    localStorage.setItem(SALES_HISTORY_KEY, JSON.stringify(salesHistory))
  }, [salesHistory])

  // ==================== Filtros ====================

  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')
  const [clientFilter, setClientFilter] = useState('')

  const filteredSales = useMemo(() => {
    return salesHistory.filter(sale => {
      const saleDate = new Date(sale.timestamp || sale.date)
      
      // Filtro por fecha
      if (dateFrom && saleDate < new Date(dateFrom)) return false
      if (dateTo && saleDate > new Date(dateTo + 'T23:59:59')) return false
      
      // Filtro por cliente
      if (clientFilter && sale.clientId !== clientFilter && !sale.client?.toLowerCase().includes(clientFilter.toLowerCase())) {
        return false
      }
      
      return true
    })
  }, [salesHistory, dateFrom, dateTo, clientFilter])

  // ==================== Análisis ====================

  const totalRevenue = useMemo(() => {
    return filteredSales.reduce((sum, sale) => sum + sale.total, 0)
  }, [filteredSales])

  const totalSales = useMemo(() => {
    return filteredSales.length
  }, [filteredSales])

  const averageTicket = useMemo(() => {
    if (totalSales === 0) return 0
    return totalRevenue / totalSales
  }, [totalRevenue, totalSales])

  const totalDiscount = useMemo(() => {
    return filteredSales.reduce((sum, sale) => sum + sale.discount, 0)
  }, [filteredSales])

  const totalTax = useMemo(() => {
    return filteredSales.reduce((sum, sale) => sum + sale.tax, 0)
  }, [filteredSales])

  // ==================== Top Products ====================

  const topProducts = useMemo(() => {
    const productSales: Record<string, { qty: number; revenue: number; name: string }> = {}
    
    filteredSales.forEach(sale => {
      sale.items.forEach(item => {
        if (!productSales[item.productId]) {
          productSales[item.productId] = { qty: 0, revenue: 0, name: item.name }
        }
        productSales[item.productId].qty += item.qty
        productSales[item.productId].revenue += item.price * item.qty
      })
    })

    return Object.entries(productSales)
      .sort((a, b) => b[1].revenue - a[1].revenue)
      .slice(0, 10)
      .map(([id, data]) => ({ id, ...data }))
  }, [filteredSales])

  // ==================== Top Clients ====================

  const topClients = useMemo(() => {
    const clientSales: Record<string, { count: number; revenue: number; name: string }> = {}
    
    filteredSales.forEach(sale => {
      const clientId = sale.clientId || 'anonimo'
      const clientName = sale.client || 'Cliente Anonimo'
      
      if (!clientSales[clientId]) {
        clientSales[clientId] = { count: 0, revenue: 0, name: clientName }
      }
      clientSales[clientId].count += 1
      clientSales[clientId].revenue += sale.total
    })

    return Object.entries(clientSales)
      .sort((a, b) => b[1].revenue - a[1].revenue)
      .slice(0, 10)
      .map(([id, data]) => ({ id, ...data }))
  }, [filteredSales])

  // ==================== Ventas por Día ====================

  const salesByDay = useMemo(() => {
    const days: Record<string, { count: number; revenue: number }> = {}
    
    filteredSales.forEach(sale => {
      const date = (sale.timestamp || sale.date).split('T')[0]
      if (!days[date]) {
        days[date] = { count: 0, revenue: 0 }
      }
      days[date].count += 1
      days[date].revenue += sale.total
    })

    return Object.entries(days)
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([date, data]) => ({ date, ...data }))
  }, [filteredSales])

  // ==================== Export ====================

  const exportToCSV = () => {
    const headers = ['ID', 'Fecha', 'Cliente', 'Subtotal', 'Descuento', 'IVA', 'Total']
    const rows = filteredSales.map(sale => [
      sale.id,
      sale.timestamp || sale.date,
      sale.client || '',
      sale.subtotal.toString(),
      sale.discount.toString(),
      sale.tax.toString(),
      sale.total.toString()
    ])
    
    const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `reporte_ventas_${new Date().toISOString().split('T')[0]}.csv`
    link.click()
    URL.revokeObjectURL(url)
  }

  const resetFilters = () => {
    setDateFrom('')
    setDateTo('')
    setClientFilter('')
  }

  return {
    // Estado
    salesHistory,
    setSalesHistory,
    // Filtros
    dateFrom,
    setDateFrom,
    dateTo,
    setDateTo,
    clientFilter,
    setClientFilter,
    filteredSales,
    // Análisis
    totalRevenue,
    totalSales,
    averageTicket,
    totalDiscount,
    totalTax,
    // Rankings
    topProducts,
    topClients,
    // Charts
    salesByDay,
    // Export
    exportToCSV,
    resetFilters,
  }
}
