import React, { useState } from 'react'
import { updateService } from '../../common/services/updateService'
import './UpdateSettings.css'

export default function UpdateSettings() {
  const [isChecking, setIsChecking] = useState(false)
  const [lastCheck, setLastCheck] = useState<Date | null>(() => {
    const stored = localStorage.getItem('pos_last_update_check')
    return stored ? new Date(stored) : null
  })
  const [checkResult, setCheckResult] = useState<string>('')
  const [updateAvailable, setUpdateAvailable] = useState(false)
  const [debugInfo, setDebugInfo] = useState<string>('')

  const handleCheckUpdates = async () => {
    setIsChecking(true)
    setCheckResult('')
    setDebugInfo('Iniciando verificación...\n')
    
    try {
      console.log('[UpdateSettings] Iniciando verificación manual')
      const updateInfo = await updateService.checkForUpdates()
      console.log('[UpdateSettings] Resultado:', updateInfo)
      
      const now = new Date()
      
      setLastCheck(now)
      localStorage.setItem('pos_last_update_check', now.toISOString())
      
      // Agregar información de depuración
      let debug = `Verificación completada:\n`
      debug += `- Versión actual: ${updateInfo.currentVersion}\n`
      debug += `- Versión disponible: ${updateInfo.version}\n`
      debug += `- Actualización disponible: ${updateInfo.available ? 'SÍ' : 'NO'}\n`
      debug += `- Características: ${updateInfo.features.length}\n`
      debug += `- URL de descarga: ${updateInfo.downloadUrl || 'No disponible'}\n`
      setDebugInfo(debug)
      
      if (updateInfo.available) {
        setUpdateAvailable(true)
        setCheckResult(`✅ Nueva versión disponible: v${updateInfo.version}`)
        
        // Guardar info de actualización
        localStorage.setItem('pos_update_available', JSON.stringify(updateInfo))
        
        // Forzar recarga del componente UpdateChecker
        window.dispatchEvent(new CustomEvent('update-available', { detail: updateInfo }))
      } else {
        setUpdateAvailable(false)
        setCheckResult('✓ Tu sistema está actualizado')
      }
      
      // Guardar en historial
      updateService.saveCheckHistory(updateInfo)
      
    } catch (error) {
      setCheckResult('❌ Error al verificar actualizaciones')
      setDebugInfo(`Error: ${error}\n${(error as Error).stack || ''}`)
      console.error('Error:', error)
    } finally {
      setIsChecking(false)
    }
  }

  const formatLastCheck = () => {
    if (!lastCheck) return 'Nunca'
    
    const now = new Date()
    const diff = now.getTime() - lastCheck.getTime()
    const minutes = Math.floor(diff / 60000)
    const hours = Math.floor(minutes / 60)
    const days = Math.floor(hours / 24)
    
    if (days > 0) return `Hace ${days} día${days > 1 ? 's' : ''}`
    if (hours > 0) return `Hace ${hours} hora${hours > 1 ? 's' : ''}`
    if (minutes > 0) return `Hace ${minutes} minuto${minutes > 1 ? 's' : ''}`
    return 'Hace un momento'
  }

  const getVersionInfo = () => {
    const currentVersion = '1.0.0' // Versión actual para detectar 2.0.0
    return currentVersion
  }

  return (
    <div className="update-settings-container">
      <div className="update-settings-header">
        <div className="update-icon-large">🔄</div>
        <h3>Actualizaciones del Sistema</h3>
        <p>Mantén tu sistema actualizado con las últimas mejoras</p>
      </div>

      <div className="update-info-grid">
        <div className="update-info-card">
          <div className="info-label">Versión Actual</div>
          <div className="info-value">v{getVersionInfo()}</div>
        </div>
        
        <div className="update-info-card">
          <div className="info-label">Última Verificación</div>
          <div className="info-value">{formatLastCheck()}</div>
        </div>
        
        <div className="update-info-card">
          <div className="info-label">Estado</div>
          <div className="info-value">
            {updateAvailable ? (
              <span className="status-badge status-update">Actualización disponible</span>
            ) : (
              <span className="status-badge status-ok">Actualizado</span>
            )}
          </div>
        </div>
      </div>

      <div className="update-actions-section">
        <button
          className="btn-check-updates"
          onClick={handleCheckUpdates}
          disabled={isChecking}
        >
          {isChecking ? (
            <>
              <span className="spinner"></span>
              Verificando...
            </>
          ) : (
            <>
              🔍 Buscar Actualizaciones
            </>
          )}
        </button>

        {checkResult && (
          <div className={`check-result ${updateAvailable ? 'result-update' : 'result-ok'}`}>
            {checkResult}
          </div>
        )}
        
        {debugInfo && (
          <div className="debug-info">
            <details>
              <summary>🔧 Información de Depuración</summary>
              <pre>{debugInfo}</pre>
            </details>
          </div>
        )}
      </div>

      <div className="update-features-section">
        <h4>Verificación Automática</h4>
        <div className="feature-item">
          <span className="feature-icon">⏰</span>
          <div className="feature-text">
            <strong>Cada 6 horas</strong>
            <p>El sistema verifica automáticamente si hay actualizaciones</p>
          </div>
        </div>
        
        <div className="feature-item">
          <span className="feature-icon">🔔</span>
          <div className="feature-text">
            <strong>Notificaciones</strong>
            <p>Recibirás una notificación cuando haya una nueva versión</p>
          </div>
        </div>
        
        <div className="feature-item">
          <span className="feature-icon">📦</span>
          <div className="feature-text">
            <strong>Descarga Directa</strong>
            <p>Descarga e instala actualizaciones con un solo clic</p>
          </div>
        </div>
      </div>

      <div className="update-history-section">
        <h4>Historial de Verificaciones</h4>
        <div className="history-list">
          {updateService.getCheckHistory().slice(-5).reverse().map((check, index) => (
            <div key={index} className="history-item">
              <span className="history-date">
                {new Date(check.date).toLocaleString('es-CO', {
                  day: '2-digit',
                  month: 'short',
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </span>
              <span className={`history-status ${check.available ? 'status-found' : 'status-none'}`}>
                {check.available ? `v${check.version} disponible` : 'Sin actualizaciones'}
              </span>
            </div>
          ))}
          {updateService.getCheckHistory().length === 0 && (
            <div className="history-empty">
              No hay historial de verificaciones
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
