import { useState, useEffect } from 'react'
import { useLocalStorageArray, STORAGE_KEYS } from '../common/hooks'
import type { Product, CartItem, Client, Sale } from '../common/types'
import { saveToVirtualFile, loadFromVirtualFile, exportModuleData } from '../common/utils'

const MODULE_NAME = 'sales'

// Productos iniciales - Vacíos para usar solo los de localStorage
const INITIAL_PRODUCTS: Product[] = []

// Cliente inicial
const INITIAL_CLIENTS: Client[] = [
  { id: 'c1', name: 'Cliente Genérico', email: 'cliente@example.com', nit: '800123456-7' },
]

export interface SalesTotals {
  subtotal: number
  discount: number
  tax: number
  total: number
}

export function useSales() {
  // Cargar productos desde localStorage (compartidos con useProducts)
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.PRODUCTS)
      if (stored) {
        const parsed = JSON.parse(stored)
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed
        }
      }
    } catch {}
    return INITIAL_PRODUCTS
  })
  
  // Sincronizar products cuando useProducts actualiza
  useEffect(() => {
    const handleProductsUpdate = (event: CustomEvent<Product[]>) => {
      const updatedProducts = event.detail
      if (updatedProducts && Array.isArray(updatedProducts)) {
        setProducts(updatedProducts)
      }
    }
    window.addEventListener('products-updated', handleProductsUpdate as EventListener)
    return () => window.removeEventListener('products-updated', handleProductsUpdate as EventListener)
  }, [])
  
  const [clients, setClients] = useLocalStorageArray<Client>(STORAGE_KEYS.CLIENTS, INITIAL_CLIENTS)
  const [cart, setCart] = useLocalStorageArray<CartItem>(STORAGE_KEYS.CART, [])
  const [salesHistory, setSalesHistory] = useLocalStorageArray<Sale>(STORAGE_KEYS.SALES_HISTORY, [])
  
  const [taxRate, setTaxRate] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.TAX_RATE)
      return saved ? parseFloat(saved) : 19
    } catch {
      return 19
    }
  })
  
  const [applyTax, setApplyTax] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.APPLY_TAX)
      return saved ? saved === 'true' : true
    } catch {
      return true
    }
  })

  // Persistir taxRate y applyTax
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TAX_RATE, String(taxRate))
  }, [taxRate])
  
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.APPLY_TAX, String(applyTax))
  }, [applyTax])

  // Escuchar actualizaciones del carrito desde App.tsx
  useEffect(() => {
    const handleCartUpdate = (event: CustomEvent<CartItem[]>) => {
      const newCart = event.detail
      if (newCart && Array.isArray(newCart)) {
        setCart(newCart)
      }
    }

    window.addEventListener('cart-updated', handleCartUpdate as EventListener)
    
    // Verificar localStorage periódicamente por si se actualiza desde otro lugar
    const checkStorage = () => {
      try {
        const storedCart = JSON.parse(localStorage.getItem(STORAGE_KEYS.CART) || '[]')
        if (JSON.stringify(storedCart) !== JSON.stringify(cart)) {
          setCart(storedCart)
        }
      } catch {
        // Ignorar errores
      }
    }

    const interval = setInterval(checkStorage, 1000)

    return () => {
      window.removeEventListener('cart-updated', handleCartUpdate as EventListener)
      clearInterval(interval)
    }
  }, [cart, setCart])

  // Métodos del carrito
  const addToCart = (product: Product, qty = 1): boolean => {
    const available = product.stock
    if (qty > available) return false
    
    // Usar el estado actual del carrito directamente desde localStorage
    // para evitar problemas de sincronización
    let currentCart: CartItem[] = []
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.CART)
      if (stored) currentCart = JSON.parse(stored)
    } catch {
      currentCart = []
    }
    
    const found = currentCart.find(p => p.productId === product.id)
    if (found) {
      // Incrementar la cantidad del producto existente
      const newQty = found.qty + qty
      const maxQty = Math.min(newQty, available)
      const updatedCart = currentCart.map(p => 
        p.productId === product.id ? { ...p, qty: maxQty } : p
      )
      setCart(updatedCart)
      console.log(`Producto ${product.name} actualizado. Nueva cantidad: ${maxQty}`)
      return true
    }
    
    const newCart = [...currentCart, { productId: product.id, name: product.name, qty, price: product.price, originalPrice: product.price }]
    setCart(newCart)
    console.log(`Producto ${product.name} agregado. Total en carrito: ${newCart.length}`)
    return true
  }

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(p => p.productId !== productId))
  }

  const setQty = (productId: string, qty: number) => {
    const prod = products.find(p => p.id === productId)
    if (!prod || qty <= 0) return
    const maxQty = Math.min(qty, prod.stock)
    setCart(prev => prev.map(p => p.productId === productId ? { ...p, qty: maxQty } : p))
  }

  const applyDiscount = (productId: string, amount: number, type: 'percentage' | 'fixed' = 'fixed') => {
    setCart(prev => prev.map(item => {
      if (item.productId !== productId) return item
      const originalPrice = item.originalPrice || item.price
      
      if (type === 'percentage') {
        const validAmount = Math.min(Math.max(amount, 0), 100)
        const discountedPrice = originalPrice * (1 - validAmount / 100)
        return { 
          ...item, 
          price: Math.round(discountedPrice * 100) / 100, 
          discount: validAmount, 
          discountType: type 
        }
      } else {
        const validAmount = Math.min(amount, originalPrice)
        const discountedPrice = Math.max(0, originalPrice - validAmount)
        return { 
          ...item, 
          price: Math.round(discountedPrice * 100) / 100,
          discount: validAmount, 
          discountType: type 
        }
      }
    }))
  }

  const clearCart = () => setCart([])

  const calculateTotal = (): SalesTotals => {
    // Leer configuración de empresa para IVA
    let applyTaxConfig = true
    try {
      const companyConfig = JSON.parse(localStorage.getItem('pos_company_config') || '{}')
      applyTaxConfig = companyConfig.applyTax !== false
    } catch {}
    
    // Calcular subtotal usando el precio original (sin descuento)
    const subtotal = cart.reduce((sum, item) => {
      const originalPrice = item.originalPrice ?? item.price
      return sum + (originalPrice * item.qty)
    }, 0)
    
    // Calcular descuento total
    const discount = cart.reduce((sum, item) => {
      if (item.discount == null) return sum
      
      if (item.discountType === 'percentage') {
        const original = item.originalPrice ?? item.price
        // Descuento porcentaje: original * qty * (discount / 100)
        const itemDiscount = original * item.qty * (item.discount / 100)
        return sum + itemDiscount
      } else {
        // Descuento fijo: discount * qty
        return sum + (item.discount * item.qty)
      }
    }, 0)
    
    // Calcular impuesto sobre el subtotal (antes de descuento)
    const tax = applyTaxConfig ? Math.round(subtotal * (taxRate / 100)) : 0
    
    // Total = subtotal + tax - discount
    const total = Math.round(subtotal + tax - discount)
    
    return { 
      subtotal: Math.round(subtotal), 
      discount: Math.round(discount), 
      tax, 
      total 
    }
  }

  const completeSale = (selectedClientId: string): Sale | null => {
    if (cart.length === 0) return null
    
    let clientName: string
    
    if (selectedClientId === 'GENERAL') {
      clientName = 'Cliente Común'
    } else {
      const client = clients.find(c => c.id === selectedClientId)
      if (!client) return null
      clientName = client.name
    }

    const total = calculateTotal()
    const sale: Sale = {
      id: `INV-${Date.now()}`,
      client: clientName,
      clientId: selectedClientId !== 'GENERAL' ? selectedClientId : undefined,
      date: new Date().toISOString(),
      subtotal: total.subtotal,
      tax: total.tax,
      discount: total.discount,
      total: total.total,
      items: [...cart],
      timestamp: new Date().toISOString(),
    }

    setSalesHistory(prev => [...prev, sale])
    
    // Generar factura HTML
    try {
      const invoice = {
        id: sale.id,
        client: sale.client,
        date: new Date().toLocaleDateString(),
        total: sale.total,
        items: sale.items.map(i => ({ name: i.name, qty: i.qty, price: i.price })),
      }
      
      const savedFormat = localStorage.getItem('invoiceFormat') as 'ticket80' | 'ticket57' | 'carta' || 'carta'
      generateInvoiceHTML(invoice, savedFormat)
    } catch (err) {
      console.error('Error generando factura:', err)
    }
    
    // Reducir stock - Leer productos actuales desde localStorage para asegurar sincronización
    try {
      const storedProducts = localStorage.getItem(STORAGE_KEYS.PRODUCTS)
      if (storedProducts) {
        const currentProducts: Product[] = JSON.parse(storedProducts)
        const updatedProducts = currentProducts.map(p => {
          const cartItem = cart.find(c => c.productId === p.id)
          return cartItem ? { ...p, stock: Math.max(0, p.stock - cartItem.qty) } : p
        })
        
        // Guardar en localStorage
        localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(updatedProducts))
        
        // Guardar en archivo virtual
        saveToVirtualFile('products', 'products.json', updatedProducts)
        
        // Actualizar estado local
        setProducts(updatedProducts)
        
        // Notificar a otros componentes (useProducts)
        window.dispatchEvent(new CustomEvent('products-updated', { detail: updatedProducts }))
        
        console.log('Stock actualizado correctamente:', updatedProducts)
      }
    } catch (e) {
      console.error('Error actualizando stock:', e)
    }

    clearCart()
    return sale
  }

  // Función para generar HTML de factura
  const generateInvoiceHTML = (invoice: { id: string; client: string; date: string; total: number; items: Array<{ name: string; qty: number; price: number }> }, format: 'ticket80' | 'ticket57' | 'carta' = 'carta') => {
    const itemsRows = invoice.items.map((item) => {
      const subtotal = Math.round(item.qty * parseFloat(String(item.price))).toLocaleString('es-CO', { minimumFractionDigits: 0, maximumFractionDigits: 0 })
      return `<tr>
                <td>${item.name}</td>
                <td style="text-align: center;">${item.qty}</td>
                <td style="text-align: right;">$${parseFloat(String(item.price)).toLocaleString('es-CO')}</td>
                <td style="text-align: right;">$${subtotal}</td>
              </tr>`
    }).join('')

    const cssStyles = format === 'carta' ? `
      * { margin: 0; padding: 0; box-sizing: border-box; }
      body { font-family: Arial, sans-serif; font-size: 12px; padding: 20px; background: white; }
      .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 20px; }
      .header h1 { margin: 0 0 10px 0; font-size: 28px; }
      .header p { margin: 5px 0; color: #666; font-size: 14px; }
      .info { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px; }
      .info-section { padding: 10px; background: #f5f5f5; border-radius: 4px; }
      .info-section strong { display: block; margin-bottom: 5px; color: #333; }
      .info-section p { margin: 0; color: #666; }
      table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
      table th { background: #333; color: white; padding: 12px; text-align: left; font-weight: bold; }
      table td { padding: 10px; border-bottom: 1px solid #ddd; }
      table tr:nth-child(even) { background: #f9f9f9; }
      .total-section { text-align: right; margin: 20px 0; }
      .total-section h4 { color: #333; font-size: 18px; margin: 0; }
      .footer { text-align: center; margin-top: 40px; color: #999; font-size: 12px; border-top: 1px solid #ddd; padding-top: 20px; }
    ` : `
      /* Formato Ticket (igual para 80mm y 57mm, solo cambia el ancho) */
      * { margin: 0; padding: 0; box-sizing: border-box; }
      body { 
        font-family: 'Courier New', monospace; 
        font-size: ${format === 'ticket80' ? '10px' : '8px'}; 
        width: ${format === 'ticket80' ? '80mm' : '57mm'}; 
        padding: 5px; 
        background: white; 
      }
      .header { text-align: center; margin-bottom: 10px; border-bottom: 1px dashed #333; padding-bottom: 5px; }
      .header h1 { margin: 0; font-size: ${format === 'ticket80' ? '14px' : '11px'}; font-weight: bold; }
      .header p { margin: 2px 0; font-size: ${format === 'ticket80' ? '9px' : '7px'}; }
      .info { margin-bottom: 10px; font-size: ${format === 'ticket80' ? '9px' : '7px'}; }
      table { width: 100%; border-collapse: collapse; margin-bottom: 10px; font-size: ${format === 'ticket80' ? '9px' : '7px'}; }
      table th { background: #333; color: white; padding: 3px; text-align: left; font-weight: bold; font-size: ${format === 'ticket80' ? '8px' : '6px'}; }
      table td { padding: 2px; border-bottom: 1px dashed #ccc; font-size: ${format === 'ticket80' ? '8px' : '6px'}; }
      .total-section { text-align: right; margin: 10px 0; font-size: ${format === 'ticket80' ? '10px' : '8px'}; font-weight: bold; }
      .footer { text-align: center; margin-top: 15px; font-size: ${format === 'ticket80' ? '8px' : '6px'}; border-top: 1px dashed #333; padding-top: 5px; }
    `

    const htmlContent = `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${invoice.id}</title>
  <style>${cssStyles}</style>
</head>
<body>
  <div class="header">
    <h1>FarmaPOS</h1>
    <p>NIT: 800123456-7</p>
    <p style="font-weight: bold;">FACTURA: ${invoice.id}</p>
  </div>
  
  <div class="info">
    <div class="info-section">
      <strong>CLIENTE:</strong>
      <p>${invoice.client}</p>
    </div>
    <div class="info-section">
      <strong>FECHA:</strong>
      <p>${invoice.date}</p>
    </div>
  </div>
  
  <table>
    <thead>
      <tr>
        <th>PRODUCTO</th>
        <th style="text-align: center;">CANTIDAD</th>
        <th style="text-align: right;">PRECIO</th>
        <th style="text-align: right;">SUBTOTAL</th>
      </tr>
    </thead>
    <tbody>
      ${itemsRows}
    </tbody>
  </table>
  
  <div class="total-section">
    <h4>TOTAL: $${invoice.total.toLocaleString('es-CO')}</h4>
  </div>
  
  <div class="footer">
    <p>Gracias por su compra</p>
    <p>Fecha de emisión: ${new Date().toLocaleDateString('es-CO')}</p>
  </div>
</body>
</html>`

    const pdfData = {
      id: invoice.id,
      client: invoice.client,
      date: invoice.date,
      total: invoice.total,
      html: htmlContent,
      timestamp: new Date().toISOString(),
    }
    
    let savedPDFs = JSON.parse(localStorage.getItem('savedPDFs') || '[]')
    savedPDFs.push(pdfData)
    localStorage.setItem('savedPDFs', JSON.stringify(savedPDFs))
    
    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.setAttribute('href', url)
    link.setAttribute('download', `${invoice.id}.html`)
    link.style.visibility = 'hidden'
    document.body.appendChild(link)
    
    setTimeout(() => {
      link.click()
      document.body.removeChild(link)
      URL.revokeObjectURL(url)
    }, 100)
  }

  // ==================== Export/Import a Archivo ====================

  const exportSalesToFile = async () => {
    await exportModuleData(MODULE_NAME, 'sales.json')
  }

  const importSalesFromFile = (file: File): Promise<boolean> => {
    return new Promise((resolve) => {
      const reader = new FileReader()
      reader.onload = (event) => {
        try {
          const data = JSON.parse(event.target?.result as string)
          if (Array.isArray(data)) {
            setSalesHistory(data)
            resolve(true)
          } else {
            resolve(false)
          }
        } catch {
          resolve(false)
        }
      }
      reader.readAsText(file)
    })
  }

  return {
    products,
    setProducts,
    clients,
    setClients,
    cart,
    salesHistory,
    addToCart,
    removeFromCart,
    setQty,
    applyDiscount,
    clearCart,
    calculateTotal,
    completeSale,
    taxRate,
    setTaxRate,
    applyTax,
    setApplyTax,
    // Export/Import a Archivo
    exportSalesToFile,
    importSalesFromFile,
  }
}
