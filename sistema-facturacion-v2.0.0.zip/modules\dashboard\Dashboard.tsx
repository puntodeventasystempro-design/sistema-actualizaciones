import React from 'react'
import { useDashboard } from './useDashboard'
import { formatCurrency } from '../common/utils/formatters'

export default function Dashboard() {
  const {
    totalRevenue,
    transactionCount,
    averageTicket,
    criticalStockProducts,
    warningStockProducts,
    trendingProducts,
    recentSales,
    salesByDay,
  } = useDashboard()

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    return date.toLocaleDateString('es-CO', { day: '2-digit', month: '2-digit', year: 'numeric' })
  }

  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr)
    return date.toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' })
  }

  return (
    <div className="dashboard-container" style={{ 
      padding: '24px', 
      height: '100%', 
      overflowY: 'auto',
      background: 'var(--bg-primary)'
    }}>
      {/* Header con saludo */}
      <div style={{ marginBottom: '32px' }}>
        <h1 style={{ 
          fontSize: '2rem', 
          fontWeight: '700', 
          color: 'var(--text-primary)',
          margin: '0 0 8px 0'
        }}>
          Panel de Control
        </h1>
        <p style={{ 
          color: 'var(--text-secondary)', 
          fontSize: '0.95rem',
          margin: 0
        }}>
          Resumen general de tu negocio
        </p>
      </div>

      {/* KPI Cards - Mejorados */}
      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
        gap: '20px', 
        marginBottom: '32px'
      }}>
        {/* Ingresos Totales */}
        <div style={{ 
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', 
          color: 'white',
          padding: '24px',
          borderRadius: '16px',
          boxShadow: '0 8px 24px rgba(102, 126, 234, 0.25)',
          position: 'relative',
          overflow: 'hidden'
        }}>
          <div style={{ position: 'relative', zIndex: 1 }}>
            <div style={{ 
              fontSize: '2.5rem', 
              marginBottom: '8px',
              opacity: 0.9
            }}>💰</div>
            <h3 style={{ 
              fontSize: '0.875rem', 
              fontWeight: '500',
              opacity: 0.9,
              margin: '0 0 8px 0',
              textTransform: 'uppercase',
              letterSpacing: '0.5px'
            }}>
              Ingresos Totales
            </h3>
            <p style={{ 
              fontSize: '2rem', 
              fontWeight: '700', 
              margin: 0,
              lineHeight: 1.2
            }}>
              {formatCurrency(totalRevenue)}
            </p>
          </div>
          <div style={{
            position: 'absolute',
            right: '-20px',
            bottom: '-20px',
            fontSize: '8rem',
            opacity: 0.1
          }}>💰</div>
        </div>
        
        {/* Transacciones */}
        <div style={{ 
          background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)', 
          color: 'white',
          padding: '24px',
          borderRadius: '16px',
          boxShadow: '0 8px 24px rgba(245, 87, 108, 0.25)',
          position: 'relative',
          overflow: 'hidden'
        }}>
          <div style={{ position: 'relative', zIndex: 1 }}>
            <div style={{ 
              fontSize: '2.5rem', 
              marginBottom: '8px',
              opacity: 0.9
            }}>📊</div>
            <h3 style={{ 
              fontSize: '0.875rem', 
              fontWeight: '500',
              opacity: 0.9,
              margin: '0 0 8px 0',
              textTransform: 'uppercase',
              letterSpacing: '0.5px'
            }}>
              Transacciones
            </h3>
            <p style={{ 
              fontSize: '2rem', 
              fontWeight: '700', 
              margin: 0,
              lineHeight: 1.2
            }}>
              {transactionCount}
            </p>
          </div>
          <div style={{
            position: 'absolute',
            right: '-20px',
            bottom: '-20px',
            fontSize: '8rem',
            opacity: 0.1
          }}>📊</div>
        </div>
        
        {/* Ticket Promedio */}
        <div style={{ 
          background: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)', 
          color: 'white',
          padding: '24px',
          borderRadius: '16px',
          boxShadow: '0 8px 24px rgba(79, 172, 254, 0.25)',
          position: 'relative',
          overflow: 'hidden'
        }}>
          <div style={{ position: 'relative', zIndex: 1 }}>
            <div style={{ 
              fontSize: '2.5rem', 
              marginBottom: '8px',
              opacity: 0.9
            }}>🎯</div>
            <h3 style={{ 
              fontSize: '0.875rem', 
              fontWeight: '500',
              opacity: 0.9,
              margin: '0 0 8px 0',
              textTransform: 'uppercase',
              letterSpacing: '0.5px'
            }}>
              Ticket Promedio
            </h3>
            <p style={{ 
              fontSize: '2rem', 
              fontWeight: '700', 
              margin: 0,
              lineHeight: 1.2
            }}>
              {formatCurrency(averageTicket)}
            </p>
          </div>
          <div style={{
            position: 'absolute',
            right: '-20px',
            bottom: '-20px',
            fontSize: '8rem',
            opacity: 0.1
          }}>🎯</div>
        </div>
      </div>

      {/* Grid de secciones */}
      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', 
        gap: '20px',
        marginBottom: '20px'
      }}>
        {/* Stock Crítico */}
        <div style={{ 
          background: 'var(--card-bg)', 
          padding: '24px', 
          borderRadius: '16px',
          boxShadow: 'var(--shadow-md)',
          border: '1px solid var(--border-color)'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', marginBottom: '20px' }}>
            <span style={{ fontSize: '1.5rem', marginRight: '12px' }}>🚨</span>
            <h3 style={{ 
              margin: 0, 
              fontSize: '1.1rem', 
              fontWeight: '600',
              color: 'var(--text-primary)'
            }}>
              Stock Crítico
            </h3>
            {criticalStockProducts.length > 0 && (
              <span style={{
                marginLeft: 'auto',
                background: '#fee',
                color: '#e74c3c',
                padding: '4px 12px',
                borderRadius: '12px',
                fontSize: '0.75rem',
                fontWeight: '600'
              }}>
                {criticalStockProducts.length}
              </span>
            )}
          </div>
          {criticalStockProducts.length === 0 ? (
            <div style={{ 
              textAlign: 'center', 
              padding: '32px 0',
              color: 'var(--text-muted)'
            }}>
              <div style={{ fontSize: '3rem', marginBottom: '8px' }}>✅</div>
              <p style={{ margin: 0 }}>Todo en orden</p>
            </div>
          ) : (
            <div style={{ maxHeight: '200px', overflowY: 'auto' }}>
              {criticalStockProducts.map(product => (
                <div key={product.id} style={{ 
                  padding: '12px', 
                  borderRadius: '8px',
                  background: 'var(--bg-secondary)',
                  marginBottom: '8px',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}>
                  <span style={{ fontWeight: '500', color: 'var(--text-primary)' }}>
                    {product.name}
                  </span>
                  <span style={{ 
                    color: '#e74c3c', 
                    fontWeight: '700',
                    fontSize: '0.9rem'
                  }}>
                    {product.stock} unidades
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Stock Bajo */}
        <div style={{ 
          background: 'var(--card-bg)', 
          padding: '24px', 
          borderRadius: '16px',
          boxShadow: 'var(--shadow-md)',
          border: '1px solid var(--border-color)'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', marginBottom: '20px' }}>
            <span style={{ fontSize: '1.5rem', marginRight: '12px' }}>⚠️</span>
            <h3 style={{ 
              margin: 0, 
              fontSize: '1.1rem', 
              fontWeight: '600',
              color: 'var(--text-primary)'
            }}>
              Stock Bajo
            </h3>
            {warningStockProducts.length > 0 && (
              <span style={{
                marginLeft: 'auto',
                background: '#fff3cd',
                color: '#f39c12',
                padding: '4px 12px',
                borderRadius: '12px',
                fontSize: '0.75rem',
                fontWeight: '600'
              }}>
                {warningStockProducts.length}
              </span>
            )}
          </div>
          {warningStockProducts.length === 0 ? (
            <div style={{ 
              textAlign: 'center', 
              padding: '32px 0',
              color: 'var(--text-muted)'
            }}>
              <div style={{ fontSize: '3rem', marginBottom: '8px' }}>✅</div>
              <p style={{ margin: 0 }}>Todo en orden</p>
            </div>
          ) : (
            <div style={{ maxHeight: '200px', overflowY: 'auto' }}>
              {warningStockProducts.map(product => (
                <div key={product.id} style={{ 
                  padding: '12px', 
                  borderRadius: '8px',
                  background: 'var(--bg-secondary)',
                  marginBottom: '8px',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}>
                  <span style={{ fontWeight: '500', color: 'var(--text-primary)' }}>
                    {product.name}
                  </span>
                  <span style={{ 
                    color: '#f39c12', 
                    fontWeight: '700',
                    fontSize: '0.9rem'
                  }}>
                    {product.stock} unidades
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Productos Más Vendidos */}
        <div style={{ 
          background: 'var(--card-bg)', 
          padding: '24px', 
          borderRadius: '16px',
          boxShadow: 'var(--shadow-md)',
          border: '1px solid var(--border-color)'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', marginBottom: '20px' }}>
            <span style={{ fontSize: '1.5rem', marginRight: '12px' }}>🔥</span>
            <h3 style={{ 
              margin: 0, 
              fontSize: '1.1rem', 
              fontWeight: '600',
              color: 'var(--text-primary)'
            }}>
              Más Vendidos
            </h3>
          </div>
          {trendingProducts.length === 0 ? (
            <div style={{ 
              textAlign: 'center', 
              padding: '32px 0',
              color: 'var(--text-muted)'
            }}>
              <div style={{ fontSize: '3rem', marginBottom: '8px' }}>📦</div>
              <p style={{ margin: 0 }}>Sin ventas aún</p>
            </div>
          ) : (
            <div style={{ maxHeight: '200px', overflowY: 'auto' }}>
              {trendingProducts.map((item, index) => (
                <div key={item.productId} style={{ 
                  padding: '12px', 
                  borderRadius: '8px',
                  background: 'var(--bg-secondary)',
                  marginBottom: '8px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px'
                }}>
                  <div style={{
                    width: '32px',
                    height: '32px',
                    borderRadius: '50%',
                    background: index === 0 ? '#FFD700' : index === 1 ? '#C0C0C0' : index === 2 ? '#CD7F32' : 'var(--accent)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: 'white',
                    fontWeight: '700',
                    fontSize: '0.85rem',
                    flexShrink: 0
                  }}>
                    {index + 1}
                  </div>
                  <span style={{ 
                    flex: 1, 
                    fontWeight: '500',
                    color: 'var(--text-primary)'
                  }}>
                    {item.name}
                  </span>
                  <span style={{ 
                    fontWeight: '700',
                    color: 'var(--accent)',
                    fontSize: '0.9rem'
                  }}>
                    {item.count} ventas
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Ventas Últimos 7 Días */}
        <div style={{ 
          background: 'var(--card-bg)', 
          padding: '24px', 
          borderRadius: '16px',
          boxShadow: 'var(--shadow-md)',
          border: '1px solid var(--border-color)'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', marginBottom: '20px' }}>
            <span style={{ fontSize: '1.5rem', marginRight: '12px' }}>📈</span>
            <h3 style={{ 
              margin: 0, 
              fontSize: '1.1rem', 
              fontWeight: '600',
              color: 'var(--text-primary)'
            }}>
              Últimos 7 Días
            </h3>
          </div>
          <div style={{ maxHeight: '200px', overflowY: 'auto' }}>
            {salesByDay.map(day => (
              <div key={day.date} style={{ 
                marginBottom: '12px'
              }}>
                <div style={{ 
                  display: 'flex', 
                  justifyContent: 'space-between',
                  marginBottom: '6px',
                  fontSize: '0.85rem'
                }}>
                  <span style={{ color: 'var(--text-secondary)' }}>
                    {formatDate(day.date)}
                  </span>
                  <span style={{ 
                    fontWeight: '700',
                    color: 'var(--text-primary)'
                  }}>
                    {formatCurrency(day.amount)}
                  </span>
                </div>
                <div style={{ 
                  height: '8px', 
                  background: 'var(--bg-secondary)',
                  borderRadius: '4px',
                  overflow: 'hidden'
                }}>
                  <div style={{ 
                    width: `${Math.min((day.amount / Math.max(...salesByDay.map(d => d.amount))) * 100, 100)}%`,
                    height: '100%',
                    background: 'linear-gradient(90deg, #667eea, #764ba2)',
                    borderRadius: '4px',
                    transition: 'width 0.3s ease'
                  }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Transacciones Recientes - Tabla mejorada */}
      <div style={{ 
        background: 'var(--card-bg)', 
        padding: '24px', 
        borderRadius: '16px',
        boxShadow: 'var(--shadow-md)',
        border: '1px solid var(--border-color)'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '20px' }}>
          <span style={{ fontSize: '1.5rem', marginRight: '12px' }}>🧾</span>
          <h3 style={{ 
            margin: 0, 
            fontSize: '1.1rem', 
            fontWeight: '600',
            color: 'var(--text-primary)'
          }}>
            Transacciones Recientes
          </h3>
        </div>
        {recentSales.length === 0 ? (
          <div style={{ 
            textAlign: 'center', 
            padding: '48px 0',
            color: 'var(--text-muted)'
          }}>
            <div style={{ fontSize: '4rem', marginBottom: '12px' }}>📭</div>
            <p style={{ margin: 0, fontSize: '1.1rem' }}>No hay transacciones recientes</p>
          </div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ 
              width: '100%', 
              borderCollapse: 'separate',
              borderSpacing: '0 8px'
            }}>
              <thead>
                <tr>
                  <th style={{ 
                    padding: '12px 16px', 
                    textAlign: 'left',
                    color: 'var(--text-secondary)',
                    fontWeight: '600',
                    fontSize: '0.85rem',
                    textTransform: 'uppercase',
                    letterSpacing: '0.5px'
                  }}>ID</th>
                  <th style={{ 
                    padding: '12px 16px', 
                    textAlign: 'left',
                    color: 'var(--text-secondary)',
                    fontWeight: '600',
                    fontSize: '0.85rem',
                    textTransform: 'uppercase',
                    letterSpacing: '0.5px'
                  }}>Fecha</th>
                  <th style={{ 
                    padding: '12px 16px', 
                    textAlign: 'left',
                    color: 'var(--text-secondary)',
                    fontWeight: '600',
                    fontSize: '0.85rem',
                    textTransform: 'uppercase',
                    letterSpacing: '0.5px'
                  }}>Hora</th>
                  <th style={{ 
                    padding: '12px 16px', 
                    textAlign: 'left',
                    color: 'var(--text-secondary)',
                    fontWeight: '600',
                    fontSize: '0.85rem',
                    textTransform: 'uppercase',
                    letterSpacing: '0.5px'
                  }}>Cliente</th>
                  <th style={{ 
                    padding: '12px 16px', 
                    textAlign: 'right',
                    color: 'var(--text-secondary)',
                    fontWeight: '600',
                    fontSize: '0.85rem',
                    textTransform: 'uppercase',
                    letterSpacing: '0.5px'
                  }}>Total</th>
                </tr>
              </thead>
              <tbody>
                {recentSales.map(sale => (
                  <tr key={sale.id} style={{ 
                    background: 'var(--bg-secondary)',
                    transition: 'transform 0.2s ease, box-shadow 0.2s ease'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = 'translateY(-2px)'
                    e.currentTarget.style.boxShadow = 'var(--shadow-sm)'
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = 'translateY(0)'
                    e.currentTarget.style.boxShadow = 'none'
                  }}>
                    <td style={{ 
                      padding: '16px', 
                      borderRadius: '8px 0 0 8px',
                      fontWeight: '600',
                      color: 'var(--accent)',
                      fontSize: '0.9rem'
                    }}>
                      #{sale.id.slice(0, 8)}
                    </td>
                    <td style={{ 
                      padding: '16px',
                      color: 'var(--text-primary)'
                    }}>
                      {formatDate(sale.timestamp || sale.date)}
                    </td>
                    <td style={{ 
                      padding: '16px',
                      color: 'var(--text-secondary)',
                      fontSize: '0.9rem'
                    }}>
                      {formatTime(sale.timestamp || sale.date)}
                    </td>
                    <td style={{ 
                      padding: '16px',
                      color: 'var(--text-primary)'
                    }}>
                      {sale.client || 'Sin cliente'}
                    </td>
                    <td style={{ 
                      padding: '16px', 
                      textAlign: 'right', 
                      fontWeight: '700',
                      color: 'var(--success)',
                      borderRadius: '0 8px 8px 0',
                      fontSize: '1rem'
                    }}>
                      {formatCurrency(sale.total)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
