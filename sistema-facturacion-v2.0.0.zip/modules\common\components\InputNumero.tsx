import React, { useState, useEffect, useRef } from 'react'

interface InputNumeroProps {
  value: number | string
  onChange: (value: number | string) => void
  placeholder?: string
  required?: boolean
  min?: number
  max?: number
  style?: React.CSSProperties
  className?: string
  disabled?: boolean
  label?: string
  error?: string
  name?: string
  autoFocus?: boolean
}

/**
 * Componente InputNumero
 * 
 * Características:
 * - Formato automático con puntos de miles en TIEMPO REAL mientras se escribe
 * - Al hacer focus en un campo con valor "0", lo limpia automáticamente
 * - Elimina ceros innecesarios al inicio al digitar
 * - Maneja correctamente el valor como string para el input y number para el onChange
 */
export default function InputNumero({
  value,
  onChange,
  placeholder = '0',
  required = false,
  min,
  max,
  style,
  className,
  disabled = false,
  label,
  error,
  name,
  autoFocus = false
}: InputNumeroProps) {
  const [displayValue, setDisplayValue] = useState('')
  const [isFocused, setIsFocused] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)
  const lastFormattedRef = useRef<string>('')
  
  // Effect para autoFocus
  useEffect(() => {
    if (autoFocus && inputRef.current) {
      inputRef.current.focus()
    }
  }, [autoFocus])
  
  // Convertir valor a formato de visualización
  useEffect(() => {
    // Solo actualizar si no está en foco (evitar conflicto mientras escribe)
    if (!isFocused) {
      if (value === 0 || value === '0' || value === '' || value === null || value === undefined) {
        setDisplayValue('')
        lastFormattedRef.current = ''
      } else {
        const numValue = typeof value === 'string' ? parseInt(value.replace(/\D/g, '')) || 0 : value
        const formatted = numValue.toLocaleString('es-CO')
        setDisplayValue(formatted)
        lastFormattedRef.current = formatted
      }
    }
  }, [value, isFocused])
  
  const formatNumberWithDots = (num: number | string): string => {
    if (num === '' || num === null || num === undefined) return ''
    const numValue = typeof num === 'string' ? parseInt(num.replace(/\D/g, '')) || 0 : num
    return numValue.toLocaleString('es-CO')
  }
  
  const handleFocus = () => {
    setIsFocused(true)
    // Si el valor es 0 o vacío, limpiar el campo
    if (value === 0 || value === '0' || value === '' || value === null || value === undefined) {
      setDisplayValue('')
      lastFormattedRef.current = ''
      onChange('')
    } else {
      // Mostrar el valor formateado (ya viene con puntos de miles)
      const numValue = typeof value === 'string' ? parseInt(value.replace(/\D/g, '')) || 0 : value
      const formatted = numValue.toLocaleString('es-CO')
      setDisplayValue(formatted)
      lastFormattedRef.current = formatted
    }
  }
  
  const handleBlur = () => {
    setIsFocused(false)
    // Al perder el foco, mantener el formato con puntos
    if (displayValue === '' || displayValue === null || displayValue === undefined) {
      setDisplayValue('')
      lastFormattedRef.current = ''
      onChange(0)
    } else {
      const numValue = parseInt(displayValue.replace(/\D/g, '')) || 0
      const formatted = numValue.toLocaleString('es-CO')
      setDisplayValue(formatted)
      lastFormattedRef.current = formatted
      onChange(numValue)
    }
  }
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputValue = e.target.value
    
    // Obtener la posición del cursor
    const cursorPosition = e.target.selectionStart || 0
    const oldLength = displayValue.length
    
    // Eliminar todo lo que no sean números
    const numbersOnly = inputValue.replace(/\D/g, '')
    
    // Si el usuario escribe un número después de un 0, eliminar el 0
    let cleanValue = numbersOnly
    if (cleanValue.startsWith('0') && cleanValue.length > 1) {
      cleanValue = cleanValue.replace(/^0+/, '')
    }
    
    if (cleanValue === '') {
      setDisplayValue('')
      lastFormattedRef.current = ''
      onChange(0)
      return
    }
    
    // Formatear con puntos de miles
    const formatted = formatNumberWithDots(cleanValue)
    
    // Calcular nueva posición del cursor
    // Si se añadió un punto, el cursor debe moverse +1
    const newLength = formatted.length
    const dotsAdded = (formatted.match(/\./g) || []).length
    const oldDots = (displayValue.match(/\./g) || []).length
    const dotsDiff = dotsAdded - oldDots
    
    // Ajustar posición del cursor
    let newCursorPos = cursorPosition
    if (cursorPosition === oldLength && newLength > oldLength) {
      newCursorPos = newLength
    } else if (dotsDiff > 0) {
      // El cursor está después de donde se añadió un punto
      newCursorPos = cursorPosition + dotsDiff
    }
    
    setDisplayValue(formatted)
    lastFormattedRef.current = formatted
    onChange(parseInt(cleanValue) || 0)
    
    // Restaurar posición del cursor
    setTimeout(() => {
      if (inputRef.current) {
        const len = inputRef.current.value.length
        const pos = Math.min(newCursorPos, len)
        inputRef.current.setSelectionRange(pos, pos)
      }
    }, 0)
  }
  
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    // Permitir teclas de navegación y control
    if (
      e.key === 'Backspace' ||
      e.key === 'Delete' ||
      e.key === 'ArrowLeft' ||
      e.key === 'ArrowRight' ||
      e.key === 'Tab' ||
      e.key === 'Home' ||
      e.key === 'End' ||
      e.ctrlKey ||
      e.metaKey
    ) {
      return
    }
    
    // Solo permitir números
    if (!/^\d$/.test(e.key)) {
      e.preventDefault()
    }
  }
  
  return (
    <div style={{ width: '100%' }}>
      {label && (
        <label style={{ 
          display: 'block', 
          marginBottom: '5px', 
          fontWeight: 'bold',
          fontSize: '14px'
        }}>
          {label}
          {required && <span style={{ color: '#e74c3c' }}> *</span>}
        </label>
      )}
      <input
        ref={inputRef}
        type="text"
        inputMode="numeric"
        value={displayValue}
        onChange={handleChange}
        onFocus={handleFocus}
        onBlur={handleBlur}
        onKeyDown={handleKeyDown}
        placeholder={placeholder}
        disabled={disabled}
        style={{
          width: '100%',
          padding: '10px',
          borderRadius: '6px',
          border: error ? '1px solid #e74c3c' : '1px solid #ddd',
          fontSize: '14px',
          textAlign: 'right',
          ...style
        }}
        className={className}
        name={name}
      />
      {error && (
        <span style={{ 
          color: '#e74c3c', 
          fontSize: '12px',
          marginTop: '4px',
          display: 'block'
        }}>
          {error}
        </span>
      )}
    </div>
  )
}
