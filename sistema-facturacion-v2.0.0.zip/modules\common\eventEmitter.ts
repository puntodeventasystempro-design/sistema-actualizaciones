// Event emitter simple para comunicar entre módulos
// Avoids circular imports between Sales and Archives

type Listener = () => void

class EventEmitterClass {
  private listeners: Record<string, Listener[]> = {}

  on(event: string, callback: Listener): void {
    if (!this.listeners[event]) {
      this.listeners[event] = []
    }
    this.listeners[event].push(callback)
  }

  off(event: string, callback: Listener): void {
    if (!this.listeners[event]) return
    this.listeners[event] = this.listeners[event].filter(cb => cb !== callback)
  }

  emit(event: string): void {
    console.log('[EventEmitter] Emitiendo evento:', event, 'Listeners:', this.listeners[event]?.length || 0)
    if (!this.listeners[event]) return
    this.listeners[event].forEach(cb => cb())
  }

  // Para debugging
  listenerCount(event: string): number {
    return this.listeners[event]?.length || 0
  }
}

// Instancias singleton
export const invoiceEventEmitter = new EventEmitterClass()
export const salesEventEmitter = new EventEmitterClass()
