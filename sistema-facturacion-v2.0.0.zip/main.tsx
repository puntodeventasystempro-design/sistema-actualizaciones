import React from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'

const mountPoint = document.getElementById('root')!

// Verificar que el mountPoint existe
if (!mountPoint) {
  throw new Error('No se encontró el elemento con id "root" en el DOM')
}

const root = createRoot(mountPoint)

// Manejo de errores global
const renderApp = (): void => {
  try {
    root.render(
      <React.StrictMode>
        <App />
      </React.StrictMode>
    )
  } catch (err: unknown) {
    console.error('Error crítico al renderizar la aplicación:', err)
    
    // Mostrar error en el DOM
    const errorMessage = err instanceof Error 
      ? err.message 
      : String(err)
    
    const errorStack = err instanceof Error && err.stack 
      ? err.stack 
      : ''

    mountPoint.innerHTML = `
      <div style="
        padding: 2rem;
        background: #1a1a2e;
        color: #e94560;
        min-height: 100vh;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        font-family: system-ui, -apple-system, sans-serif;
      ">
        <h1 style="margin-bottom: 1rem;">Error de la Aplicación</h1>
        <div style="
          background: #16213e;
          padding: 1.5rem;
          border-radius: 8px;
          max-width: 600px;
          width: 100%;
          overflow: auto;
        ">
          <p style="margin-bottom: 0.5rem;"><strong>Mensaje:</strong> ${errorMessage}</p>
          ${errorStack ? `<pre style="
            background: #0f0f23;
            padding: 1rem;
            border-radius: 4px;
            overflow-x: auto;
            font-size: 0.875rem;
            margin-top: 1rem;
          ">${errorStack}</pre>` : ''}
        </div>
        <button
          onclick="window.location.reload()"
          style="
            margin-top: 1.5rem;
            padding: 0.75rem 1.5rem;
            background: #e94560;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 1rem;
          "
        >
          Recargar Página
        </button>
      </div>
    `
  }
}

// Renderizar la aplicación
renderApp()

// Post-mount helper: centrar columnas cuyo TH tenga inline style text-align:right
function centerNumericColumns(): void {
  try {
    const tables = Array.from(document.querySelectorAll('table'))
    
    if (tables.length === 0) return
    
    tables.forEach(table => {
      const ths = Array.from(table.querySelectorAll('thead th'))
      
      if (ths.length === 0) return
      
      ths.forEach((th, idx) => {
        const styleAttr = (th as HTMLElement).getAttribute('style') || ''
        const textAlign = styleAttr.toLowerCase()
        
        if (textAlign.includes('right')) {
          // Centrar header
          ;(th as HTMLElement).style.textAlign = 'center'
          
          // Centrar celdas de la misma columna
          const cells = Array.from(table.querySelectorAll(`tbody tr td:nth-child(${idx + 1})`))
          cells.forEach(cell => {
            ;(cell as HTMLElement).style.textAlign = 'center'
          })
        }
      })
    })
  } catch (e) {
    console.warn('centerNumericColumns falló silenciosamente:', e)
  }
}

// Ejecutar después de un pequeño retraso para dejar que React renderice las tablas
setTimeout(centerNumericColumns, 200)

// Reportar éxito del mount
console.log('✅ Aplicación montada exitosamente')
