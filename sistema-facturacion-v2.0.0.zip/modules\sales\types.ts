/**
 * Tipos del Módulo Sales
 * Re-exporta desde common/types para mantener consistencia
 */
export * from '../common/types'

// Tipos específicos del módulo Sales que no están en common
export type PaymentMethod = 'efectivo' | 'nequi' | 'daviplata' | 'breb' | 'transferencia' | 'tarjeta'

export type InvoiceFormat = 'ticket80' | 'ticket57' | 'carta'

export interface SalesTotals {
  subtotal: number
  discount: number
  tax: number
  total: number
}
