import React, { useState, useEffect, useRef } from 'react'
import { useSales } from './useSales'
import type { CartItem, Product } from '../common/types'
import InputNumero from '../common/components/InputNumero'
import { invoiceEventEmitter } from '../common/eventEmitter'

// Estilos para scrollbars específicos del módulo de ventas
const scrollStyles = `
  .sales-container::-webkit-scrollbar {
    width: 6px;
  }
  .sales-container::-webkit-scrollbar-track {
    background: transparent;
  }
  .sales-container::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.2);
    border-radius: 3px;
  }
  .sales-container::-webkit-scrollbar-thumb:hover {
    background: rgba(255, 255, 255, 0.3);
  }
  .sales-container {
    scrollbar-width: thin;
    scrollbar-color: rgba(255, 255, 255, 0.2) transparent;
  }
`

// Inyectar estilos
if (typeof document !== 'undefined') {
  const styleEl = document.createElement('style')
  styleEl.textContent = scrollStyles + `
    select option {
      background-color: #ffffff !important;
      color: #000000 !important;
      background: #ffffff !important;
      background-image: none !important;
      -webkit-appearance: none !important;
      -moz-appearance: none !important;
      appearance: none !important;
    }
    select option:hover {
      background-color: #ffffff !important;
      color: #000000 !important;
      background: #ffffff !important;
      background-image: none !important;
    }
    select option:checked {
      background-color: #3b82f6 !important;
      color: #ffffff !important;
      background: #3b82f6 !important;
      background-image: none !important;
    }
    select option:focus {
      background-color: #ffffff !important;
      color: #000000 !important;
      background: #ffffff !important;
      background-image: none !important;
    }
    select option:active {
      background-color: #ffffff !important;
      color: #000000 !important;
      background: #ffffff !important;
      background-image: none !important;
    }
    select option:disabled {
      background-color: #ffffff !important;
      color: #000000 !important;
      background: #ffffff !important;
      background-image: none !important;
    }
    select option[selected] {
      background-color: #3b82f6 !important;
      color: #ffffff !important;
      background: #3b82f6 !important;
      background-image: none !important;
    }
    /* Ajustes generales para unificar tamaños en la barra de ventas (excluye el selector de cliente y botones de carrito) */
    .sales-container input[data-search-input],
    .sales-container .search-input,
    .sales-container #client-dropdown div,
    .sales-container [data-product-dropdown] div {
      font-size: 12px !important;
      padding: 6px 10px !important;
      border-radius: 6px !important;
    }
    
    /* Botones del toolbar - carrito y basura */
    .sales-container .cart-button-toolbar,
    .sales-container .trash-button-toolbar {
      padding: 6px 10px !important;
      font-size: 14px !important;
      border-radius: 4px !important;
      line-height: 1 !important;
      display: inline-flex !important;
      align-items: center !important;
      justify-content: center !important;
    }

    /* Reglas específicas para el selector de cliente: recuadro más visible */
    .sales-container #client-select-button {
      font-size: 16px !important;
      padding: 8px 12px !important;
      border: 2px solid var(--accent) !important;
      box-shadow: 0 6px 18px rgba(59,130,246,0.12) !important;
      border-radius: 6px !important;
      background: var(--card) !important;
      color: var(--accent) !important;
      font-weight: 700 !important;
      display: flex !important;
      justify-content: space-between !important;
      align-items: center !important;
      line-height: 1 !important;
      min-height: 0 !important;
      height: auto !important;
    }
    
    .sales-container #client-select-button svg {
      width: 16px !important;
      height: 16px !important;
      flex-shrink: 0 !important;
    }
    
    .sales-container #client-select-button kbd {
      line-height: 1 !important;
      padding: 2px 4px !important;
      font-size: 0.85rem !important;
    }

    /* Allow JS to control client-select text color via --client-select-text */
    .sales-container #client-select-button span {
      color: var(--client-select-text, var(--accent)) !important;
      font-weight: 700 !important;
    }

    /* Hacer que el input de búsqueda use el mismo tratamiento que el selector de cliente (recuadro azul y color de letra) */
    .sales-container .search-input,
    .sales-container input[data-search-input] {
      color: var(--client-select-text, var(--text-primary)) !important;
      /* Same blue border as client selector */
      border: 2px solid var(--accent) !important;
      /* Same shadow as client selector */
      box-shadow: 0 6px 18px rgba(59,130,246,0.12) !important;
      transition: none !important;
      background: var(--card) !important;
      /* Match client selector typography */
      font-size: 16px !important;
      font-weight: 700 !important;
      padding: 8px 12px !important;
      border-radius: 6px !important;
    }

    /* Botones del toolbar - FORZAR TAMAÑO PEQUEÑO */
    .sales-container button[data-toolbar-btn] {
      padding: 8px !important;
      font-size: 18px !important;
      border-radius: 4px !important;
      line-height: 1 !important;
      transform: none !important;
      transition: none !important;
      box-shadow: none !important;
    }
    
    .sales-container button[data-toolbar-btn]:hover {
      transform: none !important;
      box-shadow: none !important;
    }

    /* Ajustes específicos para el botón del carrito (reducir tamaño y padding) */
    .sales-container > div > div button:last-child {
      font-size: 14px !important;
      padding: 8px 12px !important;
      border-radius: 10px !important;
    }

    /* Regla específica para el botón Venta (verde) - sobrescribe la regla general de botones */
    .sales-container div > button[title="Cobrar venta actual"] {
      font-size: 48px !important;
      padding: 12px 24px !important;
      height: 60px !important;
      min-width: 200px !important;
      line-height: 1 !important;
      font-weight: 900 !important;
    }
  `
  if (!document.head.querySelector('style[data-sales-styles-v6]')) {
    styleEl.setAttribute('data-sales-styles-v6', 'true')
    document.head.appendChild(styleEl)
  }
}

export default function Sales({ onNavigateToProducts, onNavigateToClients }: { onNavigateToProducts?: () => void, onNavigateToClients?: () => void }) {
  const { products, setProducts, clients, setClients, cart, salesHistory, addToCart, removeFromCart, setQty, applyDiscount, clearCart, calculateTotal, completeSale, taxRate, setTaxRate, applyTax, setApplyTax } = useSales()
  
  const [search, setSearch] = useState('')
  const [selectedClient, setSelectedClient] = useState('')
  const [selectedClientName, setSelectedClientName] = useState<string | null>(null)
  const [showClientDropdown, setShowClientDropdown] = useState(false)
  const [invoiceFormat, setInvoiceFormat] = useState<'ticket80' | 'ticket57' | 'carta'>(() => {
    const saved = localStorage.getItem('invoiceFormat') as 'ticket80' | 'ticket57' | 'carta' | null
    return saved || 'carta'
  })
  const [showProductImages, setShowProductImages] = useState(() => {
    const viewMode = localStorage.getItem('products_view_mode')
    return viewMode !== 'list-no-image'
  })
  const [amountReceived, setAmountReceived] = useState('')
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [amountReceivedRaw, setAmountReceivedRaw] = useState('') // Valor sin formato para cálculos
  const [paymentMethod, setPaymentMethod] = useState<'efectivo' | 'nequi' | 'daviplata' | 'breb' | 'transferencia' | 'tarjeta'>('efectivo')
  const clientSelectRef = React.useRef<HTMLSelectElement | null>(null)
  const [showSelectClientModal, setShowSelectClientModal] = useState(false)
  const [modalTempClient, setModalTempClient] = useState<string>(clients[0]?.id || '')
  const [modalNewName, setModalNewName] = useState('')
  const [showReturnModal, setShowReturnModal] = useState(false)
  const [returnQuantities, setReturnQuantities] = useState<{ [key: string]: number }>({})
  const [selectedReturnItems, setSelectedReturnItems] = useState<Set<string>>(new Set())
  const [returnedItems, setReturnedItems] = useState<{ [key: string]: number }>(() => {
    try {
      const saved = localStorage.getItem('returnedItems');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const [modalNewEmail, setModalNewEmail] = useState('')
  const [modalNewPhone, setModalNewPhone] = useState('')
  const [modalNewNit, setModalNewNit] = useState('')
  const [modalNewAddress, setModalNewAddress] = useState('')
  // Mostrar un banner en UI cuando no hay cliente seleccionado (una sola vez)
  const [alertedNoClient, setAlertedNoClient] = useState(false)
  const [showNoClientBanner, setShowNoClientBanner] = useState(false)

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      // Cerrar dropdown de clientes si se hace clic fuera
      const clientDropdown = document.getElementById('client-dropdown');
      if (clientDropdown && !clientDropdown.contains(event.target as Node)) {
        setShowClientDropdown(false);
      }
      
      // Cerrar dropdown de productos si se hace clic fuera
      const productDropdowns = document.querySelectorAll('[data-product-dropdown]');
      productDropdowns.forEach(dropdown => {
        if (!dropdown.contains(event.target as Node)) {
          setSearchFocused(false);
        }
      });
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Escuchar cambios en la configuración de viewMode del inventario
  useEffect(() => {
    const handleStorageChange = () => {
      const viewMode = localStorage.getItem('products_view_mode')
      setShowProductImages(viewMode !== 'list-no-image')
    }

    window.addEventListener('storage', handleStorageChange)
    
    // También verificar periódicamente por si el cambio ocurre en la misma pestaña
    const interval = setInterval(handleStorageChange, 500)

    return () => {
      window.removeEventListener('storage', handleStorageChange)
      clearInterval(interval)
    }
  }, [])

  React.useEffect(() => {
    if (!selectedClient && !alertedNoClient && !showSelectClientModal) {
      setShowNoClientBanner(true)
      setAlertedNoClient(true)
    }
  }, [selectedClient, alertedNoClient, showSelectClientModal])
  const [showDiscountModal, setShowDiscountModal] = useState(false)
  const [selectedProductForDiscount, setSelectedProductForDiscount] = useState<string | null>(null)
  const [selectedProductId, setSelectedProductId] = React.useState<string | null>(null)
  const [hoveredProductId, setHoveredProductId] = useState<string | null>(null)
  const [discountMode, setDiscountMode] = useState<'fixed' | 'percentage'>('fixed')
  const [discountAmount, setDiscountAmount] = useState('')
  const [discountProduct, setDiscountProduct] = useState('')
  const [quickDiscountProductId, setQuickDiscountProductId] = useState<string | null>(null)
  const [quickDiscountValue, setQuickDiscountValue] = useState('')
  const [showDebtModal, setShowDebtModal] = useState(false)
  const [debtAmount, setDebtAmount] = useState('')
  const [debtReason, setDebtReason] = useState('')
  const [showActionMenu, setShowActionMenu] = useState(false)
  const [searchFocused, setSearchFocused] = useState(false)
  const [dropdownOpen, setDropdownOpen] = useState(false) // Control manual del dropdown por clic
  const [showProductsTable, setShowProductsTable] = useState(false)
  const [isLight, setIsLight] = useState(() => document.documentElement.classList.contains('light'))
  const searchInputRef = React.useRef<HTMLInputElement>(null)  
  const currencyFormatter = new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 })
  const formatCurrency = (n: number) => currencyFormatter.format(n)
  
  // Enfocar input de búsqueda al montar el componente
  React.useEffect(() => {
    searchInputRef.current?.focus()
  }, [])

  // Atajos de teclado con teclas de función
  React.useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      // Leer configuración de atajos desde localStorage
      const savedShortcuts = localStorage.getItem('pos_keyboard_shortcuts')
      const shortcuts = savedShortcuts ? JSON.parse(savedShortcuts) : {
        F1: 'toggle-products',
        F2: 'toggle-clients',
        F3: 'clear-cart',
        F4: 'process-payment',
        F5: 'goto-inventory',
        F6: 'goto-clients'
      }

      // Prevenir atajos si estamos en un input, textarea o modal (excepto F1 y F2)
      const target = event.target as HTMLElement
      const isInputField = target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT'
      
      // Mapear tecla presionada a acción configurada
      const keyPressed = event.key
      const action = shortcuts[keyPressed]
      
      if (!action || action === 'none') {
        // Si no hay acción configurada o es 'none', permitir comportamiento por defecto
        if (event.key === 'Escape') {
          // ESC siempre cierra modales o dropdowns
          if (showPaymentModal) {
            setShowPaymentModal(false)
          } else if (showClientDropdown) {
            setShowClientDropdown(false)
          } else if (dropdownOpen) {
            setDropdownOpen(false)
          } else if (search) {
            setSearch('')
            searchInputRef.current?.focus()
          }
        }
        return
      }

      // Ejecutar acción según configuración
      event.preventDefault()

      switch (action) {
        case 'toggle-products':
          setDropdownOpen(prev => !prev)
          searchInputRef.current?.focus()
          break

        case 'toggle-clients':
          setShowClientDropdown(prev => !prev)
          break

        case 'clear-cart':
          if (!isInputField && cart.length > 0) {
            const confirm = window.confirm('¿Deseas limpiar el carrito?')
            if (confirm) {
              clearCart()
            }
          }
          break

        case 'process-payment':
          if (!isInputField) {
            if (cart.length > 0 && selectedClient) {
              setShowPaymentModal(true)
            } else if (cart.length === 0) {
              alert('El carrito está vacío')
            } else if (!selectedClient) {
              alert('Selecciona un cliente primero')
            }
          }
          break

        case 'goto-inventory':
          if (!isInputField) {
            onNavigateToProducts?.()
          }
          break

        case 'goto-clients':
          if (!isInputField) {
            onNavigateToClients?.()
          }
          break
      }
    }

    document.addEventListener('keydown', handleKeyDown)
    return () => document.removeEventListener('keydown', handleKeyDown)
  }, [cart, selectedClient, showPaymentModal, showClientDropdown, dropdownOpen, search, clearCart, onNavigateToProducts, onNavigateToClients])

  // Cerrar dropdown de productos cuando se hace clic fuera
  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement
      // Verificar si el clic fue fuera del dropdown de productos
      const isDropdown = target.closest('[data-product-dropdown="true"]')
      const isSearchInput = target.closest('[data-search-input="true"]')
      
      if (!isDropdown && !isSearchInput) {
        setDropdownOpen(false)
      }
    }

    // Solo agregar el listener si el dropdown está abierto
    if (dropdownOpen) {
      document.addEventListener('click', handleClickOutside)
      return () => document.removeEventListener('click', handleClickOutside)
    }
  }, [dropdownOpen])

  // Actualizar estilos cuando el tema cambia
  React.useEffect(() => {
    const updateThemeStyles = () => {
      const isDarkMode = !document.documentElement.classList.contains('light');
      setIsLight(document.documentElement.classList.contains('light'));
      // Ensure CSS var for client-select text is set immediately
      document.documentElement.style.setProperty('--client-select-text', isDarkMode ? '#ffffff' : '#000000');
      // Also expose border and box-shadow variables so other controls (ej. search input) can use them
      document.documentElement.style.setProperty('--client-select-border', isDarkMode ? 'rgba(51,153,255,0.9)' : '#0066cc');
      document.documentElement.style.setProperty('--client-select-boxshadow', isDarkMode ? '0 8px 28px rgba(0,102,204,0.28)' : '0 8px 24px rgba(0,102,204,0.16)');
      
      // Asegurar que el botón tenga los estilos correctos inmediatamente según el tema
      const button = document.getElementById('client-select-button');
      if (button) {
        const buttonEl = button as HTMLElement;
        if (isDarkMode) {
          buttonEl.style.background = 'rgba(9,12,18,0.9)';
          buttonEl.style.border = '2px solid rgba(51,153,255,0.9)';
          buttonEl.style.boxShadow = '0 8px 28px rgba(0,102,204,0.28)';
        } else {
          buttonEl.style.background = 'var(--card-bg)';
          buttonEl.style.border = '2px solid #0066cc';
          buttonEl.style.boxShadow = '0 8px 24px rgba(0,102,204,0.16)';
        }
        // Color for text/icon is controlled by --client-select-text variable (see injected CSS)
      }
      
      // Aplicar estilo negro al dropdown en modo oscuro
      const dropdown = document.getElementById('client-dropdown');
      if (dropdown) {
        const dropdownEl = dropdown as HTMLElement;
        if (isDarkMode) {
          // Modo oscuro: fondo negro total
          dropdownEl.style.background = '#000000';
          dropdownEl.style.setProperty('background', '#000000', 'important');
          
          // Aplicar a todos los items del dropdown
          const items = dropdownEl.querySelectorAll('div');
          items.forEach(item => {
            const itemEl = item as HTMLElement;
            const isSelected = itemEl.getAttribute('data-selected') === 'true';
            if (isSelected) {
              itemEl.style.backgroundColor = '#1d4ed8';
              itemEl.style.color = '#ffffff';
            } else {
              itemEl.style.backgroundColor = '#000000';
              itemEl.style.color = '#ffffff';
            }
          });
        } else {
          // Modo claro: limpiar estilos forzados
          dropdownEl.style.removeProperty('background');
          
          const items = dropdownEl.querySelectorAll('div');
          items.forEach(item => {
            const itemEl = item as HTMLElement;
            const isSelected = itemEl.getAttribute('data-selected') === 'true';
            if (isSelected) {
              itemEl.style.backgroundColor = '#1d4ed8';
              itemEl.style.color = '#ffffff';
            } else {
              itemEl.style.removeProperty('background-color');
              itemEl.style.removeProperty('color');
            }
          });
        }
      }
    };
    
    updateThemeStyles();
    
    // Escuchar cambios de tema
    const observer = new MutationObserver(updateThemeStyles);
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['class']
    });
    
    return () => {
      observer.disconnect();
    };
  }, []);
  
  const getLowStockProducts = () => {
    return products.filter(p => p.stock < 5).sort((a, b) => a.stock - b.stock)
  }
  
  // Función para limpiar un número formateado
  const cleanNumber = (value: string): string => {
    return value.replace(/\D/g, '')
  }
  
  // Función para formatear número con puntos de mil
  const formatNumberWithDots = (value: number | string): string => {
    const num = typeof value === 'string' ? parseInt(value) || 0 : value
    return num.toLocaleString('es-CO')
  }

  // Función para abrir modal de descuento
  const openDiscountModal = (productId: string) => {
    setSelectedProductForDiscount(productId)
    setDiscountProduct(productId)
    setDiscountAmount('')
    setDiscountMode('fixed')
    setShowDiscountModal(true)
  }

  // Función para cerrar modal de descuento
  const closeDiscountModal = () => {
    setShowDiscountModal(false)
    setSelectedProductForDiscount(null)
    setDiscountProduct('')
    setDiscountAmount('')
    setDiscountMode('fixed')
  }

  const total = calculateTotal()
  const filteredProducts = React.useMemo(() => {
    const q = search.trim().toLowerCase()
    if (!q) return products
    return products.filter(p => p.name.toLowerCase().includes(q) || (p.category || '').toLowerCase().includes(q) || (p.id || '').toLowerCase().includes(q))
  }, [products, search])
  const visibleProducts = React.useMemo(() => filteredProducts.slice(0, 8), [filteredProducts])
  const [hoveredIndex, setHoveredIndex] = useState<number>(-1)

  // Scroll helper
  const scrollProductIntoView = (id: string) => {
    setTimeout(() => {
      const el = document.querySelector(`[data-product-id="${id}"]`)
      if (el && (el as HTMLElement).scrollIntoView) {
        (el as HTMLElement).scrollIntoView({ block: 'nearest', behavior: 'smooth' })
      }
    }, 0)
  }



  // Si hay productos seleccionados desde el módulo Productos, añadirlos al carrito al montar
  const loadedRef = useRef(false)
  React.useEffect(() => {
    if (loadedRef.current) return
    if (products.length === 0) return // Esperar a que los productos estén cargados
    
    loadedRef.current = true
    const loadSelectedProducts = () => {
      try {
        const raw = localStorage.getItem('pos_selected_products')
        if (raw) {
          const ids: string[] = JSON.parse(raw)
          console.log('Productos seleccionados desde Inventario:', ids)
          if (Array.isArray(ids) && ids.length > 0) {
            // Agregar productos con delay entre cada uno
            let index = 0
            const addNextProduct = () => {
              if (index >= ids.length) {
                console.log('Todos los productos procesados')
                localStorage.removeItem('pos_selected_products')
                return
              }
              
              const id = ids[index]
              const prod = products.find(p => p.id === id)
              
              if (prod) {
                console.log(`Agregando producto ${index + 1}/${ids.length}:`, prod.name)
                addToCart(prod, 1)
              } else {
                console.warn('Producto no encontrado:', id)
              }
              
              index++
              // Esperar 50ms antes de agregar el siguiente
              setTimeout(addNextProduct, 50)
            }
            
            // Iniciar la secuencia
            addNextProduct()
          } else {
            localStorage.removeItem('pos_selected_products')
          }
        }
      } catch (e) {
        console.error('Error al cargar productos seleccionados:', e)
        localStorage.removeItem('pos_selected_products')
      }
    }
    
    loadSelectedProducts()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [products])

  // Si hay cliente seleccionado desde el módulo Clientes, seleccionarlo al montar
  const clientLoadedRef = useRef<string | null>(null)
  
  // Helper para leer el cliente almacenado (puede ser id string o JSON stringificado)
  const readStoredSelectedClient = () => {
    try {
      const raw = localStorage.getItem('pos_selected_client')
      const rawName = localStorage.getItem('pos_selected_client_name')
      if (!raw) return null
      try {
        const parsed = JSON.parse(raw)
        if (parsed && typeof parsed === 'object' && parsed.id) {
          return { id: String(parsed.id), name: parsed.name || rawName || null }
        }
        if (typeof parsed === 'string') {
          return { id: parsed, name: rawName || null }
        }
      } catch (e) {
        // no JSON, tratar como id plano
        return { id: String(raw), name: rawName || null }
      }
      return null
    } catch (e) {
      return null
    }
  }

  // Efecto que se ejecuta cuando el componente se monta
  React.useEffect(() => {
    const stored = readStoredSelectedClient()
    if (!stored) return

    const { id: selectedClientId, name: selectedClientNameFromStorage } = stored
    console.log('Sales mounted - selectedClientId:', selectedClientId)
    console.log('Sales mounted - selectedClientNameFromStorage:', selectedClientNameFromStorage)
    console.log('Sales mounted - clients:', clients)

    // Si ya procesamos este cliente específico, no hacerlo de nuevo
    if (clientLoadedRef.current === selectedClientId) return

    // Buscar el cliente en el array de clientes
    const client = clients.find(c => c.id === selectedClientId)
    console.log('Sales mounted - client found:', client)

    if (client) {
      console.log('Setting client from array:', client.name)
      setSelectedClient(selectedClientId)
      setSelectedClientName(client.name)
      clientLoadedRef.current = selectedClientId
    } else if (selectedClientNameFromStorage) {
      console.log('Setting client from storage name:', selectedClientNameFromStorage)
      setSelectedClient(selectedClientId)
      setSelectedClientName(selectedClientNameFromStorage)
      clientLoadedRef.current = selectedClientId
    }

    localStorage.removeItem('pos_selected_client')
    localStorage.removeItem('pos_selected_client_name')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Listener para selección forzada de cliente desde otros módulos (SPA)
  React.useEffect(() => {
    const handler = (ev: Event) => {
      try {
        // @ts-ignore
        const detail = ev.detail
        if (!detail || !detail.id) return
        const id = String(detail.id)
        const name = detail.name || null
        // Aplicar selección inmediatamente
        setSelectedClient(id)
        setSelectedClientName(name)
        clientLoadedRef.current = id
      } catch (e) {}
    }

    window.addEventListener('pos_client_selected', handler as EventListener)
    return () => window.removeEventListener('pos_client_selected', handler as EventListener)
  }, [])
  
  // Efecto que se ejecuta cuando clients cambia para buscar el cliente si no se encontró antes
  React.useEffect(() => {
    const stored = readStoredSelectedClient()
    if (!stored || clients.length === 0) return

    const { id: selectedClientId } = stored
    console.log('Clients changed - selectedClientId:', selectedClientId)
    console.log('Clients changed - clients:', clients)

    // Si ya procesamos este cliente específico, no hacerlo de nuevo
    if (clientLoadedRef.current === selectedClientId) return

    clientLoadedRef.current = selectedClientId

    const client = clients.find(c => c.id === selectedClientId)
    console.log('Clients changed - client found:', client)

    if (client) {
      console.log('Setting client from array after change:', client.name)
      setSelectedClient(selectedClientId)
      setSelectedClientName(client.name)
    }

    localStorage.removeItem('pos_selected_client')
    localStorage.removeItem('pos_selected_client_name')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [clients])
  
  // Efecto adicional que se ejecuta cuando clients cambia
  React.useEffect(() => {
    const stored = readStoredSelectedClient()
    if (!stored || clients.length === 0) return

    const { id: selectedClientId } = stored
    if (clientLoadedRef.current === selectedClientId) return

    clientLoadedRef.current = selectedClientId

    const client = clients.find(c => c.id === selectedClientId)
    if (client) {
      setSelectedClient(selectedClientId)
      setSelectedClientName(client.name)
    }

    localStorage.removeItem('pos_selected_client')
    localStorage.removeItem('pos_selected_client_name')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [clients])

  // Persistencia de devoluciones
  React.useEffect(() => {
    try {
      localStorage.setItem('returnedItems', JSON.stringify(returnedItems));
    } catch (e) {
      console.error('Error guardando devoluciones:', e);
    }
  }, [returnedItems]);

  

  // Si otra parte de la app forzó la selección de cliente (ej. venta desde App.tsx), abrir modal obligatorio
  React.useEffect(() => {
    try {
      const f = localStorage.getItem('pos_force_select_client')
      if (f === '1') {
        setShowSelectClientModal(true)
        localStorage.removeItem('pos_force_select_client')
      }
    } catch (e) {}
  }, [])

  // Cargar cliente persistente (si el usuario dejó uno seleccionado en sesión previa)
  // SOLO se ejecuta si NO hay un cliente nuevo esperando desde el módulo Clientes
  React.useEffect(() => {
    try {
      // Solo cargar persistencia si no hay un cliente nuevo llegando
      const hasNewClient = localStorage.getItem('pos_selected_client')
      if (hasNewClient) {
        return // Saltar, el otro useEffect lo manejará
      }
      
      const rawPersist = localStorage.getItem('pos_selected_client_persist')
      if (rawPersist) {
        try {
          const parsed = JSON.parse(rawPersist)
          if (parsed && typeof parsed === 'object' && parsed.id) {
            setSelectedClient(parsed.id)
            setSelectedClientName(parsed.name || null)
          } else if (typeof parsed === 'string') {
            setSelectedClient(parsed)
            setSelectedClientName(null)
          }
        } catch (e) {
          // not JSON, treat as plain id
          const id = String(rawPersist)
          setSelectedClient(id)
          setSelectedClientName(null)
        }
      }
    } catch (e) {
      // ignore
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Persistir selección de cliente mientras el usuario la mantenga (se eliminará al completar la venta)
  React.useEffect(() => {
    try {
      if (selectedClient) {
        const payload = JSON.stringify({ id: selectedClient, name: selectedClientName })
        localStorage.setItem('pos_selected_client_persist', payload)
      } else {
        localStorage.removeItem('pos_selected_client_persist')
      }
    } catch (e) {
      // ignore
    }
  }, [selectedClient, selectedClientName])
  const handleAddToCart = (product: Product, qty = 1) => {
    if (!addToCart(product, qty)) {
      alert(`Solo hay ${product.stock} unidades disponibles`)
    }
  }

  const handleAmountReceivedChange = (value: string | number) => {
    const stringValue = String(value)
    // Eliminar todo lo que no sea números
    const numbersOnly = stringValue.replace(/\D/g, '')
    // Guardar valor sin formato para cálculos
    setAmountReceivedRaw(numbersOnly)
    // Formatear con puntos de mil para mostrar
    if (numbersOnly) {
      const formatted = formatNumberWithDots(parseInt(numbersOnly))
      setAmountReceived(formatted)
    } else {
      setAmountReceived('')
    }
  }

  const handleCompleteSale = () => {
    console.log('handleCompleteSale llamado')
    console.log('selectedClient:', selectedClient)
    console.log('cart.length:', cart.length)
    console.log('clients:', clients)
    
    if (!selectedClient) {
      alert('Selecciona un cliente')
      return
    }
    if (cart.length === 0) {
      alert('El carrito está vacío')
      return
    }
    // Abrir modal de pago en lugar de completar directamente
    console.log('Abriendo modal de pago...')
    setShowPaymentModal(true)
    // Limpiar montos recibidos al abrir modal
    setAmountReceived('')
    setAmountReceivedRaw('')
  }

  const handleProcessPayment = () => {
    console.log('=== PROCESANDO PAGO DIRECTO ===');
    
    // Guardar formato de factura en localStorage
    try {
      localStorage.setItem('invoiceFormat', invoiceFormat)
    } catch (e) {}
    
    const sale = completeSale(selectedClient)
    if (sale) {
      const total = calculateTotal().total
      const received = paymentMethod === 'efectivo' ? parseFloat(amountReceivedRaw || '0') : total
      const change = paymentMethod === 'efectivo' ? received - total : 0
      
      console.log('✅ Pago procesado:', { sale, total, received, change, paymentMethod });
      
      // Obtener nombre del método de pago
      const paymentMethodNames = {
        'efectivo': '💵 Efectivo',
        'nequi': '🅽️ Nequi',
        'daviplata': '🅰️ Daviplata',
        'breb': '🔵 BRE-B',
        'transferencia': '🏦 Transferencia Bancaria',
        'tarjeta': '💳 Tarjeta Débito/Crédito'
      }
      
      // Mostrar resumen del pago
      const formatName = invoiceFormat === 'ticket80' ? 'Ticket 80mm' : invoiceFormat === 'ticket57' ? 'Ticket 57mm' : 'Carta'
      const paymentName = paymentMethodNames[paymentMethod]
      
      // Solo mostrar cambio si es mayor a cero
      let changeText = ''
      if (change > 0) {
        changeText = `\nCambio: ${formatCurrency(change)}`
      }
      
      alert(`✅ Pago procesado:\n\nFactura: ${sale.id}\nTotal: ${formatCurrency(total)}\nRecibido: ${formatCurrency(received)}\nMétodo: ${paymentName}${changeText}\n\nFormato: ${formatName}`)
      
      try {
        // Reiniciar selector a opción por defecto
        setSelectedClient('')
        setSelectedClientName(null)
        // Eliminar cliente persistente de localStorage para la siguiente sesión
        try { localStorage.removeItem('pos_selected_client_persist') } catch (err) {}
        setAmountReceived('')
        setAmountReceivedRaw('')
        setPaymentMethod('efectivo') // Resetear a efectivo
        setShowPaymentModal(false)
      } catch (e) {}
    }
  }

  const handleApplyDiscount = () => {
    if (!discountProduct || !discountAmount) {
      alert('Completa los campos')
      return
    }
    const amount = parseFloat(discountAmount)
    if (isNaN(amount) || amount < 0) {
      alert('Cantidad inválida')
      return
    }
    
    // Validación adicional según el tipo de descuento
    if (discountMode === 'percentage') {
      if (amount > 100) {
        alert('❌ El porcentaje no puede ser mayor a 100%')
        return
      }
    } else {
      // Para descuento fijo, verificar contra el precio unitario
      const item = cart.find(i => i.productId === discountProduct)
      const originalPrice = item?.originalPrice || item?.price || 0
      
      if (amount > originalPrice) {
        alert(`❌ El descuento ($${amount.toLocaleString('es-CO')}) no puede superar el precio unitario ($${originalPrice.toLocaleString('es-CO')})`)
        return
      }
    }
    
    applyDiscount(discountProduct, amount, discountMode)
    setDiscountAmount('')
    setDiscountProduct('')
  }

  // Función para obtener el descuento de un producto
  const getProductDiscount = (productId: string, itemPrice: number, itemQty: number) => {
    const item = cart.find(item => item.productId === productId)
    if (!item || !item.discount) return 0
    
    if (item.discountType === 'percentage') {
      // Usar el precio original para calcular el descuento porcentual
      const originalPrice = item.originalPrice || itemPrice
      return (originalPrice * itemQty * item.discount) / 100
    } else {
      // Para descuento fijo, se aplica por cada unidad
      return item.discount * itemQty
    }
  }

  // Función para obtener el texto del descuento formateado
  const getDiscountText = (productId: string) => {
    const item = cart.find(item => item.productId === productId)
    if (!item || !item.discount) return ''
    
    if (item.discountType === 'percentage') {
      return `-${item.discount}%`
    } else {
      return `-${formatCurrency(item.discount)}`
    }
  }

  return (
    <div className="sales-container" style={{ position: 'fixed', top: '50px', left: '220px', right: '0', bottom: '20px', padding: '0px 22px 16px 22px', display: 'flex', flexDirection: 'column', background: 'var(--bg)', overflow: 'visible' }}>
      
      
      {/* Notificación simple cuando no hay cliente seleccionado - esquina superior derecha */}
      {!selectedClient && (
        <div style={{
          position: 'fixed',
          top: '80px',
          right: '20px',
          background: 'linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%)',
          color: '#78350f',
          padding: '8px 12px',
          borderRadius: '6px',
          border: '1px solid #f59e0b',
          boxShadow: '0 2px 8px rgba(245, 158, 11, 0.3)',
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          fontSize: '12px',
          fontWeight: '600',
          zIndex: 100001,
          boxSizing: 'border-box'
        }}>
          <span style={{ fontSize: '14px', flexShrink: 0 }}>⚠️</span>
          <span>Selecciona un cliente para continuar</span>
        </div>
      )}

       

      {/* Toolbar */}
        
      {/* SECCIÓN: Búsqueda de Productos y Cliente */}
        <div style={{ display: 'flex', gap: '12px', marginTop: '0px', marginBottom: '12px', flexWrap: 'wrap', alignItems: 'center' }}>
          {/* Búsqueda de Productos con Botón */}
          <div style={{ flex: 1, minWidth: '180px', position: 'relative', display: 'flex', gap: '8px', alignItems: 'center' }}>
            {/* Badge F1 fuera del input */}
            <kbd style={{
              background: 'transparent',
              color: 'var(--text-secondary)',
              padding: '2px 4px',
              fontSize: '0.85rem',
              fontWeight: '700',
              fontFamily: 'monospace',
              flexShrink: 0
            }}>
              F1
            </kbd>
            <div style={{ position: 'relative', flex: 1 }}>
            <input 
              ref={searchInputRef}
              type="text" 
              placeholder="Buscar producto" 
              value={search} 
              data-search-input="true"
              onClick={() => {
                // Abrir dropdown con clic siempre que haya productos
                if (filteredProducts.length > 0) {
                  setDropdownOpen(true)
                }
              }}
              onChange={e => {
                setSearch(e.target.value)
                // Abrir dropdown si hay productos filtrados
                if (filteredProducts.length > 0) {
                  setDropdownOpen(true)
                }
              }}
              onKeyDown={(e) => {
                const list = visibleProducts
                if (!list || list.length === 0) return
                if (e.key === 'ArrowDown') {
                  e.preventDefault()
                  const next = (hoveredIndex + 1) % list.length
                  setHoveredIndex(next)
                  setHoveredProductId(list[next].id)
                  scrollProductIntoView(list[next].id)
                } else if (e.key === 'ArrowUp') {
                  e.preventDefault()
                  const prev = (hoveredIndex - 1 + list.length) % list.length
                  setHoveredIndex(prev)
                  setHoveredProductId(list[prev].id)
                  scrollProductIntoView(list[prev].id)
                } else if (e.key === 'Enter') {
                  if (hoveredProductId) {
                    const prod = products.find(x => x.id === hoveredProductId)
                    if (prod) {
                      handleAddToCart(prod)
                      setSearch('')
                      setDropdownOpen(false)
                      setSelectedProductId(prod.id)
                      setTimeout(() => searchInputRef.current?.focus(), 0)
                    }
                  }
                } else if (e.key === 'Escape') {
                  setHoveredIndex(-1)
                  setHoveredProductId(null)
                  setDropdownOpen(false)
                }
              }}
              onKeyUp={() => {}}
              onFocus={() => {
                // Abrir dropdown si hay productos y hay texto escrito
                if (search.trim() !== '' && filteredProducts.length > 0) {
                  setDropdownOpen(true)
                }
              }}
              onBlur={() => {
                // No cerrar aquí, el useEffect se encarga de cerrar al hacer clic fuera
              }}

              className={`search-input ${searchFocused ? 'input-focused' : ''} ${(hoveredProductId || hoveredIndex >= 0) ? 'product-highlighted' : ''}`}

              style={{ 
                flex: 1, 
                padding: '8px 12px', 
                borderRadius: 6, 
                fontSize: 16,
                outline: 'none',
                color: 'inherit'
              }}

              onMouseOut={(e) => {
                // Quitar estilos inline para dejar que las variables CSS controlen color/borde/sombra
                e.currentTarget.style.removeProperty('color');
                e.currentTarget.style.removeProperty('borderColor');
                e.currentTarget.style.removeProperty('boxShadow');
                e.currentTarget.style.removeProperty('background');
              }}
              onMouseOver={(e) => {
                // No forzamos color aquí; usar la variable CSS para que cambie instantáneamente con el tema
                e.currentTarget.style.removeProperty('color');
              }}
            />
            </div>
            <button
              onClick={() => {
                if (onNavigateToProducts) {
                  onNavigateToProducts()
                }
              }}
              title="Productos"
              aria-label="Productos"
              style={{
                padding: '8px',
                background: 'transparent',
                color: 'inherit',
                border: 'none',
                borderRadius: 4,
                cursor: 'pointer',
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                width: 'auto',
                height: 'auto',
                lineHeight: 1,
                boxShadow: 'none'
              }}
            >
              <svg viewBox="0 0 24 24" width="32" height="32" aria-hidden="true">
                <g>
                  <rect x="2" y="6" width="16" height="10" rx="1.5" fill="#3b82f6" />
                  <path d="M20 8h1.5a1 1 0 0 1 .97 1.243l-1.5 6A1 1 0 0 1 20 16H18" fill="#06b6d4" />
                  <circle cx="8.5" cy="18.2" r="1.5" fill="#ef4444" />
                  <circle cx="17" cy="18.2" r="1.5" fill="#f59e0b" />
                </g>
              </svg>
            </button>
          
          {/* Dropdown de productos (búsqueda rápida) - solo se abre con clic o al escribir */}
          {dropdownOpen && !showProductsTable && filteredProducts.length > 0 && (() => {
            const isDark = !isLight;
            return (
            <div style={{ 
              position: 'absolute', 
              top: '100%', 
              left: 0, 
              right: 0, 
              background: isLight 
                ? 'rgba(255, 255, 255, 0.98)' 
                : 'rgba(20, 20, 30, 0.98)', 
              border: isLight ? '2px solid #e0e0e0' : '2px solid rgba(139, 92, 246, 0.3)', 
              borderRadius: 12, 
              marginTop: 8, 
              maxHeight: '400px', 
              overflowY: 'visible',
              overflowX: 'visible',
              zIndex: 20,
              scrollbarWidth: 'thin',
              scrollbarColor: isLight ? 'rgba(0,0,0,0.3) transparent' : 'rgba(139, 92, 246, 0.5) transparent',
              boxShadow: isLight 
                ? '0 10px 40px rgba(0, 0, 0, 0.15), 0 0 0 1px rgba(0, 0, 0, 0.05)' 
                : '0 10px 40px rgba(139, 92, 246, 0.3), 0 0 0 1px rgba(139, 92, 246, 0.2)',
              backdropFilter: 'blur(10px)',
            }}
            data-product-dropdown="true">
              <div style={{ overflow: 'visible', position: 'relative' }}>
              {visibleProducts.map((p, i) => {
                const outOfStock = (p.stock || 0) <= 0
                return (
                <div 
                  key={p.id} 
                  data-product-id={p.id}
                  onClick={() => { 
                    if (outOfStock) {
                      // Informar al usuario que no puede agregarse
                      alert('Producto agotado')
                      return
                    }
                    handleAddToCart(p); 
                    setSearch(''); 
                    setDropdownOpen(false); // Cerrar dropdown al seleccionar
                    setSelectedProductId(p.id);
                    // mantener el foco en el input para el siguiente producto
                    setTimeout(() => searchInputRef.current?.focus(), 0);
                    // Quitar cualquier color inline para que el input tome la variable CSS inmediatamente
                    setTimeout(() => {
                      const input = searchInputRef.current;
                      if (input) {
                        input.style.removeProperty('color');
                      }
                    }, 10);
                  }}
                  onMouseEnter={() => { setHoveredProductId(p.id); setHoveredIndex(i); }}
                  onMouseLeave={() => { setHoveredProductId(null); setHoveredIndex(-1); }}
                  style={{ 
                    padding: '16px', 
                    display: 'flex', 
                    justifyContent: 'space-between', 
                    alignItems: 'center',
                    gap: '12px',
                    background: (hoveredProductId === p.id || selectedProductId === p.id) 
                      ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' 
                      : 'transparent',
                    borderBottom: isDark 
                      ? '1px solid rgba(139, 92, 246, 0.15)' 
                      : '1px solid rgba(0, 0, 0, 0.06)',
                    transition: 'all 0.2s ease',
                    color: (hoveredProductId === p.id || selectedProductId === p.id) ? '#ffffff' : (isLight ? '#1a1a1a' : '#e0e0e0'),
                    opacity: outOfStock ? 0.5 : 1,
                    cursor: outOfStock ? 'not-allowed' : 'pointer',
                    borderRadius: i === 0 ? '12px 12px 0 0' : (i === visibleProducts.length - 1 ? '0 0 12px 12px' : '0'),
                    overflow: 'visible',
                    position: 'relative'
                  }}
                >
                  {/* Product Image */}
                  {showProductImages && (
                    p.image ? (
                      <div 
                        style={{ 
                          width: '90px', 
                          height: '90px',
                          flexShrink: 0,
                          position: 'relative',
                          overflow: 'visible'
                        }}
                        onMouseEnter={(e) => {
                          const img = e.currentTarget.querySelector('img') as HTMLElement;
                          if (img) {
                            img.style.transform = 'scale(3.0)';
                            img.style.zIndex = '9999';
                          }
                        }}
                        onMouseLeave={(e) => {
                          const img = e.currentTarget.querySelector('img') as HTMLElement;
                          if (img) {
                            img.style.transform = 'scale(1)';
                            img.style.zIndex = '1';
                          }
                        }}
                      >
                        <img 
                          src={p.image} 
                          alt={p.name}
                          style={{ 
                            width: '100%', 
                            height: '100%', 
                            objectFit: 'contain',
                            display: 'block',
                            transition: 'transform 0.1s ease',
                            transformOrigin: 'center center',
                            cursor: 'pointer',
                            position: 'relative'
                          }}
                        />
                      </div>
                    ) : (
                      <div style={{ 
                        width: '90px', 
                        height: '90px',
                        flexShrink: 0,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        background: isLight ? '#f5f5f5' : 'rgba(139, 92, 246, 0.1)',
                        borderRadius: '8px',
                        border: isLight ? '2px dashed #e0e0e0' : '2px dashed rgba(139, 92, 246, 0.3)'
                      }}>
                        <span style={{ 
                          fontSize: '13px', 
                          color: isLight ? '#999' : 'rgba(139, 92, 246, 0.5)',
                          fontWeight: 600
                        }}>Sin img</span>
                      </div>
                    )
                  )}
                  
                  {/* Product Info */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ 
                      fontWeight: 700, 
                      fontSize: 15, 
                      color: (hoveredProductId === p.id || selectedProductId === p.id) ? '#ffffff' : (isLight ? '#1a1a1a' : '#f0f0f0'),
                      marginBottom: '4px',
                      letterSpacing: '0.3px'
                    }}>{p.name}</div>
                    <div style={{ 
                      fontSize: 13, 
                      fontWeight: 500, 
                      color: (hoveredProductId === p.id || selectedProductId === p.id) ? 'rgba(255,255,255,0.9)' : (isLight ? '#666666' : 'rgba(200,200,200,0.8)'),
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px'
                    }}>
                      <span style={{ 
                        display: 'inline-flex', 
                        alignItems: 'center',
                        gap: '4px'
                      }}>
                        📦 {formatNumberWithDots(p.stock)}
                      </span>
                      {outOfStock ? (
                        <span style={{ 
                          color: '#ff4444',
                          fontWeight: 600,
                          fontSize: '12px'
                        }}>• Agotado</span>
                      ) : (
                        <span style={{ opacity: 0.8 }}>• {p.category || 'Sin categoría'}</span>
                      )}
                    </div>
                  </div>
                  
                  {/* Price */}
                  <div style={{ 
                    fontWeight: 800, 
                    color: (hoveredProductId === p.id || selectedProductId === p.id) ? '#ffffff' : (isLight ? '#667eea' : '#a78bfa'), 
                    fontSize: 16, 
                    flexShrink: 0,
                    letterSpacing: '0.5px'
                  }}>{formatCurrency(p.price)}</div>
                </div>
              )})}
              </div>
            </div>
            )
          })()}
        </div>

        {/* Búsqueda de Cliente */}
        <div style={{ flex: 0.8, minWidth: '180px' }}>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            {/* Dropdown personalizado para cliente */}
            <div style={{ position: 'relative', width: '100%' }}>
              <div 
                id="client-select-button"
                onClick={(event) => {
                  setShowClientDropdown(!showClientDropdown);
                }}
                style={{ 
                  width: '100%',
                  padding: '8px 12px',
                  background: isLight ? 'var(--card-bg)' : 'rgba(9,12,18,0.9)',
                  border: isLight ? '2px solid #0066cc' : '2px solid rgba(51,153,255,0.9)',
                  boxShadow: isLight ? '0 8px 24px rgba(0,102,204,0.16)' : '0 8px 28px rgba(0,102,204,0.28)',
                  borderRadius: 6,
                  color: isLight ? 'var(--accent)' : '#cfe8ff',
                  fontSize: 16,
                  transition: 'none',
                  outline: 'none',
                  cursor: 'pointer',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  fontWeight: selectedClient ? 700 : 600,
                  gap: 6,
                  minWidth: 0,
                  lineHeight: 1
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, width: '100%', lineHeight: 1 }}>
                  {/* Badge F2 */}
                  <kbd style={{
                    background: 'transparent',
                    color: 'var(--text-secondary)',
                    padding: '2px 4px',
                    fontSize: '0.85rem',
                    fontWeight: '700',
                    fontFamily: 'monospace',
                    flexShrink: 0,
                    lineHeight: 1
                  }}>
                    F2
                  </kbd>
                  <span style={{ color: 'inherit', fontWeight: '900', display: 'flex', alignItems: 'center', gap: 6, flex: 1, overflow: 'hidden', lineHeight: 1 }}>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden style={{flexShrink:0}}>
                      <path d="M12 12c2.761 0 5-2.239 5-5s-2.239-5-5-5-5 2.239-5 5 2.239 5 5 5z" fill="currentColor" />
                      <path d="M4 20c0-3.314 2.686-6 6-6h4c3.314 0 6 2.686 6 6v1H4v-1z" style={{fill: 'currentColor', opacity: 0.18}} />
                    </svg>
                    <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', lineHeight: 1 }}>
                      {selectedClient ? (selectedClient === 'GENERAL' ? 'Cliente Común' : (clients.find(c => c.id === selectedClient)?.name || selectedClientName || 'Cliente')) : 'Selecciona cliente'}
                    </span>
                  </span>
                  <span style={{ fontSize: '12px', color: 'inherit', fontWeight: '900', lineHeight: 1 }}>▼</span>
                </div>
              </div>
              
              {showClientDropdown && (
                <div 
                  id="client-dropdown"
                  style={{ 
                    position: 'absolute', 
                    top: '100%', 
                    left: 0, 
                    right: 0, 
                    background: isLight ? '#ffffff' : '#000000', 
                    border: 'none', 
                    borderRadius: 6, 
                    marginTop: 4, 
                    maxHeight: '200px', 
                    overflowY: 'auto', 
                    zIndex: 20,
                    scrollbarWidth: 'thin',
                    scrollbarColor: isLight ? 'rgba(0,0,0,0.5) transparent' : '#ffffff #000000',
                    boxShadow: 'none'
                  }}
                >
                  <div 
                    onClick={() => {
                      setSelectedClient('');
                      setSelectedClientName(null);
                      setShowClientDropdown(false);
                    }}
                    style={{ 
                      padding: '8px 12px', 
                      cursor: 'pointer', 
                      backgroundColor: isLight ? '#ffffff' : '#000000',
                      color: isLight ? '#000000' : '#ffffff',
                      fontSize: 14
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = '#3b82f6';
                      e.currentTarget.style.color = '#ffffff';
                      e.currentTarget.style.setProperty('background-color', '#3b82f6', 'important');
                      e.currentTarget.style.setProperty('color', '#ffffff', 'important');
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = isLight ? '#ffffff' : '#000000';
                      e.currentTarget.style.color = isLight ? '#000000' : '#ffffff';
                    }}
                  >
                    👤 Selecciona cliente
                  </div>
                  <div 
                    onClick={() => {
                      setSelectedClient('GENERAL');
                      setSelectedClientName(null);
                      setShowClientDropdown(false);
                    }}
                    style={{ 
                      padding: '8px 12px', 
                      cursor: 'pointer', 
                      backgroundColor: isLight ? '#ffffff' : '#000000',
                      color: isLight ? '#000000' : '#ffffff',
                      fontSize: 14
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = '#3b82f6';
                      e.currentTarget.style.color = '#ffffff';
                      e.currentTarget.style.setProperty('background-color', '#3b82f6', 'important');
                      e.currentTarget.style.setProperty('color', '#ffffff', 'important');
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = isLight ? '#ffffff' : '#000000';
                      e.currentTarget.style.color = isLight ? '#000000' : '#ffffff';
                    }}
                  >
                    👥 Cliente Común
                  </div>
                  {selectedClientName && !clients.find(c => c.id === selectedClient) && (
                    <div 
                      onClick={() => {
                        setShowClientDropdown(false);
                      }}
                      style={{ 
                        padding: '8px 12px', 
                        cursor: 'pointer', 
                        backgroundColor: '#000000',
                        color: '#ffffff',
                        fontSize: 14
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.backgroundColor = '#a1f3dc';
                        e.currentTarget.style.color = '#0066cc';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.backgroundColor = '#000000';
                        e.currentTarget.style.color = '#ffffff';
                      }}
                    >
                      {selectedClientName}
                    </div>
                  )}
                  {clients.map(c => (
                    <div 
                      key={c.id}
                      onClick={() => {
                        setSelectedClient(c.id);
                        setSelectedClientName(null);
                        setShowClientDropdown(false);
                      }}
                      onDoubleClick={() => {
                        // Doble clic: seleccionar cliente y cerrar dropdown
                        setSelectedClient(c.id);
                        setSelectedClientName(null);
                        setShowClientDropdown(false);
                      }}
                      data-selected={selectedClient === c.id ? 'true' : 'false'}
                      style={{ 
                        padding: '8px 12px', 
                        cursor: 'pointer', 
                        backgroundColor: selectedClient === c.id ? '#1d4ed8' : (isLight ? '#ffffff' : '#000000'),
                        color: selectedClient === c.id ? '#ffffff' : (isLight ? '#000000' : '#ffffff'),
                        fontSize: 14
                      }}
                      onMouseEnter={(e) => {
                        if (selectedClient !== c.id) {
                          e.currentTarget.style.backgroundColor = '#3b82f6';
                          e.currentTarget.style.color = '#ffffff';
                          e.currentTarget.style.setProperty('background-color', '#3b82f6', 'important');
                          e.currentTarget.style.setProperty('color', '#ffffff', 'important');
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (selectedClient !== c.id) {
                          e.currentTarget.style.backgroundColor = isLight ? '#ffffff' : '#000000';
                          e.currentTarget.style.color = isLight ? '#000000' : '#ffffff';
                        }
                      }}
                    >
                      {c.name}
                    </div>
                  ))}
                </div>
              )}
            </div>
            <button
              onClick={() => { if (onNavigateToClients) onNavigateToClients() }}
              title="Clientes"
              aria-label="Clientes"
              style={{
                padding: '8px',
                background: 'transparent',
                color: 'inherit',
                border: 'none',
                borderRadius: 4,
                cursor: 'pointer',
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                width: 'auto',
                height: 'auto',
                lineHeight: 1,
                boxShadow: 'none'
              }}
            >
              <svg viewBox="0 0 24 24" width="32" height="32" aria-hidden="true">
                <g>
                  <circle cx="9" cy="8" r="2.6" fill="#f59e0b" />
                  <path d="M4 20c0-3 3-5 5-5h2c2 0 5 2 5 5" fill="#10b981" />
                  <circle cx="18" cy="11" r="2.2" fill="#6366f1" />
                </g>
              </svg>
            </button>
            <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
              <button data-toolbar-btn="cart" onClick={() => {
                // El botón del carrito no hace nada
              }} style={{ padding: '8px', background: 'var(--card)', color: 'var(--text)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 4, cursor: 'pointer', fontWeight: 900, fontSize: 18, display: 'inline-flex', alignItems: 'center', gap: '4px', lineHeight: 1, whiteSpace: 'nowrap', flexShrink: 0 }}>
                <span style={{ fontSize: 18, lineHeight: 1 }}>🛒</span>
                <span style={{ color: '#3b82f6', fontSize: 16, fontWeight: 900 }}>{cart.length}</span>
              </button>
              <button data-toolbar-btn="trash" onClick={() => { if (cart.length > 0) { clearCart(); localStorage.setItem('pos_cart', '[]'); } }} style={{ padding: '8px', background: 'transparent', color: 'inherit', border: 'none', borderRadius: 4, cursor: 'pointer', fontSize: 18, lineHeight: 1, flexShrink: 0, display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }} title="Vaciar carrito">
                🗑️
              </button>
            </div>
            
          </div>
        </div>

      {/* Modal obligatorio para seleccionar cliente después de una venta */}
      {showSelectClientModal && (
        <div className="modal-overlay">
          <div className="modal" onClick={e => e.stopPropagation()} style={{ maxWidth: 520 }}>
            <h4>Selecciona cliente para la próxima venta</h4>
            <div style={{ color: 'var(--danger)', fontWeight: 900, marginTop: 8 }}>Falta seleccionar cliente para la próxima venta</div>
            <div style={{ maxHeight: 220, overflowY: 'auto', marginTop: 8 }}>
              {clients.map(c => (
                <label key={c.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 6px', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                  <input type="radio" name="modal_client" checked={modalTempClient === c.id} onChange={() => setModalTempClient(c.id)} />
                  <div style={{ fontWeight: 900 }}>{c.name}</div>
                </label>
              ))}
            </div>

            <hr style={{ margin: '12px 0', borderColor: 'rgba(255,255,255,0.04)' }} />
            <h5><span style={{ marginRight: 8 }}>+</span>Crear nuevo cliente</h5>
            <div style={{ display: 'grid', gap: 8, marginTop: 8 }}>
              <input placeholder="Nombre" value={modalNewName} onChange={e => setModalNewName(e.target.value)} style={{ padding: '8px', borderRadius: 6, background: 'var(--card)', color: 'var(--text)', border: '1px solid rgba(255,255,255,0.06)' }} />
              <input placeholder="Email" value={modalNewEmail} onChange={e => setModalNewEmail(e.target.value)} style={{ padding: '8px', borderRadius: 6, background: 'var(--card)', color: 'var(--text)', border: '1px solid rgba(255,255,255,0.06)' }} />
              <input placeholder="Teléfono" value={modalNewPhone} onChange={e => setModalNewPhone(e.target.value)} style={{ padding: '8px', borderRadius: 6, background: 'var(--card)', color: 'var(--text)', border: '1px solid rgba(255,255,255,0.06)' }} />
              <input placeholder="NIT/Cédula" value={modalNewNit} onChange={e => setModalNewNit(e.target.value)} style={{ padding: '8px', borderRadius: 6, background: 'var(--card)', color: 'var(--text)', border: '1px solid rgba(255,255,255,0.06)' }} />
              <input placeholder="Dirección" value={modalNewAddress} onChange={e => setModalNewAddress(e.target.value)} style={{ padding: '8px', borderRadius: 6, background: 'var(--card)', color: 'var(--text)', border: '1px solid rgba(255,255,255,0.06)' }} />
              <div style={{ display: 'flex', gap: 8 }}>
                <button className="btn" onClick={() => {
                  // Crear cliente
                  if (!modalNewName.trim()) return alert('Nombre requerido')
                  const id = `C-${Date.now()}`
                  const newClient = { id, name: modalNewName.trim(), email: modalNewEmail.trim() || '', phone: modalNewPhone.trim() || '', nit: modalNewNit.trim() || '', address: modalNewAddress.trim() || '' }
                  try { setClients([...clients, newClient]) } catch (e) { }
                  setModalTempClient(id)
                  // limpiar campos
                  setModalNewName(''); setModalNewEmail(''); setModalNewPhone(''); setModalNewNit(''); setModalNewAddress('')
                }}>Crear cliente</button>
                <div style={{ flex: 1 }} />
              </div>
            </div>

            <div style={{ color: 'var(--danger)', minHeight: 18, marginTop: 8 }}>{/* placeholder for modal errors */}</div>
            <div className="modal-actions" style={{ marginTop: 12, display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
              <button className="btn primary" onClick={() => {
                if (!modalTempClient) {
                  // mostrar error inline en modal
                  // usamos un pequeño DOM update: añadir y remover un mensaje temporal
                  const m = document.createElement('div')
                  m.textContent = 'Selecciona un cliente'
                  m.style.color = 'var(--danger)'
                  m.style.fontWeight = '700'
                  m.style.marginRight = '12px'
                  const actions = document.querySelector('.modal .modal-actions')
                  if (actions && !actions.querySelector('.modal-error')) {
                    m.className = 'modal-error'
                    actions.insertBefore(m, actions.firstChild)
                    setTimeout(() => { try { m.remove() } catch (e) {} }, 2500)
                  }
                  return
                }
                setSelectedClient(modalTempClient)
                setSelectedClientName(clients.find(x => x.id === modalTempClient)?.name || null)
                setShowSelectClientModal(false)
               }}>Confirmar cliente</button>
             </div>
           </div>
         </div>
        )}
       </div>
 
      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', flex: 1, overflow: 'hidden' }}>
        {/* CARRITO - EXPANDIBLE */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, flex: 1, minHeight: 0, overflow: 'hidden' }}>
          {/* Header con alineación fija */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 80px 120px 100px 120px 80px', gap: '8px', alignItems: 'center', padding: '12px', marginTop: 2, marginBottom: 4, borderRadius: 4, color: 'var(--text)', fontSize: '14px', background: 'rgba(255,255,255,0.08)', borderBottom: '2px solid rgba(255,255,255,0.15)', fontWeight: 900, position: 'sticky', top: 0, zIndex: 10 }}>
            <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontWeight: 900, fontSize: '14px', textAlign: 'left' }}>Producto</div>
            <div style={{ textAlign: 'center', fontWeight: 900, fontSize: '14px' }}>Cantidad</div>
            <div style={{ textAlign: 'center', fontWeight: 900, fontSize: '14px' }}>Precio Unitario</div>
            <div style={{ textAlign: 'center', fontWeight: 900, fontSize: '14px' }}>Descuento</div>
            <div style={{ textAlign: 'center', fontWeight: 900, fontSize: '14px' }}>Total</div>
            <div style={{ textAlign: 'center', fontWeight: 900, fontSize: '14px' }}>Acción</div>
          </div>
          
          {/* Carrito items */}
          <div style={{ flex: 1, overflowY: 'auto', borderRadius: 6, border: '1px solid rgba(255,255,255,0.08)', padding: '0', background: 'rgba(255,255,255,0.02)' }}>
            {cart.length === 0 ? (
              <div style={{ padding: 20, textAlign: 'center', color: 'var(--muted)', fontSize: 12 }}>Carrito vacío</div>
            ) : (
              cart.map(item => {
                  const product = products.find(p => p.id === item.productId)
                  const itemDiscount = getProductDiscount(item.productId, item.price, item.qty)
                  return (
                    <div key={item.productId} style={{ 
                      display: 'grid', 
                      gridTemplateColumns: '1fr 80px 120px 100px 120px 80px', 
                      gap: '8px', 
                      alignItems: 'center', 
                      padding: '12px', 
                      borderBottom: '1px solid rgba(255,255,255,0.05)', 
                      cursor: 'pointer',
                      background: 'rgba(255,255,255,0.02)',
                      borderRadius: 4,
                      border: '1px solid rgba(255,255,255,0.1)'
                    }}>
                        {/* Nombre del producto */}
                        <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontWeight: 900, fontSize: 16, color: 'var(--text)', textAlign: 'left', paddingLeft: '0px' }}>
                          <span title={item.name}>{item.name}</span>
                        </div>
                        
                        {/* Cantidad */}
                        <div style={{ textAlign: 'center' }}>
                          <input
                            type="text"
                            inputMode="numeric"
                            pattern="[0-9]*"
                            value={String(item.qty)}
                            onChange={(e) => {
                              const raw = e.target.value.replace(/\D/g, '')
                              const n = raw === '' ? 0 : parseInt(raw, 10)
                              const prod = products.find(p => p.id === item.productId)
                              const avail = prod ? prod.stock : 0
                              if (n === 0) {
                                setQty(item.productId, 1)
                                return
                              }
                              if (n > avail) {
                                alert(`Solo hay ${avail} unidades disponibles. Máximo permitido: ${avail}`)
                                setQty(item.productId, n) // Permite el valor pero muestra advertencia
                                return
                              }
                              setQty(item.productId, n)
                            }}
                            style={{ 
                              width: '70px', 
                              textAlign: 'center', 
                              fontWeight: 900, 
                              fontSize: 16, 
                              border: '1px solid rgba(255,255,255,0.2)', 
                              background: 'var(--card)', 
                              color: 'var(--text)', 
                              borderRadius: 4, 
                              padding: '4px'
                            }}
                          />
                        </div>
                        
                        {/* Precio Unitario */}
                        <div style={{ textAlign: 'center', fontWeight: 900, color: 'var(--accent2)', fontSize: 16 }}>
                          {formatCurrency(item.price)}
                        </div>
                        
                        {/* Descuento */}
                        <div style={{ textAlign: 'center' }}>
                          {itemDiscount > 0 ? (
                            <span style={{ 
                              color: '#FF0000', 
                              fontWeight: 900, 
                              fontSize: 16,
                              background: 'rgba(255, 0, 0, 0.1)',
                              padding: '2px 6px',
                              borderRadius: 3,
                              cursor: 'pointer'
                            }}
                            onClick={() => openDiscountModal(item.productId)}
                            title="Click para editar descuento">
                              {getDiscountText(item.productId)}
                            </span>
                          ) : (
                            <span 
                              onClick={() => openDiscountModal(item.productId)}
                              style={{ 
                                cursor: 'pointer', 
                                color: 'var(--accent)', 
                                fontSize: 18,
                                padding: '2px 6px',
                                borderRadius: 3,
                                background: 'rgba(59, 130, 246, 0.1)',
                                transition: 'all 0.2s'
                              }}
                              title="Agregar descuento"
                              onMouseOver={(e) => e.currentTarget.style.background = 'rgba(59, 130, 246, 0.2)'}
                              onMouseOut={(e) => e.currentTarget.style.background = 'rgba(59, 130, 246, 0.1)'}
                            >
                              🏷️
                            </span>
                          )}
                        </div>
                        
                        {/* Total */}
                        <div style={{ textAlign: 'center', fontWeight: 900, color: 'var(--accent)', fontSize: 16 }}>
                          {formatCurrency(item.price * item.qty)}
                        </div>
                        
                        {/* Eliminar */}
                        <div style={{ textAlign: 'center', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                          <span 
                            onClick={() => removeFromCart(item.productId)} 
                            style={{ 
                              cursor: 'pointer', 
                              fontSize: 16, 
                              color: 'var(--danger)', 
                              padding: '6px 8px',
                              borderRadius: 4,
                              background: 'rgba(220, 38, 38, 0.1)',
                              transition: 'all 0.2s',
                              display: 'inline-flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              border: '1px solid rgba(220, 38, 38, 0.2)'
                            }}
                            title="Eliminar producto"
                            onMouseOver={(e) => {
                              e.currentTarget.style.background = 'rgba(220, 38, 38, 0.2)';
                              e.currentTarget.style.transform = 'translateY(-1px)';
                            }}
                            onMouseOut={(e) => {
                              e.currentTarget.style.background = 'rgba(220, 38, 38, 0.1)';
                              e.currentTarget.style.transform = 'translateY(0)';
                            }}
                          >
                            🗑️
                          </span>
                        </div>
                      
                    </div>
                  )
                })
            )}
          </div>

          {/* Totales compacto */}
          <div style={{ width: '100%', padding: '12px 8px', background: 'var(--card)', borderRadius: 8, borderTop: showActionMenu ? 'none' : '2px solid var(--accent)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8, fontSize: 14, minHeight: 100 }}>
            <div style={{ width: 'auto', marginTop: 0, marginLeft: 0, order: 0, display: 'flex', alignItems: 'center', gap: 12 }}>
              <button
                onClick={() => {
                if (!selectedClient) {
                  alert('Por favor selecciona un cliente');
                  return;
                }
                if (cart.length === 0) {
                  alert('Por favor agrega productos al carrito');
                  return;
                }
                setShowPaymentModal(true);
              }}
                style={{ 
                  width: 'auto',
                  minWidth: 200,
                  height: 60,
                  padding: '12px 24px', 
                  background: 'linear-gradient(135deg, #00d084 0%, #00a86b 100%)',
                  color: 'white', 
                  border: 'none',
                  borderRadius: '8px',
                  fontWeight: '900',
                  fontSize: '48px',
                  cursor: 'pointer',
                  whiteSpace: 'nowrap',
                  transition: 'all 0.3s ease',
                  textAlign: 'center',
                  boxShadow: '0 4px 12px rgba(16, 185, 129, 0.3)',
                  display: 'inline-flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  lineHeight: '1',
                  position: 'relative'
                }}
              onMouseOver={(e) => {
                e.currentTarget.style.boxShadow = '0 6px 20px rgba(16, 185, 129, 0.4)';
                e.currentTarget.style.transform = 'translateY(-2px)';
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.boxShadow = '0 4px 12px rgba(16, 185, 129, 0.3)';
                e.currentTarget.style.transform = 'translateY(0)';
              }}
              title="Cobrar venta actual"
            >
              {/* Badge F4 */}
              <kbd style={{
                position: 'absolute',
                top: '8px',
                left: '8px',
                background: 'rgba(255, 255, 255, 0.3)',
                color: 'white',
                padding: '2px 6px',
                fontSize: '0.75rem',
                fontWeight: '700',
                fontFamily: 'monospace',
                borderRadius: '4px',
                lineHeight: 1
              }}>
                F4
              </kbd>
              <span style={{ fontSize: '38px', fontWeight: '900', lineHeight: '1' }}>Venta</span>
            </button>
            </div>
            
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 2, minWidth: 200, order: 1 }}>
              {/* Calcular descuento total */}
              {(() => {
                // Usar el descuento calculado en `calculateTotal` para evitar restarlo dos veces
                const totalDiscount = total.discount

                return (
                  <>
                    <div style={{ fontSize: 12, textAlign: 'right' }}><span style={{ fontWeight: 900 }}>Subtotal:</span> <span style={{ color: '#3b82f6', fontWeight: 900 }}>{formatCurrency(total.subtotal)}</span></div>
                    {applyTax && total.tax > 0 && (
                      <div style={{ fontSize: 12, textAlign: 'right' }}><span style={{ fontWeight: 900 }}>IVA:</span> <span style={{ color: '#3b82f6', fontWeight: 900 }}>{formatCurrency(total.tax)}</span></div>
                    )}
                    {totalDiscount > 0 && (
                      <div style={{ fontSize: 12, textAlign: 'right', fontWeight: 900 }}><span style={{ fontWeight: 900 }}>Descuento:</span> <span style={{ color: '#FF0000', fontWeight: 900 }}>-{formatCurrency(totalDiscount)}</span></div>
                    )}
                    <div style={{ fontSize: 19, textAlign: 'right' }}>
                      <span style={{ fontWeight: 900 }}>Total:</span> <span style={{ color: '#3b82f6', fontWeight: 900 }}>{formatCurrency(total.total)}</span>
                    </div>
                  </>
                )
              })()}
            </div>
          </div>
      </div>

        {/* Botón oculto para triggerear pago desde sidebar */}
        <button
          data-trigger-payment
          onClick={() => {
            if (!selectedClient) {
              alert('Por favor selecciona un cliente');
              return;
            }
            if (cart.length === 0) {
              alert('Por favor agrega productos al carrito');
              return;
            }
            setShowPaymentModal(true);
            setAmountReceived('');
          }}
          style={{ display: 'none' }}
        />

        {/* Modal de Pago con Cálculo de Cambio */}
        {showPaymentModal && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: isLight ? '#f5f5f5' : '#1a1a2e',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 1000
          }}>
            <div style={{
              background: isLight ? '#ffffff' : '#1a1a2e',
              padding: '24px',
              borderRadius: '12px',
              border: '1px solid ' + (isLight ? '#e0e0e0' : '#3a3a5e'),
              boxShadow: '0 8px 32px rgba(0,0,0,0.3)',
              minWidth: '400px',
              maxWidth: '90%'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '24px' }}>
                <div style={{ 
                  width: '48px', 
                  height: '48px', 
                  borderRadius: '14px', 
                  background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '24px'
                }}>
                  💰
                </div>
                <div>
                  <h3 style={{ margin: '0', color: 'var(--text)', fontSize: '22px', fontWeight: '700', letterSpacing: '-0.5px' }}>Procesar Pago</h3>
                  <p style={{ margin: '2px 0 0 0', color: 'var(--muted)', fontSize: '13px' }}>Completa el pago de tu venta</p>
                </div>
              </div>
              
              <div style={{ 
                background: isLight ? '#eff6ff' : '#1e3a5f', 
                borderRadius: '14px', 
                padding: '20px', 
                marginBottom: '24px',
                border: '1px solid ' + (isLight ? '#93c5fd' : '#3b82f6')
              }}>
                <span style={{ color: 'var(--muted)', fontSize: '13px', fontWeight: '500', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Total a pagar</span>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '8px' }}>
                  <span style={{ fontWeight: 'bold', fontSize: '32px', color: 'var(--accent)', letterSpacing: '-1px' }}>
                    {formatCurrency(calculateTotal().total)}
                  </span>
                </div>
              </div>

              {paymentMethod === 'efectivo' && (
              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', marginBottom: '10px', color: 'var(--text)', fontSize: '14px', fontWeight: '600' }}>
                  💵 Monto recibido
                </label>
                <div style={{ position: 'relative' }}>
                  <span style={{
                    position: 'absolute',
                    left: '16px',
                    top: '50%',
                    transform: 'translateY(-50%)',
                    color: 'var(--muted)',
                    fontSize: '16px',
                    fontWeight: '600'
                  }}>$</span>
                  <InputNumero
                    value={amountReceived}
                    onChange={(value) => handleAmountReceivedChange(value)}
                    placeholder="0"
                    style={{
                      width: '100%',
                      padding: '14px 16px 14px 36px',
                      background: isLight ? '#ffffff' : '#1a1a2e',
                      color: 'var(--text)',
                      borderRadius: '12px',
                      fontSize: '18px',
                      fontWeight: '600',
                      textAlign: 'right',
                      boxSizing: 'border-box'
                    }}
                    autoFocus
                  />
                </div>
              </div>
            )}

              <div style={{ marginBottom: '24px' }}>
                <label style={{ display: 'block', marginBottom: '10px', color: 'var(--text)', fontSize: '14px', fontWeight: '600' }}>
                  💳 Método de pago
                </label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value as any)}
                  style={{
                    width: '100%',
                    padding: '12px 14px',
                    background: 'var(--card)',
                    color: 'var(--text)',
                    border: '2px solid var(--accent)',
                    borderRadius: '12px',
                    fontSize: '14px',
                    fontWeight: '600',
                    cursor: 'pointer',
                    appearance: 'none',
                    backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='${isLight ? '%23000000' : '%23ffffff'}' d='M6 9L1 4h10z'/%3E%3C/svg%3E")`,
                    backgroundRepeat: 'no-repeat',
                    backgroundPosition: 'right 12px center',
                    paddingRight: '36px'
                  }}
                >
                  <option value="efectivo">💵 Efectivo</option>
                  <option value="nequi">🅽️ Nequi</option>
                  <option value="daviplata">🅰️ Daviplata</option>
                  <option value="breb">🔵 BRE-B</option>
                  <option value="transferencia">🏦 Transferencia</option>
                  <option value="tarjeta">💳 Tarjeta</option>
                </select>
              </div>

              {/* Descuentos solo por producto - el general fue removido */}

              {amountReceivedRaw && parseFloat(amountReceivedRaw) > 0 && paymentMethod === 'efectivo' && (
                <div style={{ marginBottom: '20px', padding: '12px', background: parseFloat(amountReceivedRaw) >= calculateTotal().total ? 'rgba(76, 175, 80, 0.1)' : 'rgba(244, 67, 54, 0.1)', borderRadius: '8px', border: parseFloat(amountReceivedRaw) >= calculateTotal().total ? '1px solid rgba(76, 175, 80, 0.3)' : '1px solid rgba(244, 67, 54, 0.3)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ color: 'var(--text)', fontSize: '14px' }}>
                      {parseFloat(amountReceivedRaw) >= calculateTotal().total ? 'Cambio:' : 'Faltante:'}
                    </span>
                    <span style={{ fontWeight: 'bold', fontSize: '18px', color: parseFloat(amountReceivedRaw) >= calculateTotal().total ? 'var(--success)' : 'var(--danger)' }}>
                      {formatCurrency(Math.abs(parseFloat(amountReceivedRaw) - calculateTotal().total))}
                    </span>
                  </div>
                </div>
              )}

              <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end' }}>
                <button
                  onClick={() => setShowPaymentModal(false)}
                  style={{
                    padding: '8px 16px',
                    background: '#dc2626',
                    color: 'white',
                    border: 'none',
                    borderRadius: '6px',
                    cursor: 'pointer',
                    fontSize: '14px',
                    fontWeight: 'bold'
                  }}
                >
                  Cancelar
                </button>
                <button
                  onClick={() => {
                    console.log('=== BOTÓN COBRAR DEL MODAL CLICKEADO ===');
                    
                    // Validar monto recibido si es efectivo
                    const total = calculateTotal().total
                    if (paymentMethod === 'efectivo') {
                      const received = parseFloat(amountReceivedRaw || '0')
                      if (!amountReceivedRaw || received < total) {
                        alert('❌ Para pago en efectivo, debe ingresar un monto igual o mayor al total de la venta.')
                        return
                      }
                    }
                    
                    // Guardar formato de factura en localStorage
                    try {
                      localStorage.setItem('invoiceFormat', invoiceFormat)
                    } catch (e) {}
                    
                    const sale = completeSale(selectedClient)
                    if (sale) {
                      const received = paymentMethod === 'efectivo' ? parseFloat(amountReceivedRaw || '0') : total
                      const change = paymentMethod === 'efectivo' ? received - total : 0
                      
                      console.log('✅ Pago procesado:', { sale, total, received, change, paymentMethod });
                      
                      // Obtener nombre del método de pago
                      const paymentMethodNames = {
                        'efectivo': '💵 Efectivo',
                        'nequi': '🅽️ Nequi',
                        'daviplata': '🅰️ Daviplata',
                        'breb': '🔵 BRE-B',
                        'transferencia': '🏦 Transferencia Bancaria',
                        'tarjeta': '💳 Tarjeta Débito/Crédito'
                      }
                      
                      // Mostrar resumen del pago
                      const formatName = invoiceFormat === 'ticket80' ? 'Ticket 80mm' : invoiceFormat === 'ticket57' ? 'Ticket 57mm' : 'Carta'
                      const paymentName = paymentMethodNames[paymentMethod]
                      
                      // Solo mostrar cambio si es mayor a cero
                      let changeText = ''
                      if (change > 0) {
                        changeText = `\nCambio: ${formatCurrency(change)}`
                      }
                      
                      alert(`✅ Pago procesado:\n\nFactura: ${sale.id}\nTotal: ${formatCurrency(total)}\nRecibido: ${formatCurrency(received)}\nMétodo: ${paymentName}${changeText}\n\nFormato: ${formatName}`)
                      // Generar y guardar factura
                      // Determinar el ancho según el formato
                      const companyConfig = JSON.parse(localStorage.getItem('pos_company_config') || '{}')
                      const format = companyConfig.invoiceFormat || 'carta'
                      const formatWidth = format === 'ticket80' ? '300px' : format === 'ticket57' ? '220px' : '800px'

                      // Configuración de empresa para la factura
                      const companyLogo = companyConfig.logo || '' 
                      const companyName = companyConfig.companyName || '' 
                      const companyNIT = companyConfig.companyNIT || '' 

                      // Obtener datos completos del cliente
                      const clientData = sale.clientId ? (() => {
                        try {
                          const clients = JSON.parse(localStorage.getItem('pos_clients') || '[]')
                          return clients.find((c: any) => c.id === sale.clientId) || {}
                        } catch { return {} }
                      })() : {}
                      
                      const clientName = clientData.name || sale.client || 'Cliente Común'
                      const clientDocument = clientData.nit || clientData.document || ''
                      const clientAddress = clientData.address || ''
                      const clientPhone = clientData.phone || ''
                      
                      // Configuración de tamaño de letra
                      const fontSize = companyConfig.invoiceFontSize || 11
                      
                      // Generar HTML según el formato seleccionado
                      let invoiceHTML = ''
                      
                      if (format === 'carta') {
                        // DISEÑO ELEGANTE PARA CARTA (8.5" x 11")
                        invoiceHTML = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Factura ${sale.id}</title>
  <style>
    @page { size: letter; margin: 0; }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { 
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
      background: #f5f5f5; 
      padding: 20px;
    }
    .invoice-container { 
      max-width: 800px; 
      margin: 0 auto; 
      background: white; 
      box-shadow: 0 0 30px rgba(0,0,0,0.1);
      border-radius: 12px;
      overflow: hidden;
    }
    
    /* Header con gradiente */
    .header { 
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 40px;
      color: white;
      position: relative;
    }
    .header::after {
      content: '';
      position: absolute;
      bottom: -20px;
      left: 0;
      right: 0;
      height: 20px;
      background: white;
      border-radius: 20px 20px 0 0;
    }
    .header-content {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
    }
    .company-section {
      flex: 1;
    }
    .company-logo {
      max-width: 120px;
      max-height: 80px;
      margin-bottom: 15px;
      border-radius: 8px;
      background: white;
      padding: 8px;
    }
    .company-name {
      font-size: 28px;
      font-weight: 700;
      margin-bottom: 8px;
      text-shadow: 0 2px 4px rgba(0,0,0,0.2);
    }
    .company-info {
      font-size: 13px;
      opacity: 0.95;
      line-height: 1.6;
    }
    .invoice-badge {
      background: rgba(255,255,255,0.2);
      backdrop-filter: blur(10px);
      padding: 20px 30px;
      border-radius: 12px;
      text-align: right;
      border: 2px solid rgba(255,255,255,0.3);
    }
    .invoice-badge-title {
      font-size: 14px;
      opacity: 0.9;
      margin-bottom: 8px;
      text-transform: uppercase;
      letter-spacing: 2px;
    }
    .invoice-number {
      font-size: 24px;
      font-weight: 700;
    }
    
    /* Info boxes */
    .info-section {
      padding: 40px;
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 30px;
    }
    .info-box {
      background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
      padding: 25px;
      border-radius: 12px;
      border-left: 4px solid #667eea;
    }
    .info-box-title {
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 1.5px;
      color: #667eea;
      font-weight: 700;
      margin-bottom: 15px;
    }
    .info-line {
      display: flex;
      justify-content: space-between;
      padding: 8px 0;
      border-bottom: 1px solid rgba(0,0,0,0.05);
      font-size: 14px;
    }
    .info-line:last-child {
      border-bottom: none;
    }
    .info-label {
      color: #6c757d;
      font-weight: 500;
    }
    .info-value {
      color: #212529;
      font-weight: 600;
    }
    
    /* Items table */
    .items-section {
      padding: 0 40px 20px;
    }
    .items-table {
      width: 100%;
      border-collapse: collapse;
      background: white;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }
    .items-table thead {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
    }
    .items-table th {
      padding: 15px;
      text-align: left;
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 1px;
      font-weight: 600;
    }
    .items-table th:nth-child(2),
    .items-table th:nth-child(3),
    .items-table th:nth-child(4) {
      text-align: right;
    }
    .items-table tbody tr {
      border-bottom: 1px solid #f0f0f0;
      transition: background 0.2s;
    }
    .items-table tbody tr:hover {
      background: #f8f9fa;
    }
    .items-table td {
      padding: 15px;
      font-size: 14px;
    }
    .item-name {
      font-weight: 600;
      color: #212529;
    }
    .item-details {
      font-size: 12px;
      color: #6c757d;
      margin-top: 4px;
    }
    .item-discount {
      font-size: 12px;
      color: #dc3545;
      margin-top: 4px;
      font-weight: 500;
    }
    .items-table td:nth-child(2),
    .items-table td:nth-child(3),
    .items-table td:nth-child(4) {
      text-align: right;
    }
    
    /* Totals */
    .totals-section {
      padding: 30px 40px;
      background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    }
    .totals-grid {
      max-width: 400px;
      margin-left: auto;
    }
    .total-line {
      display: flex;
      justify-content: space-between;
      padding: 10px 0;
      font-size: 15px;
    }
    .total-line-label {
      color: #6c757d;
      font-weight: 500;
    }
    .total-line-value {
      font-weight: 600;
      color: #212529;
    }
    .total-final {
      margin-top: 15px;
      padding: 20px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border-radius: 12px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .total-final-label {
      font-size: 18px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    .total-final-value {
      font-size: 32px;
      font-weight: 700;
    }
    
    /* Payment info */
    .payment-section {
      padding: 30px 40px;
      background: white;
    }
    .payment-title {
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 1.5px;
      color: #667eea;
      font-weight: 700;
      margin-bottom: 15px;
    }
    .payment-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 15px;
    }
    .payment-item {
      background: #f8f9fa;
      padding: 15px;
      border-radius: 8px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .payment-item.highlight {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
    }
    .payment-label {
      font-size: 13px;
      font-weight: 500;
    }
    .payment-value {
      font-size: 16px;
      font-weight: 700;
    }
    
    /* Footer */
    .footer {
      padding: 30px 40px;
      text-align: center;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
    }
    .footer-message {
      font-size: 16px;
      font-weight: 600;
      margin-bottom: 10px;
    }
    .footer-info {
      font-size: 13px;
      opacity: 0.9;
    }
    
    @media print {
      body { background: white; padding: 0; }
      .invoice-container { box-shadow: none; border-radius: 0; }
    }
  </style>
</head>
<body>
  <div class="invoice-container">
    <div class="header">
      <div class="header-content">
        <div class="company-section">
          ${companyLogo ? `<img src="${companyLogo}" class="company-logo" alt="Logo" />` : ''}
          <div class="company-name">${companyName || 'NOMBRE DE LA EMPRESA'}</div>
          <div class="company-info">
            ${companyNIT ? `NIT: ${companyNIT}<br>` : ''}
            ${companyConfig.address || 'Dirección'}<br>
            📞 ${companyConfig.phone || 'Teléfono'}
            ${companyConfig.email ? `<br>✉️ ${companyConfig.email}` : ''}
          </div>
        </div>
        <div class="invoice-badge">
          <div class="invoice-badge-title">Factura</div>
          <div class="invoice-number">#${sale.id}</div>
          <div style="font-size: 12px; margin-top: 8px;">${new Date().toLocaleDateString('es-CO')}</div>
        </div>
      </div>
    </div>
    
    <div class="info-section">
      <div class="info-box">
        <div class="info-box-title">Cliente</div>
        <div class="info-line">
          <span class="info-label">Nombre:</span>
          <span class="info-value">${clientName}</span>
        </div>
        ${clientDocument ? `<div class="info-line"><span class="info-label">Documento:</span><span class="info-value">${clientDocument}</span></div>` : ''}
        ${clientAddress ? `<div class="info-line"><span class="info-label">Dirección:</span><span class="info-value">${clientAddress}</span></div>` : ''}
        ${clientPhone ? `<div class="info-line"><span class="info-label">Teléfono:</span><span class="info-value">${clientPhone}</span></div>` : ''}
      </div>
      <div class="info-box">
        <div class="info-box-title">Detalles de Factura</div>
        <div class="info-line">
          <span class="info-label">Número:</span>
          <span class="info-value">${sale.id}</span>
        </div>
        <div class="info-line">
          <span class="info-label">Fecha:</span>
          <span class="info-value">${new Date().toLocaleDateString('es-CO')}</span>
        </div>
        <div class="info-line">
          <span class="info-label">Hora:</span>
          <span class="info-value">${new Date().toLocaleTimeString('es-CO')}</span>
        </div>
      </div>
    </div>
    
    <div class="items-section">
      <table class="items-table">
        <thead>
          <tr>
            <th>Descripción</th>
            <th>Cant.</th>
            <th>Precio Unit.</th>
            <th>Total</th>
          </tr>
        </thead>
        <tbody>
          ${sale.items.map(item => {
            const itemTotal = item.price * item.qty
            const discountAmount = item.discount || 0
            const finalTotal = itemTotal - discountAmount
            return `
          <tr>
            <td>
              <div class="item-name">${item.name}</div>
              ${item.reference ? `<div class="item-details">Ref: ${item.reference}</div>` : ''}
              ${discountAmount > 0 ? `<div class="item-discount">Descuento: -${formatCurrency(discountAmount)}</div>` : ''}
            </td>
            <td>${item.qty}</td>
            <td>${formatCurrency(item.price)}</td>
            <td><strong>${formatCurrency(finalTotal)}</strong></td>
          </tr>
            `
          }).join('')}
        </tbody>
      </table>
    </div>
    
    <div class="totals-section">
      <div class="totals-grid">
        ${(() => {
          const applyTax = companyConfig.applyTax === true
          const taxRate = companyConfig.taxRate || 19
          const taxDecimal = taxRate / 100
          const subtotalBeforeTax = total / (1 + taxDecimal)
          const taxAmount = total - subtotalBeforeTax
          const totalDiscounts = sale.items.reduce((acc, item) => acc + (item.discount || 0), 0)
          
          return `
        <div class="total-line">
          <span class="total-line-label">Subtotal:</span>
          <span class="total-line-value">${formatCurrency(subtotalBeforeTax)}</span>
        </div>
        ${applyTax ? `<div class="total-line"><span class="total-line-label">IVA (${taxRate}%):</span><span class="total-line-value">${formatCurrency(taxAmount)}</span></div>` : ''}
        ${totalDiscounts > 0 ? `<div class="total-line"><span class="total-line-label">Descuentos:</span><span class="total-line-value">-${formatCurrency(totalDiscounts)}</span></div>` : ''}
        <div class="total-final">
          <span class="total-final-label">Total a Pagar</span>
          <span class="total-final-value">${formatCurrency(total)}</span>
        </div>
          `
        })()}
      </div>
    </div>
    
    ${paymentMethod ? `
    <div class="payment-section">
      <div class="payment-title">Información de Pago</div>
      <div class="payment-grid">
        <div class="payment-item">
          <span class="payment-label">Método:</span>
          <span class="payment-value">${paymentName}</span>
        </div>
        ${paymentMethod === 'efectivo' ? `
        <div class="payment-item">
          <span class="payment-label">Recibido:</span>
          <span class="payment-value">${formatCurrency(received)}</span>
        </div>
        <div class="payment-item highlight">
          <span class="payment-label">Cambio:</span>
          <span class="payment-value">${formatCurrency(change)}</span>
        </div>
        ` : ''}
        ${sale.reference ? `
        <div class="payment-item">
          <span class="payment-label">Referencia:</span>
          <span class="payment-value">${sale.reference}</span>
        </div>
        ` : ''}
      </div>
    </div>
    ` : ''}
    
    ${companyConfig.invoiceFooter ? `<div style="padding: 20px 40px; text-align: center; color: #6c757d; font-size: 13px; border-top: 1px dashed #dee2e6;">${companyConfig.invoiceFooter}</div>` : ''}
    
    <div class="footer">
      <div class="footer-message">¡Gracias por su compra!</div>
      <div class="footer-info">${companyName || 'NOMBRE DE LA EMPRESA'} | ${companyConfig.address || ''}</div>
    </div>
  </div>
</body>
</html>`
                      } else {
                        // DISEÑO PARA TICKETS POS (80mm y 57mm)
                        const ticketWidth = format === 'ticket80' ? '80mm' : '57mm'
                        invoiceHTML = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Ticket ${sale.id}</title>
  <style>
    @page { size: ${ticketWidth} auto; margin: 0; }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { 
      font-family: 'Courier New', monospace; 
      width: ${ticketWidth};
      margin: 0;
      padding: 10px;
      font-size: ${format === 'ticket80' ? '11px' : '9px'};
    }
    .ticket { width: 100%; }
    .center { text-align: center; }
    .bold { font-weight: 700; }
    .large { font-size: ${format === 'ticket80' ? '16px' : '13px'}; }
    .medium { font-size: ${format === 'ticket80' ? '13px' : '11px'}; }
    .small { font-size: ${format === 'ticket80' ? '10px' : '8px'}; }
    .divider { 
      border-top: 1px dashed #000; 
      margin: 8px 0; 
    }
    .divider-solid { 
      border-top: 2px solid #000; 
      margin: 8px 0; 
    }
    .header {
      text-align: center;
      margin-bottom: 10px;
    }
    .logo {
      max-width: ${format === 'ticket80' ? '60px' : '50px'};
      margin: 0 auto 8px;
    }
    .company-name {
      font-size: ${format === 'ticket80' ? '18px' : '15px'};
      font-weight: 700;
      margin-bottom: 4px;
    }
    .info-line {
      margin: 3px 0;
      line-height: 1.4;
    }
    .section-title {
      font-weight: 700;
      margin: 10px 0 5px;
      text-transform: uppercase;
    }
    .item-row {
      margin: 6px 0;
    }
    .item-name {
      font-weight: 700;
    }
    .item-details {
      display: flex;
      justify-content: space-between;
      margin-top: 2px;
    }
    .total-row {
      display: flex;
      justify-content: space-between;
      margin: 5px 0;
    }
    .total-final {
      font-size: ${format === 'ticket80' ? '16px' : '13px'};
      font-weight: 700;
      margin: 10px 0;
      padding: 8px 0;
      border-top: 2px solid #000;
      border-bottom: 2px solid #000;
    }
    .footer {
      text-align: center;
      margin-top: 15px;
      font-size: ${format === 'ticket80' ? '10px' : '8px'};
    }
    @media print {
      body { padding: 5px; }
    }
  </style>
</head>
<body>
  <div class="ticket">
    <div class="header">
      ${companyLogo ? `<img src="${companyLogo}" class="logo" alt="Logo" />` : ''}
      <div class="company-name">${companyName || 'NOMBRE DE LA EMPRESA'}</div>
      ${companyNIT ? `<div class="small">NIT: ${companyNIT}</div>` : ''}
      <div class="small">${companyConfig.address || 'Dirección'}</div>
      <div class="small">Tel: ${companyConfig.phone || 'Teléfono'}</div>
      ${companyConfig.email ? `<div class="small">${companyConfig.email}</div>` : ''}
    </div>
    
    <div class="divider-solid"></div>
    
    <div class="center">
      <div class="medium bold">FACTURA DE VENTA</div>
      <div class="small">No. ${sale.id}</div>
      <div class="small">${new Date().toLocaleDateString('es-CO')} - ${new Date().toLocaleTimeString('es-CO')}</div>
    </div>
    
    <div class="divider"></div>
    
    <div class="section-title small">CLIENTE</div>
    <div class="info-line">${clientName}</div>
    ${clientDocument ? `<div class="info-line small">Doc: ${clientDocument}</div>` : ''}
    ${clientPhone ? `<div class="info-line small">Tel: ${clientPhone}</div>` : ''}
    
    <div class="divider"></div>
    
    <div class="section-title small">PRODUCTOS</div>
    ${sale.items.map(item => {
      const itemTotal = item.price * item.qty
      const discountAmount = item.discount || 0
      const finalTotal = itemTotal - discountAmount
      return `
    <div class="item-row">
      <div class="item-name">${item.name}</div>
      <div class="item-details small">
        <span>${item.qty} x ${formatCurrency(item.price)}</span>
        <span>${formatCurrency(finalTotal)}</span>
      </div>
      ${discountAmount > 0 ? `<div class="small" style="color: #666;">Desc: -${formatCurrency(discountAmount)}</div>` : ''}
    </div>
      `
    }).join('')}
    
    <div class="divider-solid"></div>
    
    ${(() => {
      const applyTax = companyConfig.applyTax === true
      const taxRate = companyConfig.taxRate || 19
      const taxDecimal = taxRate / 100
      const subtotalBeforeTax = total / (1 + taxDecimal)
      const taxAmount = total - subtotalBeforeTax
      const totalDiscounts = sale.items.reduce((acc, item) => acc + (item.discount || 0), 0)
      
      return `
    <div class="total-row">
      <span>Subtotal:</span>
      <span>${formatCurrency(subtotalBeforeTax)}</span>
    </div>
    ${applyTax ? `<div class="total-row"><span>IVA (${taxRate}%):</span><span>${formatCurrency(taxAmount)}</span></div>` : ''}
    ${totalDiscounts > 0 ? `<div class="total-row"><span>Descuentos:</span><span>-${formatCurrency(totalDiscounts)}</span></div>` : ''}
    <div class="total-row total-final">
      <span>TOTAL:</span>
      <span>${formatCurrency(total)}</span>
    </div>
      `
    })()}
    
    ${paymentMethod ? `
    <div class="divider"></div>
    <div class="section-title small">PAGO</div>
    <div class="total-row">
      <span>Método:</span>
      <span>${paymentName}</span>
    </div>
    ${paymentMethod === 'efectivo' ? `
    <div class="total-row">
      <span>Recibido:</span>
      <span>${formatCurrency(received)}</span>
    </div>
    <div class="total-row bold">
      <span>Cambio:</span>
      <span>${formatCurrency(change)}</span>
    </div>
    ` : ''}
    ${sale.reference ? `<div class="total-row small"><span>Ref:</span><span>${sale.reference}</span></div>` : ''}
    ` : ''}
    
    ${companyConfig.invoiceFooter ? `<div class="divider"></div><div class="center small">${companyConfig.invoiceFooter}</div>` : ''}
    
    <div class="divider"></div>
    
    <div class="footer">
      <div class="bold">¡GRACIAS POR SU COMPRA!</div>
      <div>${companyName || 'NOMBRE DE LA EMPRESA'}</div>
      <div>Vuelva pronto</div>
    </div>
  </div>
</body>
</html>`
                      }
                      
                      // NO abrir diálogo de impresión - solo guardar la factura
                      // La impresión se manejará desde el backend o desde Archives
                      const companyConfigForPrint = JSON.parse(localStorage.getItem('pos_company_config') || '{}')
                      const printerName = companyConfigForPrint.printerName || ''
                      
                      console.log('Factura generada. Impresora configurada:', printerName)
                      // No llamar a window.print() para evitar el diálogo
                      
                      // Guardar factura en el servidor
                      fetch('http://localhost:4000/save-invoice', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ id: sale.id, html: invoiceHTML })
                      })
                      .then(res => res.json())
                      .then(data => {
                        if (data.ok) console.log('Factura guardada:', data.htmlUrl)
                      })
                      .catch(err => console.warn('Error:', err))
                      
                      // Guardar factura en localStorage para Archives
                      const invoiceData = {
                        id: sale.id,
                        saleId: sale.id,
                        html: invoiceHTML,
                        format: invoiceFormat,
                        createdAt: new Date().toISOString(),
                      }
                      
                      // Obtener facturas existentes y agregar la nueva
                      try {
                        const existingInvoices = JSON.parse(localStorage.getItem('pos_invoices') || '[]')
                        // Verificar si ya existe
                        if (!existingInvoices.find((inv: any) => inv.id === sale.id)) {
                          existingInvoices.push(invoiceData)
                          localStorage.setItem('pos_invoices', JSON.stringify(existingInvoices))
                          console.log('[Sales] Factura guardada:', sale.id, 'Total facturas:', existingInvoices.length)
                          
                          // === IMPRIMIR Y GUARDAR SEGÚN CONFIGURACIÓN ===
                          const filename = `factura_${sale.id}_${Date.now()}.html`
                          const companyConfig = JSON.parse(localStorage.getItem('pos_company_config') || '{}')
                          
                          if (window.electronAPI) {
                            // Verificar configuración de impresión
                            const shouldAutoPrint = companyConfig.autoPrint === true
                            const shouldSaveToFolder = companyConfig.saveToFolder !== false // Default true
                            
                            if (shouldAutoPrint && shouldSaveToFolder) {
                              // Imprimir Y guardar en carpeta
                              window.electronAPI.printAndSaveInvoice(filename, invoiceHTML)
                                .then(result => {
                                  if (result.success) {
                                    console.log('[Sales] Factura impresa y guardada en:', result.path)
                                  }
                                })
                                .catch(err => console.warn('[Sales] Error:', err))
                            } else if (shouldAutoPrint) {
                              // Solo imprimir
                              window.electronAPI.printInvoice(invoiceHTML)
                                .then(result => {
                                  if (result.success) {
                                    console.log('[Sales] Factura impresa')
                                  }
                                })
                                .catch(err => console.warn('[Sales] Error:', err))
                            } else if (shouldSaveToFolder) {
                              // Solo guardar en carpeta
                              window.electronAPI.saveInvoiceToFolder(filename, invoiceHTML)
                                .then(result => {
                                  if (result.success) {
                                    console.log('[Sales] Factura guardada en:', result.path)
                                  }
                                })
                                .catch(err => console.warn('[Sales] Error:', err))
                            }
                          } else {
                            // Si estamos en navegador, solo mostrar mensaje
                            console.log('[Sales] Ejecute en Electron para imprimir/guardar automáticamente')
                          }
                          // ============================================
                          
                          // Emitir evento para actualizar Archives en tiempo real
                          try {
                            invoiceEventEmitter.emit('invoice-added')
                          } catch (e) {
                            console.warn('[Sales] Error emitiendo evento:', e)
                          }
                        } else {
                          console.log('[Sales] Factura ya existe:', sale.id)
                        }
                      } catch (e) {
                        console.warn('[Sales] Error guardando factura:', e)
                      }
                      
                      try {
                        // Limpiar el carrito
                        clearCart()
                        // Limpiar el carrito
         clearCart()
         // Reiniciar selector a opción por defecto
                        setSelectedClient('')
                        setSelectedClientName(null)
                        setAmountReceived('')
                        setAmountReceivedRaw('')
                        setPaymentMethod('efectivo') // Resetear a efectivo
                        setShowPaymentModal(false)
                      } catch (e) {}
                    }
                  }}
                  style={{
                    padding: '8px 16px',
                    background: 'var(--accent)',
                    color: 'white',
                    border: 'none',
                    borderRadius: '6px',
                    cursor: 'pointer',
                    fontSize: '14px',
                    fontWeight: '600'
                  }}
                >
                  💰 Cobrar
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal de Devolución de Productos - Diseño Moderno */}
        {showReturnModal && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: isLight ? '#f5f5f5' : '#1a1a2e',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 1001
          }}>
            <div style={{
              background: 'linear-gradient(145deg, var(--card) 0%, var(--card-bg) 100%)',
              padding: '32px',
              borderRadius: '20px',
              border: isLight ? '1px solid rgba(0,0,0,0.1)' : '1px solid rgba(255,255,255,0.08)',
              boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)',
              maxWidth: '700px',
              width: '90%',
              maxHeight: '85vh',
              overflowY: 'auto'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '24px' }}>
                <div style={{ 
                  width: '48px', 
                  height: '48px', 
                  borderRadius: '14px', 
                  background: 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '24px'
                }}>
                  ↩️
                </div>
                <div>
                  <h3 style={{ margin: '0', color: 'var(--text)', fontSize: '22px', fontWeight: '700', letterSpacing: '-0.5px' }}>Devolver Productos</h3>
                  <p style={{ margin: '2px 0 0 0', color: 'var(--muted)', fontSize: '13px' }}>Selecciona los productos a devolver</p>
                </div>
              </div>
              
              <div style={{ marginBottom: '20px' }}>
                {(() => {
                  // Obtener el nombre del cliente
                  const client = clients.find(c => c.id === selectedClient);
                  const clientName = client?.name;
                  
                  if (!clientName) {
                    return <p style={{ color: 'var(--danger)' }}>⚠️ No hay cliente seleccionado. Selecciona uno para ver sus compras.</p>;
                  }

                  // Filtrar ventas del cliente
                  const clientSales = salesHistory.filter(sale => {
                    return sale.client.toLowerCase().trim() === clientName.toLowerCase().trim();
                  });
                  
                  if (clientSales.length === 0) {
                    return (
                      <div>
                        <p style={{ color: 'var(--warning)', marginBottom: '12px' }}>
                          ℹ️ No se encontraron ventas para <strong>{clientName}</strong>
                        </p>
                        <p style={{ color: 'var(--muted)', fontSize: '12px' }}>
                          Total de ventas en el sistema: {salesHistory.length}
                        </p>
                        {salesHistory.length > 0 && (
                          <details style={{ marginTop: '12px', color: 'var(--muted)', fontSize: '11px' }}>
                            <summary style={{ cursor: 'pointer', color: 'var(--accent)' }}>Ver todas las ventas</summary>
                            <div style={{ marginTop: '8px', maxHeight: '200px', overflowY: 'auto', background: 'var(--bg)', padding: '8px', borderRadius: '4px' }}>
                              {salesHistory.map(s => (
                                <div key={s.id} style={{ padding: '4px', borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
                                  {s.id}: {s.client}
                                </div>
                              ))}
                            </div>
                          </details>
                        )}
                      </div>
                    );
                  }

                  return (
                    <>
                      <p style={{ color: 'var(--success)', fontSize: '14px', marginBottom: '16px' }}>
                        ✅ Encontradas {clientSales.length} venta(s) para {clientName}
                      </p>
                      <p style={{ color: 'var(--muted)', fontSize: '12px', marginBottom: '16px' }}>Selecciona productos para devolver:</p>
                      {clientSales.map((sale) => (
                        <div key={sale.id} style={{
                          marginBottom: '16px',
                          padding: '12px',
                          background: 'var(--card-bg)',
                          borderRadius: '8px',
                          border: '1px solid var(--border-color)'
                        }}>
                          <p style={{ margin: '0 0 8px 0', color: 'var(--text)', fontWeight: 'bold', fontSize: '13px' }}>
                            📄 {sale.id} - {new Date(sale.date).toLocaleDateString()}
                          </p>
                          {sale.items.length === 0 ? (
                            <p style={{ color: 'var(--muted)', fontSize: '12px' }}>Sin productos</p>
                          ) : (
                            sale.items
                              .filter(item => {
                                // Filtrar solo productos no completamente devueltos
                                const itemKey = `${sale.id}|${item.productId}`;
                                const returnedQty = returnedItems[itemKey] || 0;
                                return returnedQty < item.qty;
                              })
                              .map((item) => {
                                const itemKey = `${sale.id}|${item.productId}`;
                                const isSelected = selectedReturnItems.has(itemKey);
                                const quantity = returnQuantities[itemKey] || 0;
                                const returnedQty = returnedItems[itemKey] || 0;
                                const remainingQty = item.qty - returnedQty;
                                
                                return (
                                <div key={item.productId} style={{
                                  display: 'flex',
                                  justifyContent: 'space-between',
                                  alignItems: 'center',
                                  padding: '12px',
                                  marginBottom: '8px',
                                  background: isSelected ? 'rgba(59, 130, 246, 0.15)' : 'var(--bg)',
                                  borderRadius: '6px',
                                  border: isSelected ? '2px solid var(--accent)' : '1px solid rgba(255,255,255,0.2)',
                                  cursor: 'pointer',
                                  transition: 'all 0.2s'
                                }}
                                onClick={() => {
                                  const newSelected = new Set(selectedReturnItems);
                                  if (newSelected.has(itemKey)) {
                                    newSelected.delete(itemKey);
                                    setReturnQuantities(prev => ({
                                      ...prev,
                                      [itemKey]: 0
                                    }));
                                  } else {
                                    newSelected.add(itemKey);
                                    setReturnQuantities(prev => ({
                                      ...prev,
                                      [itemKey]: 1
                                    }));
                                  }
                                  setSelectedReturnItems(newSelected);
                                }}>
                                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flex: 1 }}>
                                    <input
                                      type="checkbox"
                                      checked={isSelected}
                                      onChange={() => {}}
                                      style={{
                                        width: '20px',
                                        height: '20px',
                                        cursor: 'pointer',
                                        accentColor: 'var(--success)'
                                      }}
                                      onClick={(e) => e.stopPropagation()}
                                    />
                                    <div style={{ flex: 1 }}>
                                      <p style={{ margin: '0 0 2px 0', color: 'var(--text)', fontSize: '13px', fontWeight: isSelected ? '700' : '500' }}>{item.name}</p>
                                      <p style={{ margin: 0, color: 'var(--muted)', fontSize: '11px' }}>
                                        Disponible: {remainingQty} {returnedQty > 0 && `(${returnedQty} ya devueltos)`}
                                      </p>
                                    </div>
                                  </div>
                                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                    <input
                                      type="number"
                                      min="0"
                                      max={remainingQty}
                                      value={quantity}
                                      onChange={(e) => {
                                        const val = Math.min(parseInt(e.target.value) || 0, remainingQty);
                                        setReturnQuantities(prev => ({
                                          ...prev,
                                          [itemKey]: Math.max(0, val)
                                        }));
                                        if (val > 0 && !selectedReturnItems.has(itemKey)) {
                                          setSelectedReturnItems(prev => new Set([...prev, itemKey]));
                                        }
                                      }}
                                      style={{
                                        width: '60px',
                                        padding: '6px 8px',
                                        background: 'var(--card-bg)',
                                        color: 'var(--text)',
                                        border: '2px solid var(--accent)',
                                        borderRadius: '6px',
                                        fontSize: '13px',
                                        fontWeight: '600',
                                        cursor: 'text',
                                        WebkitAppearance: 'none',
                                        MozAppearance: 'textfield',
                                        outline: 'none'
                                      }}
                                      onClick={(e) => e.stopPropagation()}
                                    />
                                    <span style={{ color: 'var(--muted)', minWidth: '25px', textAlign: 'right', fontSize: '12px' }}>
                                      / {remainingQty}
                                    </span>
                                  </div>
                                </div>
                              );
                              })
                          )}
                        </div>
                      ))}
                    </>
                  );
                })()}
              </div>

              <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end' }}>
                <button
                  onClick={() => {
                    setShowReturnModal(false);
                    setReturnQuantities({});
                    setSelectedReturnItems(new Set());
                  }}
                  style={{
                    padding: '10px 20px',
                    background: '#dc2626',
                    color: 'white',
                    border: 'none',
                    borderRadius: '6px',
                    cursor: 'pointer',
                    fontSize: '14px',
                    fontWeight: 'bold',
                    transition: 'all 0.2s ease'
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.background = '#b91c1c'}
                  onMouseLeave={(e) => e.currentTarget.style.background = '#dc2626'}
                >
                  Cancelar
                </button>
                <button
                  onClick={() => {
                    console.log('returnQuantities:', returnQuantities);
                    // Procesar devolución
                    const returnItems: Array<{ productId: string; name: string; qty: number }> = [];
                    const updatedProducts = [...products];
                    const updatedReturnedItems = { ...returnedItems };

                    Object.entries(returnQuantities).forEach(([key, qty]) => {
                      console.log(`Processing key: ${key}, qty: ${qty}`);
                      if (qty > 0) {
                        const parts = key.split('|');
                        const saleId = parts[0];
                        const productId = parts[1];
                        console.log(`saleId: ${saleId}, productId: ${productId}`);
                        
                        const sale = salesHistory.find(s => s.id === saleId);
                        console.log('sale:', sale);
                        const item = sale?.items.find(i => i.productId === productId);
                        console.log('item:', item);
                        
                        if (item) {
                          returnItems.push({ productId, name: item.name, qty });
                          
                          // Actualizar stock
                          const productIndex = updatedProducts.findIndex(p => p.id === productId);
                          if (productIndex !== -1) {
                            updatedProducts[productIndex] = {
                              ...updatedProducts[productIndex],
                              stock: updatedProducts[productIndex].stock + qty
                            };
                          }

                          // Registrar devolución
                          const currentReturned = updatedReturnedItems[key] || 0;
                          updatedReturnedItems[key] = currentReturned + qty;
                        }
                      }
                    });

                    console.log('returnItems:', returnItems);

                    if (returnItems.length === 0) {
                      alert('Selecciona al menos un producto para devolver');
                      return;
                    }

                    // Guardar cambios de stock
                    setProducts(updatedProducts);
                    localStorage.setItem('products', JSON.stringify(updatedProducts));

                    // Guardar devoluciones registradas
                    setReturnedItems(updatedReturnedItems);
                    localStorage.setItem('returnedItems', JSON.stringify(updatedReturnedItems));

                    // Crear resumen
                    const returnSummary = returnItems
                      .map(item => `${item.qty} x ${item.name}`)
                      .join('\n');

                    alert(`✅ Devolución registrada:\n\n${returnSummary}\n\nEl stock ha sido actualizado.`);
                    
                    setShowReturnModal(false);
                    setReturnQuantities({});
                    setSelectedReturnItems(new Set());
                  }}
                  style={{
                    padding: '10px 20px',
                    background: 'var(--success)',
                    color: 'white',
                    border: 'none',
                    borderRadius: '6px',
                    cursor: 'pointer',
                    fontSize: '14px',
                    fontWeight: '600'
                  }}
                >
                  ✅ Confirmar Devolución
                </button>
              </div>
            </div>
          </div>
        )}

      {/* Modal Descuentos */}
      {showDiscountModal && selectedProductForDiscount && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 9999
        }}>
          <div style={{
            background: 'var(--card-bg)',
            border: '1px solid var(--border-color)',
            borderRadius: 8,
            padding: 20,
            maxWidth: '400px',
            width: '90%'
          }}>
            <h3 style={{ margin: '0 0 16px 0', color: 'var(--text)' }}>🏷️ Aplicar Descuento</h3>
            
            {/* Tabs: Porcentaje / Valor */}
            <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
              <button 
                onClick={() => setDiscountMode('percentage')}
                style={{
                  flex: 1,
                  padding: '10px',
                  background: discountMode === 'percentage' ? 'var(--accent)' : 'rgba(255,255,255,0.1)',
                  color: 'var(--text)',
                  border: 'none',
                  borderRadius: 4,
                  cursor: 'pointer',
                  fontWeight: discountMode === 'percentage' ? 700 : 400
                }}
              >
                📊 Porcentaje (%)
              </button>
              <button 
                onClick={() => setDiscountMode('fixed')}
                style={{
                  flex: 1,
                  padding: '10px',
                  background: discountMode === 'fixed' ? 'var(--accent)' : 'rgba(255,255,255,0.1)',
                  color: 'var(--text)',
                  border: 'none',
                  borderRadius: 4,
                  cursor: 'pointer',
                  fontWeight: discountMode === 'fixed' ? 700 : 400
                }}
              >
                💵 Valor ($)
              </button>
            </div>

            {/* Input descuento */}
            <div style={{ marginBottom: 16 }}>
              <label style={{ display: 'block', marginBottom: 8, color: 'var(--muted)', fontSize: 12, fontWeight: 600 }}>
                {discountMode === 'percentage' ? '📊 Porcentaje de descuento (%)' : '💵 Valor de descuento ($)'}
              </label>
              <input
                type="text"
                inputMode="numeric"
                value={discountMode === 'fixed' ? formatNumberWithDots(discountAmount) : discountAmount}
                onChange={(e) => {
                  if (discountMode === 'percentage') {
                    setDiscountAmount(e.target.value.replace(/[^0-9.]/g, ''))
                  } else {
                    const rawValue = e.target.value.replace(/\D/g, '')
                    setDiscountAmount(rawValue)
                  }
                }}
                placeholder={discountMode === 'percentage' ? '10' : '5.000'}
                style={{
                  width: '100%',
                  padding: '10px',
                  border: '2px solid rgba(59, 130, 246, 0.5)',
                  borderRadius: 4,
                  background: 'var(--card)',
                  color: 'var(--text)',
                  fontSize: 14,
                  boxSizing: 'border-box'
                }}
              />
              {/* Preview del cálculo */}
              {discountAmount && (() => {
                const item = cart.find(i => i.productId === selectedProductForDiscount)
                if (!item) return null
                const originalPrice = item.originalPrice || item.price
                const totalProducto = originalPrice * item.qty
                const amount = parseFloat(discountAmount)
                if (isNaN(amount)) return null
                
                let preview = ''
                let warning = ''
                let isValid = true
                
                if (discountMode === 'percentage') {
                  const descuentoMonto = (originalPrice * amount) / 100
                  const descuentoTotal = descuentoMonto * item.qty
                  const precioFinal = originalPrice - descuentoMonto
                  preview = `Precio unitario: $${originalPrice.toLocaleString('es-CO')} → -$${descuentoMonto.toLocaleString('es-CO', {minimumFractionDigits: 0})} = $${precioFinal.toLocaleString('es-CO', {minimumFractionDigits: 0})}\nDescuento total: -$${descuentoTotal.toLocaleString('es-CO', {minimumFractionDigits: 0})} en ${item.qty} unidades`
                } else {
                  // Descuento fijo: se aplica directamente al precio unitario
                  if (amount > originalPrice) {
                    warning = `⚠️ Supera el precio unitario ($${originalPrice.toLocaleString('es-CO')})`
                    isValid = false
                  }
                  const precioFinal = originalPrice - amount
                  const descuentoTotal = amount * item.qty
                  preview = `Precio unitario: $${originalPrice.toLocaleString('es-CO')} → -$${amount.toLocaleString('es-CO')} = $${precioFinal.toLocaleString('es-CO')}\nTotal: $${precioFinal.toLocaleString('es-CO')} × ${item.qty} unidades = $${(precioFinal * item.qty).toLocaleString('es-CO', {minimumFractionDigits: 0})}\nDescuento total: -$${descuentoTotal.toLocaleString('es-CO', {minimumFractionDigits: 0})}`
                }
                return (
                  <div style={{ marginTop: 8, fontSize: 12, color: isValid ? 'var(--accent)' : 'var(--danger)', padding: '8px', background: isValid ? 'rgba(59, 130, 246, 0.1)' : 'rgba(220, 38, 38, 0.1)', borderRadius: 4, fontWeight: 500, whiteSpace: 'pre-line', lineHeight: 1.5 }}>
                    {preview}
                    {warning && <div style={{ marginTop: 6, color: isValid ? 'var(--success)' : 'var(--danger)', fontWeight: 600 }}>{warning}</div>}
                  </div>
                )
              })()}
            </div>

            {/* Botones */}
            <div style={{ display: 'flex', gap: 8 }}>
              <button
                onClick={() => {
                  handleApplyDiscount()
                  setShowDiscountModal(false)
                }}
                style={{
                  flex: 1,
                  padding: '10px',
                  background: 'var(--success)',
                  color: 'white',
                  border: 'none',
                  borderRadius: 4,
                  cursor: 'pointer',
                  fontWeight: 600
                }}
              >
                ✅ Aplicar
              </button>
              <button
                onClick={() => {
                  // Eliminar descuento existente
                  applyDiscount(selectedProductForDiscount, 0, 'fixed')
                  setShowDiscountModal(false)
                  setDiscountAmount('')
                  setDiscountMode('fixed')
                }}
                style={{
                  flex: 1,
                  padding: '10px',
                  background: '#FF9800',
                  color: 'white',
                  border: 'none',
                  borderRadius: 4,
                  cursor: 'pointer',
                  fontWeight: 600
                }}
              >
                🗑️ Eliminar
              </button>
              <button
                onClick={() => {
                  setShowDiscountModal(false)
                  setDiscountAmount('')
                  setDiscountMode('fixed')
                }}
                style={{
                  flex: 1,
                  padding: '10px',
                  background: '#dc2626',
                  color: 'white',
                  border: 'none',
                  borderRadius: 4,
                  cursor: 'pointer',
                  fontWeight: 'bold'
                }}
              >
                ❌ Cancelar
              </button>
            </div>
            <div style={{ fontSize: '12px', color: 'var(--muted)', marginTop: '12px', padding: '8px', background: 'rgba(255,255,255,0.05)', borderRadius: 4, borderLeft: '3px solid var(--accent)' }}>
              {(() => {
                const product = cart.find(item => item.productId === selectedProductForDiscount)
                if (!product) return ''
                const original = product.originalPrice || product.price
                const total = original * product.qty
                return `💰 Precio unitario: ${formatCurrency(original)} | Cantidad: ${product.qty} | Total del producto: ${formatCurrency(total)}`
              })()}
            </div>
          </div>
        </div>
      )}

      {/* Modal de Deuda - Diseño Moderno */}
      {showDebtModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: isLight ? '#f5f5f5' : '#1a1a2e',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div onClick={e => e.stopPropagation()} style={{ 
            background: 'linear-gradient(145deg, var(--card) 0%, var(--card-bg) 100%)',
            padding: '32px',
            borderRadius: '20px',
            border: isLight ? '1px solid rgba(0,0,0,0.1)' : '1px solid rgba(255,255,255,0.08)',
            boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)',
            maxWidth: '480px',
            width: '90%'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
              <div style={{ 
                width: '48px', 
                height: '48px', 
                borderRadius: '14px', 
                background: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '24px'
              }}>
                💳
              </div>
              <div>
                <h4 style={{ margin: '0', color: 'var(--text)', fontSize: '22px', fontWeight: '700', letterSpacing: '-0.5px' }}>Venta a Crédito</h4>
                <p style={{ margin: '2px 0 0 0', color: 'var(--muted)', fontSize: '13px' }}>Registra esta deuda del cliente</p>
              </div>
            </div>

            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', marginBottom: '10px', color: 'var(--text)', fontSize: '14px', fontWeight: '600' }}>
                📊 Monto de la Deuda
              </label>
              <div style={{ position: 'relative' }}>
                <span style={{
                  position: 'absolute',
                  left: '16px',
                  top: '50%',
                  transform: 'translateY(-50%)',
                  color: 'var(--muted)',
                  fontSize: '16px',
                  fontWeight: '600'
                }}>$</span>
                <input
                  type="text"
                  value={debtAmount}
                  onChange={e => setDebtAmount(e.target.value)}
                  placeholder="0"
                  style={{
                    width: '100%',
                    padding: '14px 16px 14px 36px',
                    border: '2px solid rgba(255,255,255,0.1)',
                    borderRadius: '12px',
                    background: 'var(--bg)',
                    color: 'var(--text)',
                    fontSize: '18px',
                    fontWeight: '600',
                    boxSizing: 'border-box',
                    textAlign: 'right',
                    transition: 'all 0.2s ease'
                  }}
                  onFocus={(e) => e.target.style.borderColor = '#f59e0b'}
                  onBlur={(e) => e.target.style.borderColor = 'rgba(255,255,255,0.1)'}
                />
              </div>
            </div>

            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', marginBottom: '10px', color: 'var(--text)', fontSize: '14px', fontWeight: '600' }}>
                📝 Motivo (opcional)
              </label>
              <textarea
                value={debtReason}
                onChange={e => setDebtReason(e.target.value)}
                placeholder="Describe el motivo de la deuda..."
                rows={3}
                style={{
                  width: '100%',
                  padding: '14px 16px',
                  border: '2px solid rgba(255,255,255,0.1)',
                  borderRadius: '12px',
                  background: 'var(--bg)',
                  color: 'var(--text)',
                  fontSize: '14px',
                  boxSizing: 'border-box',
                  resize: 'vertical',
                  transition: 'all 0.2s ease',
                  fontFamily: 'inherit'
                }}
                onFocus={(e) => e.target.style.borderColor = '#f59e0b'}
                onBlur={(e) => e.target.style.borderColor = 'rgba(255,255,255,0.1)'}
              />
            </div>

            <div style={{ 
              background: isLight ? '#ecfdf5' : '#065f46', 
              borderRadius: '14px', 
              padding: '16px 20px', 
              marginBottom: '24px',
              border: '1px solid rgba(16, 185, 129, 0.2)'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                <span style={{ color: 'var(--muted)', fontSize: '12px', fontWeight: '500', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Cliente</span>
                <span style={{ color: 'var(--text)', fontSize: '14px', fontWeight: '600' }}>{clients.find(c => c.id === selectedClient)?.name || 'No seleccionado'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ color: 'var(--muted)', fontSize: '12px', fontWeight: '500', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Total del carrito</span>
                <span style={{ color: 'var(--accent)', fontSize: '18px', fontWeight: '700' }}>{formatCurrency(calculateTotal().total)}</span>
              </div>
            </div>

            <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end' }}>
              <button
                onClick={() => {
                  setShowDebtModal(false)
                  setDebtAmount('')
                  setDebtReason('')
                }}
                style={{
                  padding: '12px 24px',
                  background: '#dc2626',
                  color: 'white',
                  border: 'none',
                  borderRadius: '8px',
                  cursor: 'pointer',
                  fontWeight: 'bold',
                  fontSize: '14px',
                  transition: 'all 0.2s ease'
                }}
                onMouseEnter={(e) => (e.target as HTMLElement).style.background = '#b91c1c'}
                onMouseLeave={(e) => (e.target as HTMLElement).style.background = '#dc2626'}
              >
                ❌ Cancelar
              </button>
              <button
                onClick={() => {
                  if (!debtAmount || parseFloat(debtAmount.replace(/[^0-9]/g, '')) <= 0) {
                    alert('Por favor ingresa un monto válido');
                    return;
                  }
                  
                  const sale = completeSale(selectedClient);
                  if (sale) {
                    // Aquí podrías guardar la deuda en un sistema separado
                    // Por ahora, solo completamos la venta
                    alert(`✅ Venta registrada como deuda:\n\nFactura: ${sale.id}\nMonto: ${debtAmount}\nCliente: ${clients.find(c => c.id === selectedClient)?.name}\nMotivo: ${debtReason || 'No especificado'}`);
                    
                    // Limpiar
                    setShowDebtModal(false);
                    setDebtAmount('');
                    setDebtReason('');
                    clearCart();
                  }
                }}
                style={{
                  padding: '10px 20px',
                  background: 'var(--success)',
                  color: 'white',
                  border: 'none',
                  borderRadius: 4,
                  cursor: 'pointer',
                  fontWeight: 600
                }}
              >
                ✅ Confirmar Deuda
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
    </div>
  )
}






