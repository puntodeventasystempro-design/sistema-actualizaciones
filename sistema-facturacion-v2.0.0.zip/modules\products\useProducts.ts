import { useState, useEffect, useMemo } from 'react'
import { Product } from '../common/types'
import { saveToVirtualFile, loadFromVirtualFile, exportModuleData } from '../common/utils'

const PRODUCTS_KEY = 'pos_products'
const CATEGORIES_KEY = 'pos_categories'
const PROVIDERS_KEY = 'pos_providers'
const MODULE_NAME = 'products'

// Datos de prueba - Categorías iniciales
const CATEGORIAS_INICIALES: string[] = []

// Datos de prueba - Proveedores iniciales
const PROVEEDORES_INICIALES: string[] = []

// Función simple para formatear moneda
const formatCurrency = (value: number): string => {
  return new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', minimumFractionDigits: 0 }).format(value)
}

// Tipo helper para el formulario
interface ProductFormData {
  name: string
  price: number | string
  stock: number | string
  category: string
  costPrice: number | string
  provider: string
  image?: string | null
}

// Datos de prueba
const PRODUCTOS_PRUEBA: Product[] = []

export function useProducts() {
  const [products, setProducts] = useState<Product[]>(() => {
    // Intentar cargar desde archivo virtual primero
    const fromFile = loadFromVirtualFile<Product[]>(MODULE_NAME, 'products.json')
    if (fromFile && Array.isArray(fromFile) && fromFile.length > 0) {
      return fromFile
    }
    // Luego intentar localStorage
    try {
      const saved = localStorage.getItem(PRODUCTS_KEY)
      if (saved) {
        const parsed = JSON.parse(saved)
        if (Array.isArray(parsed)) {
          return parsed
        }
      }
    } catch (e) {
      console.log('Error al cargar productos desde localStorage')
    }
    // Iniciar con lista vacía (no cargar datos de prueba automáticamente)
    return []
  })

  // Persistir cambios en archivo virtual y localStorage
  useEffect(() => {
    // Debounce persist to avoid UI freezes when products change rápidamente
    let timer: number | undefined
    try {
      if ((window as any).requestIdleCallback) {
        // Prefer requestIdleCallback when esté disponible
        const id = (window as any).requestIdleCallback(() => {
          saveToVirtualFile(MODULE_NAME, 'products.json', products)
          localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products))
        }, { timeout: 500 })
        // Guardar id para poder limpiar si es necesario
        timer = id
      } else {
        // Fallback: debounce con setTimeout
        timer = window.setTimeout(() => {
          saveToVirtualFile(MODULE_NAME, 'products.json', products)
          localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products))
        }, 250)
      }
    } catch (e) {
      try { localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products)) } catch {}
    }

    return () => {
      try {
        if ((window as any).cancelIdleCallback && typeof timer === 'number') {
          (window as any).cancelIdleCallback(timer)
        } else if (timer) {
          clearTimeout(timer)
        }
      } catch {}
    }
  }, [products])

  // Escuchar actualizaciones de stock desde otros componentes (ventas)
  useEffect(() => {
    const handleProductsUpdate = (event: Event) => {
      const customEvent = event as CustomEvent<Product[]>
      const updatedProducts = customEvent.detail
      if (updatedProducts && Array.isArray(updatedProducts)) {
        setProducts(updatedProducts)
      }
    }
    window.addEventListener('products-updated', handleProductsUpdate)
    return () => window.removeEventListener('products-updated', handleProductsUpdate)
  }, [])

  // ==================== Categorías ====================
  const [categories, setCategories] = useState<string[]>(() => {
    // Intentar cargar desde archivo virtual primero
    const fromFile = loadFromVirtualFile<string[]>(MODULE_NAME, 'categories.json')
    if (fromFile && Array.isArray(fromFile)) {
      return fromFile
    }
    // Luego intentar localStorage
    const saved = localStorage.getItem(CATEGORIES_KEY)
    if (saved) {
      try {
        const parsed = JSON.parse(saved)
        if (Array.isArray(parsed) && parsed.length > 0) return parsed
      } catch {}
    }
    return CATEGORIAS_INICIALES
  })

  useEffect(() => {
    saveToVirtualFile(MODULE_NAME, 'categories.json', categories)
    localStorage.setItem(CATEGORIES_KEY, JSON.stringify(categories))
  }, [categories])

  const addCategory = (category: string) => {
    const trimmed = category.trim()
    if (!trimmed || categories.includes(trimmed)) return trimmed
    setCategories(prev => [...prev, trimmed])
    return trimmed
  }

  const removeCategory = (category: string) => {
    setCategories(prev => prev.filter(c => c !== category))
  }

  // ==================== Proveedores ====================
  const [providers, setProviders] = useState<string[]>(() => {
    // Intentar cargar desde archivo virtual primero
    const fromFile = loadFromVirtualFile<string[]>(MODULE_NAME, 'providers.json')
    if (fromFile && Array.isArray(fromFile)) {
      return fromFile
    }
    // Luego intentar localStorage
    const saved = localStorage.getItem(PROVIDERS_KEY)
    if (saved) {
      try {
        const parsed = JSON.parse(saved)
        if (Array.isArray(parsed) && parsed.length > 0) return parsed
      } catch {}
    }
    return PROVEEDORES_INICIALES
  })

  useEffect(() => {
    saveToVirtualFile(MODULE_NAME, 'providers.json', providers)
    localStorage.setItem(PROVIDERS_KEY, JSON.stringify(providers))
  }, [providers])

  const addProvider = (provider: string) => {
    const trimmed = provider.trim()
    if (!trimmed || providers.includes(trimmed)) return trimmed
    setProviders(prev => [...prev, trimmed])
    return trimmed
  }

  const removeProvider = (provider: string) => {
    setProviders(prev => prev.filter(p => p !== provider))
  }

  // ==================== CRUD Operations ====================

  // Función para migrar IDs existentes al nuevo formato
  const migrateProductIds = () => {
    const sortedProducts = [...products].sort((a, b) => {
      // Primero los que ya tienen el formato correcto
      const aMatch = a.id.match(/^PRD-(\d+)$/)
      const bMatch = b.id.match(/^PRD-(\d+)$/)
      if (aMatch && !bMatch) return -1
      if (!aMatch && bMatch) return 1
      if (aMatch && bMatch) return parseInt(aMatch[1]) - parseInt(bMatch[1])
      return a.name.localeCompare(b.name)
    })
    
    let counter = 1
    const migratedProducts = sortedProducts.map(product => {
      const match = product.id.match(/^PRD-(\d+)$/)
      if (match) {
        // Ya tiene el formato correcto
        counter = Math.max(counter, parseInt(match[1]) + 1)
        return product
      }
      // Asignar nuevo ID
      const newId = `PRD-${counter.toString().padStart(3, '0')}`
      counter++
      return { ...product, id: newId }
    })
    
    setProducts(migratedProducts)
    return migratedProducts
  }

  const addProduct = (product: ProductFormData) => {
    // Obtener todos los IDs numéricos existentes
    const existingIds = products.map(p => {
      const match = p.id.match(/^PRD-(\d+)$/)
      return match ? parseInt(match[1]) : 0
    }).filter(id => id > 0).sort((a, b) => a - b)
    
    // Buscar el primer ID faltante en la secuencia
    let newIdNumber = 1
    for (let i = 0; i < existingIds.length; i++) {
      if (existingIds[i] !== i + 1) {
        newIdNumber = i + 1
        break
      }
    }
    // Si no hay huecos, usar el siguiente número
    if (newIdNumber === 1 && existingIds.length > 0) {
      newIdNumber = existingIds[existingIds.length - 1] + 1
    }
    
    const newId = `PRD-${newIdNumber.toString().padStart(3, '0')}`
    
    const newProduct: Product = {
      id: newId,
      name: product.name,
      price: typeof product.price === 'string' ? parseInt(product.price.replace(/\D/g, '')) || 0 : product.price,
      stock: typeof product.stock === 'string' ? parseInt(product.stock.replace(/\D/g, '')) || 0 : product.stock,
      category: product.category || undefined,
      costPrice: typeof product.costPrice === 'string' ? parseInt(product.costPrice.replace(/\D/g, '')) || 0 : product.costPrice,
      provider: product.provider || undefined,
      image: product.image || undefined,
    }
    
    // Agregar y ordenar alfabéticamente por nombre
    setProducts(prev => [...prev, newProduct].sort((a, b) => a.name.localeCompare(b.name)))
    return newProduct
  }

  const updateProduct = (id: string, data: Partial<Product>) => {
    setProducts(prev => prev.map(product => 
      product.id === id ? { ...product, ...data } : product
    ).sort((a, b) => a.name.localeCompare(b.name)))
  }

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(product => product.id !== id))
  }

  const getProduct = (id: string) => {
    return products.find(product => product.id === id)
  }

  // ==================== Búsqueda ====================

  const searchProducts = (query: string) => {
    if (!query.trim()) return products
    
    const lowerQuery = query.toLowerCase()
    return products.filter(product =>
      product.name.toLowerCase().includes(lowerQuery) ||
      product.category?.toLowerCase().includes(lowerQuery) ||
      product.provider?.toLowerCase().includes(lowerQuery) ||
      product.id.toLowerCase().includes(lowerQuery)
    )
  }

  // ==================== Import/Export ====================

  const importFromJSON = (jsonData: Product[]) => {
    const validProducts = jsonData.filter(p => p.name && p.price !== undefined)
    setProducts(prev => [...prev, ...validProducts])
    return validProducts.length
  }

  const exportToJSON = () => {
    const dataStr = JSON.stringify(products, null, 2)
    const blob = new Blob([dataStr], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `products_${new Date().toISOString().split('T')[0]}.json`
    link.click()
    URL.revokeObjectURL(url)
  }

  // ==================== Validación ====================

  const validateProduct = (product: ProductFormData): { valid: boolean; errors: string[] } => {
    const errors: string[] = []
    
    // Convertir valores a número para validación
    const price = typeof product.price === 'string' ? parseInt(product.price.replace(/\D/g, '')) || 0 : product.price
    const stock = typeof product.stock === 'string' ? parseInt(product.stock.replace(/\D/g, '')) || 0 : product.stock
    const costPrice = typeof product.costPrice === 'string' ? parseInt(product.costPrice.replace(/\D/g, '')) || 0 : product.costPrice

    if (!product.name.trim()) {
      errors.push('El nombre es requerido')
    }

    if (price < 0) {
      errors.push('El precio no puede ser negativo')
    }

    if (stock < 0) {
      errors.push('El stock no puede ser negativo')
    }

    if (costPrice && costPrice < 0) {
      errors.push('El precio de costo no puede ser negativo')
    }
    
    // Validar que el precio de venta sea mayor al precio de compra
    if (costPrice > 0 && price <= costPrice) {
      errors.push(`El precio de venta (${formatCurrency(price)}) debe ser mayor al precio de compra (${formatCurrency(costPrice)})`)
    }

    return {
      valid: errors.length === 0,
      errors
    }
  }

  // ==================== Análisis ====================

  const criticalStockProducts = useMemo(() => {
    return products.filter(p => p.stock < 10)
  }, [products])

  const warningStockProducts = useMemo(() => {
    return products.filter(p => p.stock >= 10 && p.stock < 20)
  }, [products])

  const getTotalInventoryValue = useMemo(() => {
    return products.reduce((sum, product) => {
      return sum + (product.price * product.stock)
    }, 0)
  }, [products])

  const getTotalCostValue = useMemo(() => {
    return products.reduce((sum, product) => {
      return sum + ((product.costPrice || 0) * product.stock)
    }, 0)
  }, [products])

  // Usar estados de categorías y proveedores
  const getCategories = useMemo(() => categories, [categories])
  const getProviders = useMemo(() => providers, [providers])

  // ==================== Editar Categoría ====================
  const updateCategory = (oldCategory: string, newCategory: string) => {
    if (!oldCategory || !newCategory.trim() || oldCategory === newCategory) return false
    
    setProducts(prev => prev.map(product =>
      product.category === oldCategory
        ? { ...product, category: newCategory.trim() }
        : product
    ))
    // Actualizar también el array de categorías
    setCategories(prev => prev.map(c => c === oldCategory ? newCategory.trim() : c))
    return true
  }

  // ==================== Eliminar Categoría ====================
  const deleteCategory = (category: string) => {
    if (!category) return false
    
    setProducts(prev => prev.map(product =>
      product.category === category
        ? { ...product, category: '' }
        : product
    ))
    // Eliminar del array de categorías
    setCategories(prev => prev.filter(c => c !== category))
    return true
  }

  // ==================== Editar Proveedor ====================
  const updateProvider = (oldProvider: string, newProvider: string) => {
    if (!oldProvider || !newProvider.trim() || oldProvider === newProvider) return false
    
    setProducts(prev => prev.map(product =>
      product.provider === oldProvider
        ? { ...product, provider: newProvider.trim() }
        : product
    ))
    // Actualizar también el array de proveedores
    setProviders(prev => prev.map(p => p === oldProvider ? newProvider.trim() : p))
    return true
  }

  // ==================== Eliminar Proveedor ====================
  const deleteProvider = (provider: string) => {
    if (!provider) return false
    
    setProducts(prev => prev.map(product =>
      product.provider === provider
        ? { ...product, provider: '' }
        : product
    ))
    return true
  }

  // ==================== Export/Import a Archivo ====================

  const exportToFile = async () => {
    await exportModuleData(MODULE_NAME, 'products.json')
  }

  const importFromFile = (file: File): Promise<boolean> => {
    return new Promise((resolve) => {
      const reader = new FileReader()
      reader.onload = (event) => {
        try {
          const data = JSON.parse(event.target?.result as string)
          if (Array.isArray(data)) {
            setProducts(data)
            resolve(true)
          } else {
            resolve(false)
          }
        } catch {
          resolve(false)
        }
      }
      reader.readAsText(file)
    })
  }

  return {
    // Estado
    products,
    setProducts,
    // CRUD
    addProduct,
    updateProduct,
    deleteProduct,
    getProduct,
    migrateProductIds,
    // Búsqueda
    searchProducts,
    // Import/Export
    importFromJSON,
    exportToJSON,
    // Import/Export a Archivo
    exportToFile,
    importFromFile,
    // Validación
    validateProduct,
    // Análisis
    criticalStockProducts,
    warningStockProducts,
    getTotalInventoryValue,
    getTotalCostValue,
    getCategories,
    getProviders,
    // Categorías
    addCategory,
    removeCategory,
    updateCategory,
    deleteCategory,
    // Proveedores
    addProvider,
    removeProvider,
    updateProvider,
    deleteProvider,
  }
}
