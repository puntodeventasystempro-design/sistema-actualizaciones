import React, { useState, useEffect } from 'react'
import { useQuotes, Quote, QuoteItem } from './useQuotes'
import styles from './Quotes.module.css'

interface QuotesProps {
  onNavigateToProducts?: () => void
  onNavigateToClients?: () => void
}

export default function Quotes({ onNavigateToProducts, onNavigateToClients }: QuotesProps) {
  const {
    quotes,
    searchQuotes,
    deleteQuote,
    convertToSale,
    downloadQuoteHTML,
    printQuoteHTML,
    getQuoteCount,
    getTotalQuoted,
    addQuote,
    generateQuoteHTML,
    getQuote,
  } = useQuotes()

  const [searchQuery, setSearchQuery] = useState('')
  const [selectedQuote, setSelectedQuote] = useState<string | null>(null)
  const [showPreview, setShowPreview] = useState(false)
  // Cargar estado del formulario desde localStorage
  const loadFormState = () => {
    try {
      const saved = localStorage.getItem('pos_quote_draft')
      if (saved) {
        const draft = JSON.parse(saved)
        return draft
      }
    } catch (e) {
      console.error('Error loading draft:', e)
    }
    return null
  }

  const savedDraft = loadFormState()

  const [showCreateForm, setShowCreateForm] = useState(savedDraft?.showCreateForm || false)
  const [clientName, setClientName] = useState(savedDraft?.clientName || '')
  const [clientSearch, setClientSearch] = useState(savedDraft?.clientSearch || '')
  const [showClientList, setShowClientList] = useState(false)
  const [selectedClient, setSelectedClient] = useState<any>(savedDraft?.selectedClient || null)
  const [cart, setCart] = useState<QuoteItem[]>(savedDraft?.cart || [])
  const [productSearch, setProductSearch] = useState('')
  const [selectedProduct, setSelectedProduct] = useState<any>(null)
  const [showProductList, setShowProductList] = useState(false)
  const [quantity, setQuantity] = useState(1)
  const [discount, setDiscount] = useState(savedDraft?.discount || 0)
  const [notes, setNotes] = useState(savedDraft?.notes || '')
  const [products, setProducts] = useState<any[]>([])
  const [clients, setClients] = useState<any[]>([])

  useEffect(() => {
    const productsData = JSON.parse(localStorage.getItem('pos_products') || '[]')
    setProducts(productsData)
    const clientsData = JSON.parse(localStorage.getItem('pos_clients') || '[]')
    setClients(clientsData)
  }, [showCreateForm])

  // Guardar estado del formulario automáticamente
  useEffect(() => {
    if (showCreateForm || cart.length > 0 || clientName || notes || discount > 0) {
      const draft = {
        showCreateForm,
        clientName,
        clientSearch,
        selectedClient,
        cart,
        discount,
        notes
      }
      localStorage.setItem('pos_quote_draft', JSON.stringify(draft))
    }
  }, [showCreateForm, clientName, clientSearch, selectedClient, cart, discount, notes])

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as HTMLElement
      if (!target.closest('.client-dropdown') && !target.closest('input[placeholder*="cliente"]')) {
        setShowClientList(false)
      }
      if (!target.closest('.product-dropdown') && !target.closest('input[placeholder*="producto"]')) {
        setShowProductList(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const filteredQuotes = searchQuotes(searchQuery)
  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(productSearch.toLowerCase()) ||
    p.barcode?.toLowerCase().includes(productSearch.toLowerCase())
  )
  const filteredClients = clients.filter(c =>
    c.name.toLowerCase().includes(clientSearch.toLowerCase()) ||
    c.email?.toLowerCase().includes(clientSearch.toLowerCase()) ||
    c.phone?.toLowerCase().includes(clientSearch.toLowerCase())
  )

  const formatCurrency = (amount: number) => `$ ${amount.toLocaleString('es-CO')}`
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    return date.toLocaleDateString('es-CO', {
      day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit'
    })
  }

  const handlePreview = (quoteId: string) => {
    const quote = getQuote(quoteId)
    if (!quote) {
      alert('Cotización no encontrada')
      return
    }
    const companyConfig = JSON.parse(localStorage.getItem('pos_company_config') || '{}')
    const userProfile = JSON.parse(localStorage.getItem('pos_user_profile') || '{}')
    const html = generateQuoteHTML(quote, companyConfig, userProfile)
    
    // Abrir en nueva ventana
    const previewWindow = window.open('', '_blank')
    if (previewWindow) {
      previewWindow.document.write(html)
      previewWindow.document.close()
    } else {
      alert('Por favor, permite las ventanas emergentes para ver la vista previa')
    }
  }

  const handleDownload = (quoteId: string) => {
    const companyConfig = JSON.parse(localStorage.getItem('pos_company_config') || '{}')
    const userProfile = JSON.parse(localStorage.getItem('pos_user_profile') || '{}')
    downloadQuoteHTML(quoteId, companyConfig, userProfile)
  }

  const handlePrint = (quoteId: string) => {
    const companyConfig = JSON.parse(localStorage.getItem('pos_company_config') || '{}')
    const userProfile = JSON.parse(localStorage.getItem('pos_user_profile') || '{}')
    printQuoteHTML(quoteId, companyConfig, userProfile)
  }

  const handleDelete = (quoteId: string) => {
    if (window.confirm('¿Estás seguro de eliminar esta cotización?')) {
      deleteQuote(quoteId)
    }
  }

  const handleConvertToSale = (quoteId: string) => {
    if (window.confirm('¿Convertir esta cotización en una venta?')) {
      convertToSale(quoteId)
      alert('Cotización convertida a venta exitosamente')
    }
  }

  const addToCart = () => {
    if (!selectedProduct) {
      alert('Selecciona un producto')
      return
    }
    const existingItem = cart.find(item => item.id === selectedProduct.id)
    if (existingItem) {
      setCart(cart.map(item =>
        item.id === selectedProduct.id ? { ...item, qty: item.qty + quantity } : item
      ))
    } else {
      setCart([...cart, {
        id: selectedProduct.id,
        name: selectedProduct.name,
        price: selectedProduct.price,
        qty: quantity
      }])
    }
    setSelectedProduct(null)
    setProductSearch('')
    setQuantity(1)
  }

  const removeFromCart = (productId: string) => {
    setCart(cart.filter(item => item.id !== productId))
  }

  const updateCartQuantity = (productId: string, newQty: number) => {
    if (newQty <= 0) {
      removeFromCart(productId)
      return
    }
    setCart(cart.map(item =>
      item.id === productId ? { ...item, qty: newQty } : item
    ))
  }

  const calculateSubtotal = () => cart.reduce((sum, item) => sum + (item.price * item.qty), 0)
  
  const calculateTax = () => {
    const companyConfig = JSON.parse(localStorage.getItem('pos_company_config') || '{}')
    const taxRate = companyConfig.taxRate || 0
    const applyTax = companyConfig.applyTax ?? false
    if (!applyTax) return 0
    return (calculateSubtotal() - discount) * (taxRate / 100)
  }

  const calculateTotal = () => calculateSubtotal() - discount + calculateTax()

  const handleCreateQuote = () => {
    if (!clientName.trim()) {
      alert('Ingresa el nombre del cliente')
      return
    }
    if (cart.length === 0) {
      alert('Agrega al menos un producto')
      return
    }
    const newQuote: Quote = {
      id: `COT-${Date.now()}`,
      createdAt: new Date().toISOString(),
      client: clientName,
      clientEmail: selectedClient?.email || '',
      clientPhone: selectedClient?.phone || '',
      clientAddress: selectedClient?.address || '',
      clientDocument: selectedClient?.nit || '',
      items: cart,
      subtotal: calculateSubtotal(),
      discount: discount,
      tax: calculateTax(),
      total: calculateTotal(),
      status: 'pending',
      notes: notes
    }
    addQuote(newQuote)
    
    // Mostrar opciones después de crear
    const action = window.confirm('✅ Cotización creada exitosamente\n\n¿Deseas imprimir la cotización ahora?\n\nOK = Imprimir\nCancelar = Solo guardar')
    
    if (action) {
      // Imprimir cotización
      const companyConfig = JSON.parse(localStorage.getItem('pos_company_config') || '{}')
      const userProfile = JSON.parse(localStorage.getItem('pos_user_profile') || '{}')
      printQuoteHTML(newQuote.id, companyConfig, userProfile)
    }
    
    // Limpiar formulario y borrar draft
    clearForm()
  }

  const cancelCreateQuote = () => {
    if (cart.length > 0 && !window.confirm('¿Cancelar la cotización? Se perderán los datos ingresados.')) {
      return
    }
    clearForm()
  }

  const clearForm = () => {
    setClientName('')
    setClientSearch('')
    setSelectedClient(null)
    setShowClientList(false)
    setCart([])
    setDiscount(0)
    setNotes('')
    setProductSearch('')
    setSelectedProduct(null)
    setShowProductList(false)
    setShowCreateForm(false)
    // Limpiar draft del localStorage
    localStorage.removeItem('pos_quote_draft')
  }

  const selectClient = (client: any) => {
    setClientName(client.name)
    setClientSearch(client.name)
    setSelectedClient(client)
    setShowClientList(false)
  }

  const selectProduct = (product: any) => {
    setSelectedProduct(product)
    setProductSearch(product.name)
    setShowProductList(false)
  }

  return (
    <div className={styles.container}>
      {!showCreateForm && (
        <div style={{ marginBottom: '20px' }}>
          <button onClick={() => setShowCreateForm(true)} className={styles.newQuoteBtn}>
            ➕ Nueva Cotización
          </button>
        </div>
      )}

      {showCreateForm && (
        <div className={styles.formContainer}>
          <div className={styles.formHeader}>
            <h3 className={styles.formTitle}>📋 Nueva Cotización</h3>
          </div>

          <div className={styles.section}>
            <h4 className={styles.sectionTitle}>👤 Información del Cliente</h4>
            <div className={styles.inputGroup}>
              <label className={styles.label}>Cliente *</label>
              <div style={{ display: 'flex', gap: '10px' }}>
                <div style={{ flex: 1, position: 'relative' }}>
                  <input
                    type="text"
                    value={clientSearch}
                    onChange={e => { setClientSearch(e.target.value); setClientName(e.target.value); setShowClientList(true); }}
                    onFocus={() => setShowClientList(true)}
                    placeholder="Buscar cliente..."
                    autoComplete="off"
                    className={styles.input}
                  />
                  {showClientList && (
                    <div className={`client-dropdown ${styles.dropdown}`}>
                      {filteredClients.length > 0 ? filteredClients.map(client => (
                        <div key={client.id} onClick={() => selectClient(client)} className={styles.dropdownItem}>
                          <div style={{ fontWeight: 'bold' }}>{client.name}</div>
                          <div style={{ fontSize: '12px', color: '#666' }}>
                            {client.email && <span>📧 {client.email}</span>}
                            {client.phone && <span> • 📱 {client.phone}</span>}
                          </div>
                        </div>
                      )) : (
                        <div style={{ padding: '20px', textAlign: 'center', color: '#666' }}>
                          {clients.length === 0 ? 'No hay clientes registrados' : 'No se encontraron clientes'}
                        </div>
                      )}
                    </div>
                  )}
                </div>
                {onNavigateToClients && (
                  <button onClick={onNavigateToClients} className={styles.btnAddNew}>
                    ➕ Nuevo
                  </button>
                )}
              </div>
            </div>
          </div>

          <div className={styles.section}>
            <h4 className={styles.sectionTitle}>🛒 Selección de Productos</h4>
            <div className={styles.inputGroup}>
              <label className={styles.label}>Buscar Producto *</label>
              <div style={{ display: 'flex', gap: '10px', marginBottom: '10px' }}>
                <div style={{ flex: 1, position: 'relative' }}>
                  <input
                    type="text"
                    value={productSearch}
                    onChange={e => { setProductSearch(e.target.value); setShowProductList(true); setSelectedProduct(null); }}
                    onFocus={() => setShowProductList(true)}
                    placeholder="Buscar producto..."
                    autoComplete="off"
                    className={styles.input}
                  />
                  {showProductList && (
                    <div className={`product-dropdown ${styles.dropdown}`}>
                      {filteredProducts.length > 0 ? filteredProducts.slice(0, 15).map(product => (
                        <div key={product.id} onClick={() => selectProduct(product)} className={styles.dropdownItem}>
                          <div className={styles.productCard}>
                            <div>
                              <div style={{ fontWeight: 'bold' }}>{product.name}</div>
                              <div style={{ fontSize: '12px', color: '#666' }}>Stock: {product.stock}</div>
                            </div>
                            <div style={{ fontWeight: 'bold', color: '#10b981' }}>{formatCurrency(product.price)}</div>
                          </div>
                        </div>
                      )) : (
                        <div style={{ padding: '20px', textAlign: 'center', color: '#666' }}>
                          {products.length === 0 ? 'No hay productos registrados' : 'No se encontraron productos'}
                        </div>
                      )}
                    </div>
                  )}
                </div>
                <input type="number" min="1" value={quantity} onChange={e => setQuantity(Number(e.target.value))} style={{ width: '80px', padding: '10px', borderRadius: '6px', border: '1px solid #ddd' }} />
                <button onClick={addToCart} className={styles.btnAdd}>
                  ➕ Agregar
                </button>
              </div>
              {selectedProduct && (
                <div className={styles.selectedBadge}>
                  ✓ Seleccionado: <strong>{selectedProduct.name}</strong> - {formatCurrency(selectedProduct.price)}
                </div>
              )}
            </div>
          </div>

          {cart.length > 0 && (
            <div className={styles.section}>
              <h4 className={styles.sectionTitle}>📦 Carrito de Compras</h4>
              <div className={styles.cartTable}>
                <table>
                  <thead>
                    <tr>
                      <th style={{ textAlign: 'left' }}>Producto</th>
                      <th style={{ textAlign: 'center' }}>Cantidad</th>
                      <th style={{ textAlign: 'right' }}>Precio</th>
                      <th style={{ textAlign: 'right' }}>Total</th>
                      <th style={{ textAlign: 'center' }}>Acción</th>
                    </tr>
                  </thead>
                  <tbody>
                    {cart.map(item => (
                      <tr key={item.id}>
                        <td>{item.name}</td>
                        <td style={{ textAlign: 'center' }}>
                          <input type="number" min="1" value={item.qty} onChange={e => updateCartQuantity(item.id, Number(e.target.value))} style={{ width: '60px', padding: '5px', borderRadius: '4px', border: '1px solid #ddd', textAlign: 'center' }} />
                        </td>
                        <td style={{ textAlign: 'right' }}>{formatCurrency(item.price)}</td>
                        <td style={{ textAlign: 'right', fontWeight: 'bold' }}>{formatCurrency(item.price * item.qty)}</td>
                        <td style={{ textAlign: 'center' }}>
                          <button onClick={() => removeFromCart(item.id)} className={styles.btnDelete}>🗑️</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          <div className={styles.section}>
            <h4 className={styles.sectionTitle}>💰 Descuentos y Notas</h4>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '15px' }}>
              <div className={styles.inputGroup}>
                <label className={styles.label}>Descuento ($)</label>
                <input type="number" min="0" value={discount} onChange={e => setDiscount(Number(e.target.value))} placeholder="0" className={styles.input} />
              </div>
              <div className={styles.inputGroup}>
                <label className={styles.label}>Notas (opcional)</label>
                <input type="text" value={notes} onChange={e => setNotes(e.target.value)} placeholder="Notas adicionales..." className={styles.input} />
              </div>
            </div>
          </div>

          {cart.length > 0 && (
            <div className={styles.summary}>
              <h4 className={styles.summaryTitle}>📊 Resumen de Cotización</h4>
              <div className={styles.summaryRow}>
                <span>Subtotal:</span>
                <span>{formatCurrency(calculateSubtotal())}</span>
              </div>
              {discount > 0 && (
                <div className={styles.summaryRow}>
                  <span>Descuento:</span>
                  <span>-{formatCurrency(discount)}</span>
                </div>
              )}
              {calculateTax() > 0 && (
                <div className={styles.summaryRow}>
                  <span>IVA:</span>
                  <span>{formatCurrency(calculateTax())}</span>
                </div>
              )}
              <div className={styles.summaryTotal}>
                <span>TOTAL:</span>
                <span>{formatCurrency(calculateTotal())}</span>
              </div>
            </div>
          )}

          <div className={styles.actions}>
            <button onClick={cancelCreateQuote} style={{
              padding: '12px 24px',
              borderRadius: '8px',
              border: 'none',
              background: '#dc2626',
              color: 'white',
              fontWeight: 'bold',
              cursor: 'pointer',
              fontSize: '14px'
            }}>
              ✕ Cancelar
            </button>
            <button onClick={handleCreateQuote} className={styles.btnPrimary}>
              💾 Guardar Cotización
            </button>
          </div>
        </div>
      )}

      {!showCreateForm && (
        <>
          <div className={styles.statsGrid}>
            <div className={styles.statCard}>
              <strong>Total Cotizaciones:</strong> {getQuoteCount}
            </div>
            <div className={styles.statCard}>
              <strong>Total Cotizado:</strong> {formatCurrency(getTotalQuoted)}
            </div>
          </div>

          <div style={{ marginBottom: '20px' }}>
            <input
              type="text"
              placeholder="Buscar por ID de cotización o cliente..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className={styles.input}
            />
          </div>

          <div className={styles.tableContainer}>
            <table className={styles.table}>
              <thead>
                <tr>
                  <th style={{ textAlign: 'left' }}>ID Cotización</th>
                  <th style={{ textAlign: 'left' }}>Fecha</th>
                  <th style={{ textAlign: 'left' }}>Cliente</th>
                  <th style={{ textAlign: 'right' }}>Total</th>
                  <th style={{ textAlign: 'center' }}>Estado</th>
                  <th style={{ textAlign: 'center' }}>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {filteredQuotes.length === 0 ? (
                  <tr>
                    <td colSpan={6} style={{ padding: '40px', textAlign: 'center', color: '#666' }}>
                      {searchQuery ? 'No se encontraron cotizaciones' : 'No hay cotizaciones registradas'}
                    </td>
                  </tr>
                ) : (
                  filteredQuotes.map(quote => (
                    <tr key={quote.id}>
                      <td style={{ fontFamily: 'monospace', fontSize: '12px' }}>{quote.id}</td>
                      <td style={{ fontSize: '12px' }}>{formatDate(quote.createdAt)}</td>
                      <td>{quote.client || 'Cliente General'}</td>
                      <td style={{ textAlign: 'right', fontWeight: 'bold' }}>{formatCurrency(quote.total)}</td>
                      <td style={{ textAlign: 'center' }}>
                        <span className={`${styles.badge} ${quote.status === 'converted' ? styles.badgeSuccess : styles.badgeWarning}`}>
                          {quote.status === 'converted' ? 'Convertida' : 'Pendiente'}
                        </span>
                      </td>
                      <td style={{ textAlign: 'center' }}>
                        {quote.status !== 'converted' && (
                          <button onClick={() => handleConvertToSale(quote.id)} className={styles.btnConvert} title="Convertir a venta">💰</button>
                        )}
                        <button onClick={() => handlePrint(quote.id)} className={styles.btnPrint} title="Imprimir">🖨️</button>
                        <button onClick={() => handlePreview(quote.id)} className={styles.btnPreview} title="Vista previa">👁️</button>
                        <button onClick={() => handleDownload(quote.id)} className={styles.btnDownload} title="Descargar HTML">📄</button>
                        <button onClick={() => handleDelete(quote.id)} className={styles.btnDeleteAction} title="Eliminar">🗑️</button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  )
}
