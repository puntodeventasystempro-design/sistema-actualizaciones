export const formatNumberWithDots = (value: number | string): string => {
  const num = typeof value === 'string' ? parseInt(value.replace(/\D/g, '')) || 0 : value
  return num.toLocaleString('es-CO')
}

export const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(amount)
}

export const formatInputNumber = (value: string): string => {
  // Eliminar todo lo que no sea números
  const numbersOnly = value.replace(/\D/g, '')
  
  // Si el valor es solo él cero, mantenerlo
  if (numbersOnly === '') return ''
  if (numbersOnly === '0') return ''
  
  // Formatear con puntos de mil
  return formatNumberWithDots(numbersOnly)
}

export const parseInputNumber = (value: string): number => {
  // Eliminar puntos y otros caracteres no numéricos
  const cleaned = value.replace(/\D/g, '')
  return parseInt(cleaned) || 0
}
