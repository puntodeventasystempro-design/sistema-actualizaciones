import React, { useRef, useState, useEffect } from 'react'
import { useSettings } from './useSettings'
import UpdatesPanel from './components/UpdatesPanel'

export default function Settings() {
  const {
    userProfile,
    updateUserProfile,
    updateUserPhoto,
    companyConfig,
    updateCompanyConfig,
    isDarkMode,
    toggleTheme,
    exportBackup,
    importBackup,
    clearAllData,
    // printers
    printerConfig,
    updatePrinterConfig,
    printers,
    addPrinter,
    removePrinter
  } = useSettings()

  // Función reutilizable para detectar impresoras (Electron / IPC / backend / navegador)
  const detectPrinters = async () => {
    const w = window as any
    let found: string[] = []
    
    // Intentar con Electron API
    try {
      if (w.electronAPI && typeof w.electronAPI.listPrinters === 'function') {
        found = await w.electronAPI.listPrinters()
      } else if (w.ipcRenderer && typeof w.ipcRenderer.invoke === 'function') {
        found = await w.ipcRenderer.invoke('list-printers')
      }
    } catch (err) {
      console.warn('Error con Electron API:', err)
    }

    // Si no hay Electron, intentar con backend
    if (found.length === 0) {
      try {
        const res = await fetch('/api/printers')
        if (res.ok) {
          const body = await res.json()
          if (Array.isArray(body)) found = body
        }
      } catch (e) {
        console.warn('No hay backend API disponible')
      }
    }

    // Si no hay backend, usar opciones del navegador
    if (found.length === 0) {
      // Agregar opciones de impresión disponibles en el navegador
      found = [
        'Impresora predeterminada del sistema',
        'Microsoft Print to PDF',
        'Guardar como PDF'
      ]
      console.log('[Settings] Usando opciones de impresión del navegador')
    }

    if (found && found.length > 0) {
      console.log('[Settings] found printers:', found)
      found.forEach(p => addPrinter(p))
      if (!companyConfig.printerName) {
        updateCompanyConfig({ printerName: found[0] })
      }
      alert(`Se encontraron ${found.length} opción(es) de impresión.\n\nNota: Desde el navegador, la impresora específica se selecciona en el diálogo de impresión del sistema.`)
      return true
    }

    alert('No se pudieron detectar opciones de impresión.')
    return false
  }

  // Función para generar vista previa de factura
  const generateInvoicePreview = (config: any, format: string) => {
    const colorPrimary = config.invoiceColorPrimary || '#667eea'
    const colorSecondary = config.invoiceColorSecondary || '#764ba2'
    const colorAccent = config.invoiceColorAccent || '#667eea'
    const fontSize = config.invoiceFontSize || '14'
    const fontFamily = config.invoiceFontFamily || 'Segoe UI'
    const fontBold = config.invoiceFontBold || false
    const fontItalic = config.invoiceFontItalic || false
    const fontWeight = config.invoiceFontWeight || '400'
    const footerText = config.invoiceFooterText || '¡Gracias por su compra!'
    const showLogo = config.invoiceShowLogo ?? true
    
    const ticketFontSize = config.ticketFontSize || '11'
    const ticketFontFamily = config.ticketFontFamily || 'Courier New'
    const ticketFontWeight = config.ticketFontWeight || '400'
    const ticketLineSpacing = config.ticketLineSpacing || 'normal'
    const ticketShowBorders = config.ticketShowBorders ?? true
    const ticketBoldHeaders = config.ticketBoldHeaders ?? true
    
    const lineHeight = ticketLineSpacing === 'compact' ? '1.2' : ticketLineSpacing === 'relaxed' ? '1.6' : '1.4'
    
    const companyName = config.companyName || 'MI EMPRESA S.A.S.'
    const companyNIT = config.companyNIT || '900.123.456-7'
    const companyAddress = config.address || 'Calle 123 #45-67, Bogotá'
    const companyPhone = config.phone || '(601) 234-5678'
    const companyEmail = config.email || 'info@miempresa.com'
    const companyLogo = config.logo || ''
    
    if (format === 'carta') {
      return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Vista Previa - Factura Carta</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { 
      font-family: ${fontFamily}, sans-serif; 
      font-size: ${fontSize}px;
      font-weight: ${fontWeight};
      ${fontBold ? 'font-weight: 700;' : ''}
      ${fontItalic ? 'font-style: italic;' : ''}
      background: #f5f5f5; 
      padding: 20px;
    }
    .invoice-container { 
      max-width: 800px; 
      margin: 0 auto; 
      background: white; 
      box-shadow: 0 0 30px rgba(0,0,0,0.1);
      border-radius: 12px;
      overflow: hidden;
    }
    .header { 
      background: linear-gradient(135deg, ${colorPrimary} 0%, ${colorSecondary} 100%);
      padding: 40px;
      color: white;
    }
    .header-content { display: flex; justify-content: space-between; align-items: flex-start; }
    .company-name { font-size: 28px; font-weight: 700; margin-bottom: 8px; }
    .company-info { font-size: 13px; opacity: 0.95; line-height: 1.6; }
    .invoice-badge {
      background: rgba(255,255,255,0.2);
      padding: 20px 30px;
      border-radius: 12px;
      text-align: right;
      border: 2px solid rgba(255,255,255,0.3);
    }
    .invoice-number { font-size: 24px; font-weight: 700; }
    .info-section { padding: 40px; display: grid; grid-template-columns: 1fr 1fr; gap: 30px; }
    .info-box {
      background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
      padding: 25px;
      border-radius: 12px;
      border-left: 4px solid ${colorAccent};
    }
    .info-box-title { font-size: 12px; text-transform: uppercase; color: ${colorAccent}; font-weight: 700; margin-bottom: 15px; }
    .items-section { padding: 0 40px 20px; }
    .items-table { width: 100%; border-collapse: collapse; border-radius: 12px; overflow: hidden; }
    .items-table thead { background: linear-gradient(135deg, ${colorPrimary} 0%, ${colorSecondary} 100%); color: white; }
    .items-table th { padding: 15px; text-align: left; font-size: 12px; text-transform: uppercase; }
    .items-table td { padding: 15px; font-size: 14px; border-bottom: 1px solid #f0f0f0; }
    .totals-section { padding: 30px 40px; background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%); }
    .total-final {
      margin-top: 15px;
      padding: 20px;
      background: linear-gradient(135deg, ${colorPrimary} 0%, ${colorSecondary} 100%);
      color: white;
      border-radius: 12px;
      display: flex;
      justify-content: space-between;
    }
    .total-final-value { font-size: 32px; font-weight: 700; }
    .footer {
      padding: 30px 40px;
      text-align: center;
      background: linear-gradient(135deg, ${colorPrimary} 0%, ${colorSecondary} 100%);
      color: white;
    }
  </style>
</head>
<body>
  <div class="invoice-container">
    <div class="header">
      <div class="header-content">
        <div>
          ${showLogo && companyLogo ? `<img src="${companyLogo}" style="max-width: 120px; margin-bottom: 15px; border-radius: 8px;" />` : ''}
          <div class="company-name">${companyName}</div>
          <div class="company-info">
            NIT: ${companyNIT}<br>
            ${companyAddress}<br>
            📞 ${companyPhone}<br>
            ✉️ ${companyEmail}
          </div>
        </div>
        <div class="invoice-badge">
          <div style="font-size: 14px; margin-bottom: 8px;">Factura</div>
          <div class="invoice-number">#PREVIEW-001</div>
          <div style="font-size: 12px; margin-top: 8px;">${new Date().toLocaleDateString('es-CO')}</div>
        </div>
      </div>
    </div>
    <div class="info-section">
      <div class="info-box">
        <div class="info-box-title">Cliente</div>
        <div>Cliente de Ejemplo</div>
      </div>
      <div class="info-box">
        <div class="info-box-title">Detalles</div>
        <div>Factura de Vista Previa</div>
      </div>
    </div>
    <div class="items-section">
      <table class="items-table">
        <thead><tr><th>Producto</th><th>Cant.</th><th>Precio</th><th>Total</th></tr></thead>
        <tbody>
          <tr><td>Producto Ejemplo 1</td><td>2</td><td>$ 50.000</td><td><strong>$ 100.000</strong></td></tr>
          <tr><td>Producto Ejemplo 2</td><td>1</td><td>$ 75.000</td><td><strong>$ 75.000</strong></td></tr>
        </tbody>
      </table>
    </div>
    <div class="totals-section">
      <div class="total-final">
        <span>TOTAL A PAGAR</span>
        <span class="total-final-value">$ 175.000</span>
      </div>
    </div>
    <div class="footer">
      <div style="font-size: 16px; font-weight: 600; margin-bottom: 10px;">${footerText}</div>
      <div style="font-size: 13px; opacity: 0.9;">${companyName}</div>
    </div>
  </div>
</body>
</html>`
    } else if (format === 'cotizacion') {
      // Vista previa de cotización - usar configuración personalizada de cotización
      const colorPrimary = config.quoteColorPrimary || '#f59e0b'
      const colorSecondary = config.quoteColorSecondary || '#d97706'
      const colorAccent = config.quoteColorAccent || '#3b82f6'
      const quoteFontSize = config.quoteFontSize || '14'
      const quoteFontFamily = config.quoteFontFamily || 'Segoe UI'
      const validityDays = config.quoteValidityDays || 15
      const quoteShowLogo = config.quoteShowLogo ?? true
      const logoWidth = config.quoteLogoWidth || 120
      const logoHeight = config.quoteLogoHeight || 70
      
      // Configuración de información del cliente
      const showClientName = config.quoteShowClientName ?? true
      const showClientEmail = config.quoteShowClientEmail ?? false
      const showClientPhone = config.quoteShowClientPhone ?? false
      const showClientAddress = config.quoteShowClientAddress ?? false
      const showClientDocument = config.quoteShowClientDocument ?? false
      
      // Términos y condiciones personalizables
      const defaultTerms = 'Después de {dias} días, no nos hacemos responsables de cambios en el valor de los productos o servicios cotizados, los precios están sujetos a disponibilidad de inventario al momento de confirmar el pedido, para confirmar su pedido se requiere un anticipo del 50% del valor total, el tiempo de entrega será confirmado al momento de realizar el pedido, los productos o servicios no incluyen instalación, transporte o configuración salvo que se especifique lo contrario, esta cotización no constituye una factura ni un compromiso de compra hasta su confirmación formal.'
      const quoteTerms = (config.quoteTerms || defaultTerms).replace('{dias}', validityDays.toString())
      
      return `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Vista Previa - Cotización</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    html {
      width: 100%;
      min-width: 21cm;
    }
    
    body {
      font-family: '${quoteFontFamily}', sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 20px 10px;
      color: #1f2937;
      font-size: ${quoteFontSize}px;
      width: 100%;
      min-width: 21cm;
    }
    
    .quote-container {
      width: 21cm;
      max-width: 21cm;
      min-width: 21cm;
      margin: 0 auto;
      background: white;
      border-radius: 12px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
      overflow: hidden;
    }
    
    .quote-header {
      background: linear-gradient(135deg, ${colorPrimary} 0%, ${colorSecondary} 100%);
      padding: 18px 25px;
      color: white;
      position: relative;
      overflow: hidden;
    }
    
    .quote-header::before {
      content: '';
      position: absolute;
      top: -50%;
      right: -10%;
      width: 300px;
      height: 300px;
      background: rgba(255, 255, 255, 0.1);
      border-radius: 50%;
    }
    
    .header-content {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      position: relative;
      z-index: 1;
      gap: 20px;
    }
    
    .logo-section {
      display: flex;
      align-items: center;
      gap: 15px;
    }
    
    .company-logo {
      max-width: ${logoWidth}px;
      height: auto;
      max-height: ${logoHeight}px;
      object-fit: contain;
      background: white;
      padding: 5px;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
      flex-shrink: 0;
    }
    
    .company-info h1 {
      font-size: 20px;
      font-weight: 700;
      margin-bottom: 4px;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
    }
    
    .company-info p {
      font-size: ${parseInt(quoteFontSize) - 3}px;
      margin: 2px 0;
      opacity: 0.95;
    }
    
    .quote-badge {
      background: white;
      color: ${colorPrimary};
      padding: 10px 20px;
      border-radius: 6px;
      font-size: 20px;
      font-weight: 700;
      text-align: center;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }
    
    .quote-info {
      text-align: right;
      margin-top: 8px;
    }
    
    .quote-info p {
      font-size: ${parseInt(quoteFontSize) - 2}px;
      margin: 3px 0;
    }
    
    .quote-body {
      padding: 20px 25px;
    }
    
    .client-section {
      background: linear-gradient(135deg, ${colorAccent}08 0%, ${colorAccent}15 100%);
      padding: 8px 12px;
      border-radius: 6px;
      margin-bottom: 10px;
      border-left: 3px solid ${colorAccent};
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
    }
    
    .client-section h3 {
      display: inline-block;
      color: ${colorAccent};
      font-size: ${parseInt(quoteFontSize) - 2}px;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-right: 10px;
      font-weight: 700;
      opacity: 0.8;
    }
    
    .client-name {
      display: inline;
      font-size: ${parseInt(quoteFontSize) + 1}px;
      font-weight: 700;
      color: #1f2937;
      margin-right: 12px;
    }
    
    .client-details {
      display: inline-flex;
      flex-wrap: wrap;
      gap: 8px;
      font-size: ${parseInt(quoteFontSize) - 2}px;
      color: #4b5563;
      align-items: center;
    }
    
    .client-detail-item {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 2px 8px;
      background: white;
      border-radius: 4px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
      font-weight: 500;
      border: 1px solid #e5e7eb;
      white-space: nowrap;
    }
    
    .client-detail-icon {
      font-size: ${parseInt(quoteFontSize)}px;
      flex-shrink: 0;
    }
    
    .items-table {
      width: 100%;
      border-collapse: collapse;
      margin: 15px 0;
      border: 2px solid #e5e7eb;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
    }
    
    .items-table thead {
      background: linear-gradient(135deg, ${colorPrimary} 0%, ${colorSecondary} 100%);
    }
    
    .items-table th {
      padding: 8px 8px;
      text-align: left;
      font-size: ${parseInt(quoteFontSize) - 1}px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: white;
      border-bottom: 2px solid ${colorPrimary};
    }
    
    .items-table th:nth-child(2),
    .items-table th:nth-child(3),
    .items-table th:nth-child(4) {
      text-align: right;
    }
    
    .items-table th:nth-child(2) {
      text-align: center;
    }
    
    .items-table tbody tr:hover {
      background: linear-gradient(90deg, #f0f9ff 0%, #e0f2fe 100%);
    }
    
    .items-table tbody tr {
      border-bottom: 1px solid #e5e7eb;
      transition: background 0.2s;
    }
    
    .items-table tbody tr:last-child {
      border-bottom: 2px solid ${colorPrimary};
    }
    
    .items-table td {
      color: #1f2937;
      font-size: ${parseInt(quoteFontSize)}px;
      padding: 8px 8px;
      font-weight: 500;
    }
    
    .items-table td:last-child {
      font-weight: 700;
      color: ${colorPrimary};
    }
    
    .totals-section {
      margin-top: 12px;
      display: flex;
      justify-content: flex-end;
    }
    
    .totals-box {
      width: 280px;
      background: linear-gradient(135deg, #f9fafb 0%, #f3f4f6 100%);
      border-radius: 6px;
      padding: 10px 12px;
      border: 2px solid #e5e7eb;
    }
    
    .total-row {
      display: flex;
      justify-content: space-between;
      padding: 3px 0;
      font-size: ${parseInt(quoteFontSize) - 1}px;
      color: #4b5563;
    }
    
    .total-row.discount {
      color: #dc2626;
      font-weight: 600;
    }
    
    .total-row.final {
      border-top: 2px solid ${colorPrimary};
      margin-top: 6px;
      padding-top: 6px;
      font-size: ${parseInt(quoteFontSize) + 3}px;
      font-weight: 700;
      color: #1f2937;
    }
    
    .total-row.final .amount {
      color: ${colorPrimary};
    }
    
    .notes-section {
      margin-top: 12px;
      background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
      padding: 8px 10px;
      border-radius: 6px;
      border-left: 3px solid ${colorPrimary};
    }
    
    .notes-section h4 {
      color: #92400e;
      font-size: ${parseInt(quoteFontSize) - 2}px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 5px;
    }
    
    .notes-section p {
      color: #78350f;
      font-size: ${parseInt(quoteFontSize) - 2}px;
      line-height: 1.4;
    }
    
    .quote-footer {
      background: #f9fafb;
      padding: 12px 20px;
      text-align: center;
      border-top: 2px solid #e5e7eb;
    }
    
    .validity-notice {
      background: linear-gradient(135deg, ${colorAccent}25 0%, ${colorAccent}35 100%);
      padding: 8px;
      border-radius: 6px;
      margin-bottom: 10px;
      border: 2px solid ${colorAccent};
    }
    
    .validity-notice p {
      color: ${colorAccent};
      font-weight: 600;
      font-size: ${parseInt(quoteFontSize) - 1}px;
      margin: 0;
    }
    
    .footer-info {
      font-size: ${parseInt(quoteFontSize) - 2}px;
      color: #6b7280;
    }
    
    @media print {
      body {
        background: white;
        padding: 0;
      }
      
      .quote-container {
        box-shadow: none;
        border-radius: 0;
        max-width: 21cm;
        min-height: 29.7cm;
      }
      
      .quote-header::before {
        display: none;
      }
      
      @page {
        size: letter;
        margin: 1cm;
      }
    }
  </style>
</head>
<body>
  <div class="quote-container">
    <!-- Header -->
    <div class="quote-header">
      <div class="header-content">
        <div class="logo-section">
          ${quoteShowLogo && companyLogo ? `<img src="${companyLogo}" alt="Logo" class="company-logo" />` : ''}
          <div class="company-info">
            <h1>${companyName}</h1>
            <p>📄 NIT: ${companyNIT}</p>
            <p>📍 ${companyAddress}</p>
            <p>📞 Tel: ${companyPhone}</p>
            <p>✉️ ${companyEmail}</p>
          </div>
        </div>
        <div>
          <div class="quote-badge">COTIZACIÓN</div>
          <div class="quote-info">
            <p><strong>No:</strong> PREVIEW-001</p>
            <p><strong>Fecha:</strong> ${new Date().toLocaleDateString('es-CO', { day: '2-digit', month: 'long', year: 'numeric' })}</p>
            <p><strong>Vendedor:</strong> ${userProfile?.name || 'Admin'}</p>
          </div>
        </div>
      </div>
    </div>

    <!-- Body -->
    <div class="quote-body">
      <!-- Cliente -->
      <div class="client-section">
        <h3>Cliente:</h3>
        ${showClientName ? `<span class="client-name">Cliente de Ejemplo</span>` : ''}
        <div class="client-details">
          ${showClientDocument ? `<span class="client-detail-item"><span class="client-detail-icon">📄</span>123456789</span>` : ''}
          ${showClientEmail ? `<span class="client-detail-item"><span class="client-detail-icon">✉️</span>cliente@ejemplo.com</span>` : ''}
          ${showClientPhone ? `<span class="client-detail-item"><span class="client-detail-icon">📱</span>300 123 4567</span>` : ''}
          ${showClientAddress ? `<span class="client-detail-item"><span class="client-detail-icon">📍</span>Calle 123 #45-67</span>` : ''}
        </div>
      </div>

      <!-- Items -->
      <table class="items-table">
        <thead>
          <tr>
            <th>Producto / Servicio</th>
            <th>Cantidad</th>
            <th>Precio Unitario</th>
            <th>Subtotal</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Producto Ejemplo 1</td>
            <td style="text-align: center;">2</td>
            <td style="text-align: right;">$ 50.000</td>
            <td style="text-align: right;"><strong>$ 100.000</strong></td>
          </tr>
          <tr>
            <td>Producto Ejemplo 2</td>
            <td style="text-align: center;">1</td>
            <td style="text-align: right;">$ 75.000</td>
            <td style="text-align: right;"><strong>$ 75.000</strong></td>
          </tr>
        </tbody>
      </table>

      <!-- Totales -->
      <div class="totals-section">
        <div class="totals-box">
          <div class="total-row">
            <span>Subtotal:</span>
            <span class="amount">$ 175.000</span>
          </div>
          <div class="total-row final">
            <span>TOTAL:</span>
            <span class="amount">$ 175.000</span>
          </div>
        </div>
      </div>

      <!-- Notas (ejemplo) -->
      <div class="notes-section">
        <h4>📝 Notas Adicionales</h4>
        <p>Esta es una cotización de ejemplo para vista previa.</p>
      </div>
    </div>

    <!-- Footer -->
    <div class="quote-footer">
      <div class="validity-notice">
        <p>⏰ Esta cotización es válida por ${validityDays} días calendario</p>
      </div>
      
      <div style="background: white; padding: 10px; border-radius: 6px; margin-bottom: 12px; border: 1px solid #e5e7eb; text-align: left;">
        <h4 style="color: #374151; font-size: ${parseInt(quoteFontSize) - 5}px; margin-bottom: 4px; font-weight: 700;">📋 Términos y Condiciones</h4>
        <p style="color: #6b7280; font-size: ${parseInt(quoteFontSize) - 6}px; line-height: 1.3; margin: 0; text-align: justify;">
          ${quoteTerms}
        </p>
      </div>
      
      <div style="background: linear-gradient(135deg, ${colorPrimary}15 0%, ${colorSecondary}15 100%); padding: 10px; border-radius: 6px; margin-bottom: 12px; border-left: 3px solid ${colorPrimary};">
        <p style="color: #374151; font-size: ${parseInt(quoteFontSize) - 2}px; font-weight: 600; margin: 0;">
          💼 Para más información o aclarar dudas sobre esta cotización, no dude en contactarnos.
        </p>
      </div>
      
      <div class="footer-info">
        <p style="font-weight: 600; color: #374151; margin: 0; font-size: ${parseInt(quoteFontSize) - 1}px;">¡Gracias por su preferencia!</p>
      </div>
    </div>
  </div>
</body>
</html>`
    } else {
      // Tickets POS
      const ticketWidth = format === 'ticket80' ? '80mm' : '57mm'
      return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Vista Previa - Ticket ${format === 'ticket80' ? '80mm' : '57mm'}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { 
      font-family: ${ticketFontFamily}, monospace; 
      width: ${ticketWidth};
      margin: 0 auto;
      padding: 10px;
      font-size: ${ticketFontSize}px;
      font-weight: ${ticketFontWeight};
      background: white;
    }
    .center { text-align: center; }
    .bold { font-weight: 700; }
    .company-name { font-size: ${parseInt(ticketFontSize) + 4}px; font-weight: 700; margin-bottom: 4px; }
    .divider { ${ticketShowBorders ? 'border-top: 1px dashed #000;' : ''} margin: 8px 0; }
    .divider-solid { ${ticketShowBorders ? 'border-top: 2px solid #000;' : ''} margin: 8px 0; }
    .section-title { ${ticketBoldHeaders ? 'font-weight: 700;' : ''} margin: 10px 0 5px; text-transform: uppercase; }
    .info-line { margin: 3px 0; line-height: ${lineHeight}; }
    .item-row { margin: 6px 0; }
    .item-name { font-weight: 700; }
    .item-details { display: flex; justify-content: space-between; margin-top: 2px; }
    .total-row { display: flex; justify-content: space-between; margin: 5px 0; }
    .total-final { font-size: ${parseInt(ticketFontSize) + 2}px; font-weight: 700; margin: 10px 0; padding: 8px 0; ${ticketShowBorders ? 'border-top: 2px solid #000; border-bottom: 2px solid #000;' : ''} }
  </style>
</head>
<body>
  <div class="center">
    ${showLogo && companyLogo ? `<img src="${companyLogo}" style="max-width: 60px; margin-bottom: 8px;" />` : ''}
    <div class="company-name">${companyName}</div>
    <div style="font-size: ${parseInt(ticketFontSize) - 2}px;">NIT: ${companyNIT}</div>
    <div style="font-size: ${parseInt(ticketFontSize) - 2}px;">${companyAddress}</div>
    <div style="font-size: ${parseInt(ticketFontSize) - 2}px;">Tel: ${companyPhone}</div>
  </div>
  <div class="divider-solid"></div>
  <div class="center">
    <div class="bold">FACTURA DE VENTA</div>
    <div style="font-size: ${parseInt(ticketFontSize) - 2}px;">No. PREVIEW-001</div>
    <div style="font-size: ${parseInt(ticketFontSize) - 2}px;">${new Date().toLocaleDateString('es-CO')}</div>
  </div>
  <div class="divider"></div>
  <div class="section-title" style="font-size: ${parseInt(ticketFontSize) - 2}px;">CLIENTE</div>
  <div class="info-line">Cliente de Ejemplo</div>
  <div class="divider"></div>
  <div class="section-title" style="font-size: ${parseInt(ticketFontSize) - 2}px;">PRODUCTOS</div>
  <div class="item-row">
    <div class="item-name">Producto 1</div>
    <div class="item-details" style="font-size: ${parseInt(ticketFontSize) - 2}px;">
      <span>2 x $50.000</span>
      <span>$100.000</span>
    </div>
  </div>
  <div class="item-row">
    <div class="item-name">Producto 2</div>
    <div class="item-details" style="font-size: ${parseInt(ticketFontSize) - 2}px;">
      <span>1 x $75.000</span>
      <span>$75.000</span>
    </div>
  </div>
  <div class="divider-solid"></div>
  <div class="total-row total-final">
    <span>TOTAL:</span>
    <span>$175.000</span>
  </div>
  <div class="divider"></div>
  <div class="center" style="margin-top: 15px; font-size: ${parseInt(ticketFontSize) - 2}px;">
    <div class="bold">${footerText.toUpperCase()}</div>
    <div>${companyName}</div>
  </div>
</body>
</html>`
    }
  }

  const fileInputRef = useRef<HTMLInputElement>(null)
  const backupInputRef = useRef<HTMLInputElement>(null)
  const [activeTab, setActiveTab] = useState<'profile' | 'company' | 'backup' | 'security' | 'printer' | 'license' | 'styles' | 'updates'>('profile')
  
  // Estado para lista desplegable de respaldos
  const [expandedBackup, setExpandedBackup] = useState<string | null>(null)
  
  // Estado para cambiar credenciales
  const [loginCredentials, setLoginCredentials] = useState({
    username: '',
    password: '',
    newUsername: '',
    newPassword: '',
    confirmPassword: ''
  })
  const [loginMessage, setLoginMessage] = useState('')
  const [loginError, setLoginError] = useState('')
  
  // Estado para visibilidad de contraseñas
  const [showNewPassword, setShowNewPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  
  // Estado para visibilidad de contraseñas en formulario de crear usuario
  const [showNewUserPassword, setShowNewUserPassword] = useState(false)
  const [showNewUserConfirmPassword, setShowNewUserConfirmPassword] = useState(false)

  // Estado para gestión de usuarios
  const [showCreateUserForm, setShowCreateUserForm] = useState(false)
  
  // Estado para el contador de días de licencia
  const [licenseDaysRemaining, setLicenseDaysRemaining] = useState<number | null>(null)
  
  // Calcular días restantes de licencia
  useEffect(() => {
    const licenseDate = localStorage.getItem('pos_license_date')
    const licenseDays = localStorage.getItem('pos_license_days')
    
    if (licenseDate && licenseDays) {
      const activationDate = new Date(licenseDate)
      const totalDays = parseInt(licenseDays)
      const now = new Date()
      const daysPassed = Math.floor((now.getTime() - activationDate.getTime()) / (1000 * 60 * 60 * 24))
      const remaining = Math.max(0, totalDays - daysPassed)
      setLicenseDaysRemaining(remaining)
    }
  }, [])

  // Detectar impresoras automáticamente al cargar el tab de impresora
  useEffect(() => {
    if (activeTab === 'printer' && printers.length === 0) {
      // Detectar impresoras automáticamente solo si no hay ninguna guardada
      const autoDetect = async () => {
        const w = window as any
        let found: string[] = []
        
        // Intentar con Electron API
        try {
          if (w.electronAPI && typeof w.electronAPI.listPrinters === 'function') {
            found = await w.electronAPI.listPrinters()
          } else if (w.ipcRenderer && typeof w.ipcRenderer.invoke === 'function') {
            found = await w.ipcRenderer.invoke('list-printers')
          }
        } catch (err) {
          console.warn('Error con Electron API:', err)
        }

        // Si no hay Electron, intentar con backend
        if (found.length === 0) {
          try {
            const res = await fetch('/api/printers')
            if (res.ok) {
              const body = await res.json()
              if (Array.isArray(body)) found = body
            }
          } catch (e) {
            console.warn('No hay backend API disponible')
          }
        }

        // Si no hay backend, usar Web Print API (navegador)
        if (found.length === 0 && 'print' in window) {
          try {
            // Intentar obtener impresoras del sistema usando la API del navegador
            if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
              const devices = await navigator.mediaDevices.enumerateDevices()
              console.log('Dispositivos disponibles:', devices)
            }
            
            // Agregar impresoras comunes como opciones
            found = [
              'Impresora predeterminada del sistema',
              'Microsoft Print to PDF',
              'Guardar como PDF'
            ]
            console.log('[Settings] Usando opciones de impresión del navegador')
          } catch (err) {
            console.warn('Error accediendo a dispositivos:', err)
          }
        }

        if (found && found.length > 0) {
          console.log('[Settings] Auto-detected printers:', found)
          found.forEach(p => addPrinter(p))
          if (!companyConfig.printerName) {
            updateCompanyConfig({ printerName: found[0] })
          }
        }
      }
      autoDetect()
    }
  }, [activeTab, printers.length])
  const [newUser, setNewUser] = useState({
    username: '',
    password: '',
    confirmPassword: '',
    role: 'user',
    permissions: {
      dashboard: false,
      sales: false,
      products: false,
      clients: false,
      reports: false,
      archives: false,
      settings: false
    }
  })
  const [userMessage, setUserMessage] = useState('')
  const [userError, setUserError] = useState('')
  const [usersList, setUsersList] = useState<any[]>([])

  // Estado para respaldo automático (activado por defecto)
  const [autoBackupEnabled, setAutoBackupEnabled] = useState(() => {
    // Siempre iniciar como true, ignorar localStorage
    localStorage.setItem('pos_auto_backup', 'true')
    return true
  })

  // Cargar credenciales actuales al iniciar
  useState(() => {
    const savedUsers = JSON.parse(localStorage.getItem('pos_users') || '[]')
    if (savedUsers.length > 0) {
      setLoginCredentials(prev => ({ ...prev, username: savedUsers[0].username || '', newUsername: savedUsers[0].username || '' }))
      setUsersList(savedUsers)
    } else {
      // Usar credenciales por defecto
      setLoginCredentials(prev => ({ ...prev, username: 'admin', newUsername: 'admin' }))
      setUsersList([{ username: 'admin', password: 'admin', role: 'admin', permissions: { dashboard: true, sales: true, products: true, clients: true, reports: true, archives: true, settings: true } }])
    }
  })

  // Efecto para manejar el respaldo automático solo al cerrar sesión
  useEffect(() => {
    // Remover los event listeners de cierre de página
    // El respaldo solo se hará manualmente al cerrar sesión
  }, [autoBackupEnabled])

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (event) => {
      if (event.target?.result) {
        updateUserPhoto(event.target.result as string)
      }
    }
    reader.readAsDataURL(file)
  }

  const handleBackupImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const success = await importBackup(file)
    if (success) {
      alert('Backup restaurado exitosamente')
    } else {
      alert('Error al restaurar backup')
    }
    
    // Limpiar el input
    if (backupInputRef.current) {
      backupInputRef.current.value = ''
    }
  }

  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault()
    setUserError('')
    setUserMessage('')

    // Validaciones
    if (!newUser.username || newUser.username.length < 3) {
      setUserError('El nombre de usuario debe tener al menos 3 caracteres')
      return
    }

    if (!newUser.password || newUser.password.length < 4) {
      setUserError('La contraseña debe tener al menos 4 caracteres')
      return
    }

    if (newUser.password !== newUser.confirmPassword) {
      setUserError('Las contraseñas no coinciden')
      return
    }

    // Verificar si el usuario ya existe
    const existingUser = usersList.find(u => u.username === newUser.username)
    if (existingUser) {
      setUserError('El nombre de usuario ya existe')
      return
    }

    // Crear nuevo usuario
    const userToAdd = {
      username: newUser.username,
      password: newUser.password,
      role: newUser.role,
      permissions: newUser.permissions
    }

    const updatedUsers = [...usersList, userToAdd]
    localStorage.setItem('pos_users', JSON.stringify(updatedUsers))
    setUsersList(updatedUsers)

    setUserMessage('Usuario creado exitosamente')
    setNewUser({
      username: '',
      password: '',
      confirmPassword: '',
      role: 'user',
      permissions: {
        dashboard: false,
        sales: false,
        products: false,
        clients: false,
        reports: false,
        archives: false,
        settings: false
      }
    })

    // Cerrar el formulario después de 2 segundos
    setTimeout(() => {
      setShowCreateUserForm(false)
      setUserMessage('')
    }, 2000)
  }

  const handleDeleteUser = (username: string) => {
    if (username === 'admin') {
      setUserError('No se puede eliminar el usuario admin')
      return
    }

    if (confirm(`¿Está seguro de eliminar el usuario "${username}"?`)) {
      const updatedUsers = usersList.filter(u => u.username !== username)
      localStorage.setItem('pos_users', JSON.stringify(updatedUsers))
      setUsersList(updatedUsers)
      setUserMessage('Usuario eliminado exitosamente')
      setTimeout(() => setUserMessage(''), 2000)
    }
  }

  return (
    <div className="module-body">

      {/* Tabs */}
      <div style={{ 
        display: 'flex', 
        gap: '8px', 
        marginBottom: '20px',
        flexWrap: 'wrap'
      }}>
        <button
          onClick={() => setActiveTab('profile')}
          style={{
            padding: '10px 16px',
            borderRadius: '8px',
            border: 'none',
            background: activeTab === 'profile' ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' : 'var(--bg-tertiary, #f0f0f0)',
            color: activeTab === 'profile' ? 'white' : 'var(--text-primary, #333)',
            cursor: 'pointer',
            fontWeight: 'bold',
            fontSize: '14px',
            flex: '1',
            minWidth: '100px',
            whiteSpace: 'nowrap',
            transition: 'all 0.3s ease'
          }}
        >
          Perfil
        </button>
        <button
          onClick={() => setActiveTab('company')}
          style={{
            padding: '10px 16px',
            borderRadius: '8px',
            border: 'none',
            background: activeTab === 'company' ? 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)' : 'var(--bg-tertiary, #f0f0f0)',
            color: activeTab === 'company' ? 'white' : 'var(--text-primary, #333)',
            cursor: 'pointer',
            fontWeight: 'bold',
            fontSize: '14px',
            flex: '1',
            minWidth: '100px',
            whiteSpace: 'nowrap',
            transition: 'all 0.3s ease'
          }}
        >
          Empresa
        </button>
        <button
          onClick={() => setActiveTab('backup')}
          style={{
            padding: '10px 16px',
            borderRadius: '8px',
            border: 'none',
            background: activeTab === 'backup' ? 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)' : 'var(--bg-tertiary, #f0f0f0)',
            color: activeTab === 'backup' ? 'white' : 'var(--text-primary, #333)',
            cursor: 'pointer',
            fontWeight: 'bold',
            fontSize: '14px',
            flex: '1',
            minWidth: '100px',
            whiteSpace: 'nowrap',
            transition: 'all 0.3s ease'
          }}
        >
          Respaldo
        </button>
        <button
          onClick={() => setActiveTab('printer')}
          style={{
            padding: '10px 16px',
            borderRadius: '8px',
            border: 'none',
            background: activeTab === 'printer' ? 'linear-gradient(135deg, #56ccf2 0%, #2f80ed 100%)' : 'var(--bg-tertiary, #f0f0f0)',
            color: activeTab === 'printer' ? 'white' : 'var(--text-primary, #333)',
            cursor: 'pointer',
            fontWeight: 'bold',
            fontSize: '14px',
            flex: '1',
            minWidth: '100px',
            whiteSpace: 'nowrap',
            transition: 'all 0.3s ease'
          }}
        >
          🖨️ Impresora
        </button>
        <button
          onClick={() => setActiveTab('security')}
          style={{
            padding: '10px 16px',
            borderRadius: '8px',
            border: 'none',
            background: activeTab === 'security' ? 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)' : 'var(--bg-tertiary, #f0f0f0)',
            color: activeTab === 'security' ? 'white' : 'var(--text-primary, #333)',
            cursor: 'pointer',
            fontWeight: 'bold',
            fontSize: '14px',
            flex: '1',
            minWidth: '100px',
            whiteSpace: 'nowrap',
            transition: 'all 0.3s ease'
          }}
        >
          🔐 Seguridad
        </button>
        <button
          onClick={() => setActiveTab('license')}
          style={{
            padding: '10px 16px',
            borderRadius: '8px',
            border: 'none',
            background: activeTab === 'license' ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' : 'var(--bg-tertiary, #f0f0f0)',
            color: activeTab === 'license' ? 'white' : 'var(--text-primary, #333)',
            cursor: 'pointer',
            fontWeight: 'bold',
            fontSize: '14px',
            flex: '1',
            minWidth: '100px',
            whiteSpace: 'nowrap',
            transition: 'all 0.3s ease'
          }}
        >
          🔑 Licencia
        </button>

        <button
          onClick={() => setActiveTab('styles')}
          style={{
            padding: '12px 20px',
            background: activeTab === 'styles' ? 'var(--accent, #0066cc)' : 'var(--bg-secondary, #f0f0f0)',
            color: activeTab === 'styles' ? 'white' : 'var(--text-primary, #333)',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
            fontWeight: activeTab === 'styles' ? 'bold' : 'normal',
            fontSize: '14px',
            minWidth: '100px',
            whiteSpace: 'nowrap',
            transition: 'all 0.3s ease'
          }}
        >
          🎨 Estilos
        </button>
        <button
          onClick={() => setActiveTab('updates')}
          style={{
            padding: '10px 16px',
            borderRadius: '8px',
            border: 'none',
            background: activeTab === 'updates' ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' : 'var(--bg-tertiary, #f0f0f0)',
            color: activeTab === 'updates' ? 'white' : 'var(--text-primary, #333)',
            cursor: 'pointer',
            fontWeight: 'bold',
            fontSize: '14px',
            flex: '1',
            minWidth: '100px',
            whiteSpace: 'nowrap',
            transition: 'all 0.3s ease'
          }}
        >
          🔄 Actualizaciones
        </button>
      </div>

      {/* User Profile Tab */}
      {activeTab === 'profile' && (
        <div style={{
          background: 'var(--card-bg, #fff)', 
          padding: '20px', 
          borderRadius: '12px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          maxWidth: '100%',
          width: '100%',
          overflowY: 'auto',
          maxHeight: 'calc(100vh - 200px)'
        }}>
          <h3 style={{ marginTop: 0 }}>Perfil de Usuario</h3>
          
          {/* Photo */}
          <div style={{ textAlign: 'center', marginBottom: '20px' }}>
            <div style={{
              width: '100px',
              height: '100px',
              borderRadius: '50%',
              background: 'var(--border-color, #ddd)',
              margin: '0 auto 15px',
              overflow: 'hidden',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '40px'
            }}>
              {userProfile.photo ? (
                <img src={userProfile.photo} alt="Foto de perfil" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              ) : (
                '👤'
              )}
            </div>
            <button
              onClick={() => fileInputRef.current?.click()}
              style={{
                padding: '8px',
                borderRadius: '50%',
                border: 'none',
                background: 'transparent',
                cursor: 'pointer',
                fontSize: '16px',
                transition: 'transform 0.2s, background 0.2s'
              }}
              title="Cambiar foto"
            >
              📷
            </button>
            {userProfile.photo && (
              <button
                onClick={() => updateUserPhoto('')}
                style={{
                  padding: '8px',
                  borderRadius: '50%',
                  border: 'none',
                  background: 'transparent',
                  cursor: 'pointer',
                  fontSize: '16px',
                  transition: 'transform 0.2s, background 0.2s'
                }}
                title="Quitar foto"
              >
                ❌
              </button>
            )}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handlePhotoUpload}
              style={{ display: 'none' }}
            />
          </div>

          <form>
            <div style={{ marginBottom: '15px' }}>
              <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold', color: 'var(--text-primary, #333)' }}>Nombre</label>
              <input
                type="text"
                value={userProfile.name}
                onChange={e => updateUserProfile({ name: e.target.value })}
                style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)', background: 'var(--bg-secondary, white)', color: 'var(--text-primary, #333)' }}
              />
            </div>

            <div style={{ marginBottom: '15px' }}>
              <label style={{ display: 'block', marginBottom: '5px', color: 'var(--text-primary, #333)' }}>Email</label>
              <input
                type="email"
                value={userProfile.email}
                onChange={e => updateUserProfile({ email: e.target.value })}
                style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)', background: 'var(--bg-secondary, white)', color: 'var(--text-primary, #333)' }}
              />
            </div>

            <div style={{ marginBottom: '15px' }}>
              <label style={{ display: 'block', marginBottom: '5px', color: 'var(--text-primary, #333)' }}>Telefono</label>
              <input
                type="tel"
                value={userProfile.phone}
                onChange={e => updateUserProfile({ phone: e.target.value })}
                style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)', background: 'var(--bg-secondary, white)', color: 'var(--text-primary, #333)' }}
              />
            </div>

            <div style={{ marginBottom: '15px' }}>
              <label style={{ display: 'block', marginBottom: '5px', color: 'var(--text-primary, #333)' }}>NIT</label>
              <input
                type="text"
                value={userProfile.nit}
                onChange={e => updateUserProfile({ nit: e.target.value })}
                style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)', background: 'var(--bg-secondary, white)', color: 'var(--text-primary, #333)' }}
              />
            </div>

            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', marginBottom: '5px', color: 'var(--text-primary, #333)' }}>Direccion</label>
              <input
                type="text"
                value={userProfile.address}
                onChange={e => updateUserProfile({ address: e.target.value })}
                style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)', background: 'var(--bg-secondary, white)', color: 'var(--text-primary, #333)' }}
              />
            </div>

            <button
              onClick={() => alert('Perfil guardado exitosamente')}
              style={{
                padding: '12px 24px',
                borderRadius: '8px',
                border: 'none',
                background: 'var(--accent, #0066cc)',
                color: 'white',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: 'bold'
              }}
            >
              💾 Guardar Cambios
            </button>
          </form>
        </div>
      )}

      {/* Printer Tab */}
      {activeTab === 'printer' && (
        <div style={{ 
          background: 'var(--card-bg, #fff)', 
          padding: '20px', 
          borderRadius: '12px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          maxWidth: '100%',
          width: '100%',
          overflowY: 'auto',
          maxHeight: 'calc(100vh - 200px)'
        }}>
          <h3 style={{ marginTop: 0 }}>Configuración de Impresora</h3>

          <div style={{ marginBottom: '12px' }}>
            <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold' }}>Impresora seleccionada</label>
            <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
              <select value={companyConfig.printerName || ''} onChange={e => updateCompanyConfig({ printerName: e.target.value })} style={{ flex: 1, padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)' }}>
                <option value="">-- Seleccionar impresora --</option>
                {(printers || []).map(p => (
                  <option key={p} value={p}>{p}</option>
                ))}
              </select>
              <div style={{ display: 'flex', gap: '8px' }}>
                <button type="button" onClick={async () => { await detectPrinters() }} style={{ padding: '8px 10px', borderRadius: '8px', background: '#2563eb', color: 'white', border: 'none' }}>Buscar</button>
              </div>
            </div>
            <p style={{ marginTop: '8px', fontSize: '12px', color: 'var(--text-secondary, #666)' }}>Si tu navegador no puede listar impresoras, usa <strong>Detectar</strong> para añadir una impresora manualmente; el nombre se guardará y se seleccionará automáticamente.</p>
          </div>

          <div style={{ display: 'flex', gap: '10px', marginBottom: '12px' }}>
            <div style={{ flex: 1 }}>
              <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold' }}>Tipo</label>
              <select value={(companyConfig as any).printerType || 'virtual'} onChange={e => updateCompanyConfig({ printerType: e.target.value })} style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)' }}>
                <option value="network">Network</option>
                <option value="usb">USB</option>
                <option value="virtual">Virtual (PDF)</option>
              </select>
            </div>
            <div style={{ width: '120px' }}>
              <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold' }}>Copias</label>
              <input type="number" min={1} value={(companyConfig as any).defaultCopies || 1} onChange={e => updateCompanyConfig({ defaultCopies: Number(e.target.value) })} style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)' }} />
            </div>
          </div>

          <div style={{ display: 'flex', gap: '10px', marginBottom: '12px' }}>
            <div style={{ flex: 1 }}>
              <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold' }}>IP (para impresora en red)</label>
              <input type="text" value={(companyConfig as any).ipAddress || ''} onChange={e => updateCompanyConfig({ ipAddress: e.target.value })} style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)' }} />
            </div>
            <div style={{ width: '120px' }}>
              <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold' }}>Puerto</label>
              <input type="number" min={1} value={(companyConfig as any).port || 9100} onChange={e => updateCompanyConfig({ port: Number(e.target.value) })} style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)' }} />
            </div>
          </div>

          <div style={{ marginBottom: '12px' }}>
            <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold' }}>Tamaño de papel</label>
            <select value={(companyConfig as any).paperSize || '80mm'} onChange={e => updateCompanyConfig({ paperSize: e.target.value })} style={{ width: '200px', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)' }}>
              <option value="80mm">80mm</option>
              <option value="57mm">57mm</option>
              <option value="Letter">Carta</option>
              <option value="Oficio">Oficio</option>
            </select>
          </div>

          {/* Opciones de Impresión */}
          <div style={{ 
            marginTop: '20px', 
            marginBottom: '20px',
            padding: '20px', 
            background: 'var(--bg-secondary, #f8f9fa)', 
            borderRadius: '8px',
            border: '2px solid var(--accent, #0066cc)'
          }}>
            <h4 style={{ marginTop: 0, color: 'var(--text-primary, #333)', marginBottom: '15px' }}>
              🖨️ Configuración de Impresión
            </h4>

            <div style={{ marginBottom: '15px' }}>
              <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
                <input
                  type="checkbox"
                  checked={companyConfig.autoPrint ?? false}
                  onChange={e => updateCompanyConfig({ autoPrint: e.target.checked })}
                  style={{ marginRight: '10px', width: '18px', height: '18px' }}
                />
                <span style={{ color: 'var(--text-primary, #333)', fontWeight: '500' }}>
                  Imprimir automáticamente después de cada venta
                </span>
              </label>
            </div>

            <div style={{ marginBottom: '15px' }}>
              <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
                <input
                  type="checkbox"
                  checked={companyConfig.saveToFolder ?? true}
                  onChange={e => updateCompanyConfig({ saveToFolder: e.target.checked })}
                  style={{ marginRight: '10px', width: '18px', height: '18px' }}
                />
                <span style={{ color: 'var(--text-primary, #333)', fontWeight: '500' }}>
                  Guardar factura en carpeta "Facturas"
                </span>
              </label>
            </div>

            <div style={{ marginBottom: '15px' }}>
              <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
                <input
                  type="checkbox"
                  checked={companyConfig.printSilent ?? true}
                  onChange={e => updateCompanyConfig({ printSilent: e.target.checked })}
                  style={{ marginRight: '10px', width: '18px', height: '18px' }}
                />
                <span style={{ color: 'var(--text-primary, #333)', fontWeight: '500' }}>
                  Impresión silenciosa (sin mostrar diálogo de impresión)
                </span>
              </label>
            </div>

            <p style={{ fontSize: '12px', color: 'var(--text-secondary, #666)', marginTop: '10px' }}>
              💡 Las opciones de impresión solo funcionan cuando la aplicación se ejecuta en Electron (no en el navegador).
            </p>
          </div>

          {/* Personalización de Diseño de Factura */}
          <div style={{ 
            marginTop: '20px', 
            marginBottom: '20px',
            padding: '20px', 
            background: 'var(--bg-secondary, #f8f9fa)', 
            borderRadius: '8px',
            border: '2px solid #667eea'
          }}>
            <h4 style={{ marginTop: 0, color: 'var(--text-primary, #333)', marginBottom: '15px' }}>
              🎨 Personalización de Diseño de Facturas
            </h4>

            {/* Selector de formato */}
            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold', fontSize: '14px' }}>
                Formato a personalizar:
              </label>
              <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
                <button
                  onClick={() => updateCompanyConfig({ designFormat: 'carta' })}
                  style={{
                    padding: '10px 20px',
                    borderRadius: '8px',
                    border: 'none',
                    background: ((companyConfig as any).designFormat || 'carta') === 'carta' ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' : '#e9ecef',
                    color: ((companyConfig as any).designFormat || 'carta') === 'carta' ? 'white' : '#333',
                    fontWeight: 'bold',
                    cursor: 'pointer'
                  }}
                >
                  📄 Carta
                </button>
                <button
                  onClick={() => updateCompanyConfig({ designFormat: 'ticket80' })}
                  style={{
                    padding: '10px 20px',
                    borderRadius: '8px',
                    border: 'none',
                    background: ((companyConfig as any).designFormat || 'carta') === 'ticket80' ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' : '#e9ecef',
                    color: ((companyConfig as any).designFormat || 'carta') === 'ticket80' ? 'white' : '#333',
                    fontWeight: 'bold',
                    cursor: 'pointer'
                  }}
                >
                  🧾 POS 80mm
                </button>
                <button
                  onClick={() => updateCompanyConfig({ designFormat: 'ticket57' })}
                  style={{
                    padding: '10px 20px',
                    borderRadius: '8px',
                    border: 'none',
                    background: ((companyConfig as any).designFormat || 'carta') === 'ticket57' ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' : '#e9ecef',
                    color: ((companyConfig as any).designFormat || 'carta') === 'ticket57' ? 'white' : '#333',
                    fontWeight: 'bold',
                    cursor: 'pointer'
                  }}
                >
                  🧾 POS 57mm
                </button>
                <button
                  onClick={() => updateCompanyConfig({ designFormat: 'cotizacion' })}
                  style={{
                    padding: '10px 20px',
                    borderRadius: '8px',
                    border: 'none',
                    background: ((companyConfig as any).designFormat || 'carta') === 'cotizacion' ? 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)' : '#e9ecef',
                    color: ((companyConfig as any).designFormat || 'carta') === 'cotizacion' ? 'white' : '#333',
                    fontWeight: 'bold',
                    cursor: 'pointer'
                  }}
                >
                  📋 Cotización
                </button>
              </div>
            </div>

            {/* Opciones para CARTA */}
            {((companyConfig as any).designFormat || 'carta') === 'carta' && (
              <>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                  <div>
                    <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold', fontSize: '13px' }}>
                      Color Principal (Header)
                    </label>
                    <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                      <input
                        type="color"
                        value={(companyConfig as any).invoiceColorPrimary || '#667eea'}
                        onChange={e => updateCompanyConfig({ invoiceColorPrimary: e.target.value })}
                        style={{ width: '50px', height: '40px', border: 'none', borderRadius: '6px', cursor: 'pointer' }}
                      />
                      <input
                        type="text"
                        value={(companyConfig as any).invoiceColorPrimary || '#667eea'}
                        onChange={e => updateCompanyConfig({ invoiceColorPrimary: e.target.value })}
                        style={{ flex: 1, padding: '8px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)', fontFamily: 'monospace' }}
                        placeholder="#667eea"
                      />
                    </div>
                  </div>

                  <div>
                    <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold', fontSize: '13px' }}>
                      Color Secundario (Header)
                    </label>
                    <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                      <input
                        type="color"
                        value={(companyConfig as any).invoiceColorSecondary || '#764ba2'}
                        onChange={e => updateCompanyConfig({ invoiceColorSecondary: e.target.value })}
                        style={{ width: '50px', height: '40px', border: 'none', borderRadius: '6px', cursor: 'pointer' }}
                      />
                      <input
                        type="text"
                        value={(companyConfig as any).invoiceColorSecondary || '#764ba2'}
                        onChange={e => updateCompanyConfig({ invoiceColorSecondary: e.target.value })}
                        style={{ flex: 1, padding: '8px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)', fontFamily: 'monospace' }}
                        placeholder="#764ba2"
                      />
                    </div>
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                  <div>
                    <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold', fontSize: '13px' }}>
                      Color de Acento (Bordes)
                    </label>
                    <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                      <input
                        type="color"
                        value={(companyConfig as any).invoiceColorAccent || '#667eea'}
                        onChange={e => updateCompanyConfig({ invoiceColorAccent: e.target.value })}
                        style={{ width: '50px', height: '40px', border: 'none', borderRadius: '6px', cursor: 'pointer' }}
                      />
                      <input
                        type="text"
                        value={(companyConfig as any).invoiceColorAccent || '#667eea'}
                        onChange={e => updateCompanyConfig({ invoiceColorAccent: e.target.value })}
                        style={{ flex: 1, padding: '8px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)', fontFamily: 'monospace' }}
                        placeholder="#667eea"
                      />
                    </div>
                  </div>

                  <div>
                    <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold', fontSize: '13px' }}>
                      Tamaño de Fuente Base
                    </label>
                    <select
                      value={(companyConfig as any).invoiceFontSize || '14'}
                      onChange={e => updateCompanyConfig({ invoiceFontSize: e.target.value })}
                      style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)' }}
                    >
                      <option value="12">Pequeño (12px)</option>
                      <option value="14">Mediano (14px)</option>
                      <option value="16">Grande (16px)</option>
                    </select>
                  </div>
                </div>

                <div style={{ marginBottom: '15px' }}>
                  <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold', fontSize: '13px' }}>
                    Fuente de la Factura
                  </label>
                  <select
                    value={(companyConfig as any).invoiceFontFamily || 'Segoe UI'}
                    onChange={e => updateCompanyConfig({ invoiceFontFamily: e.target.value })}
                    style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)' }}
                  >
                    <optgroup label="Sans-Serif (Modernas)">
                      <option value="Segoe UI">Segoe UI</option>
                      <option value="Arial">Arial</option>
                      <option value="Helvetica">Helvetica</option>
                      <option value="Helvetica Neue">Helvetica Neue</option>
                      <option value="Verdana">Verdana</option>
                      <option value="Tahoma">Tahoma</option>
                      <option value="Trebuchet MS">Trebuchet MS</option>
                      <option value="Calibri">Calibri</option>
                      <option value="Century Gothic">Century Gothic</option>
                      <option value="Franklin Gothic Medium">Franklin Gothic Medium</option>
                      <option value="Gill Sans">Gill Sans</option>
                      <option value="Futura">Futura</option>
                      <option value="Optima">Optima</option>
                      <option value="Candara">Candara</option>
                      <option value="Geneva">Geneva</option>
                      <option value="Lucida Grande">Lucida Grande</option>
                      <option value="Corbel">Corbel</option>
                      <option value="Impact">Impact</option>
                    </optgroup>
                    <optgroup label="Serif (Formales)">
                      <option value="Times New Roman">Times New Roman</option>
                      <option value="Georgia">Georgia</option>
                      <option value="Garamond">Garamond</option>
                      <option value="Palatino">Palatino</option>
                      <option value="Palatino Linotype">Palatino Linotype</option>
                      <option value="Book Antiqua">Book Antiqua</option>
                      <option value="Baskerville">Baskerville</option>
                      <option value="Cambria">Cambria</option>
                      <option value="Didot">Didot</option>
                      <option value="Bodoni MT">Bodoni MT</option>
                      <option value="Goudy Old Style">Goudy Old Style</option>
                      <option value="Perpetua">Perpetua</option>
                      <option value="Rockwell">Rockwell</option>
                      <option value="Constantia">Constantia</option>
                    </optgroup>
                    <optgroup label="Monoespaciadas">
                      <option value="Courier New">Courier New</option>
                      <option value="Courier">Courier</option>
                      <option value="Consolas">Consolas</option>
                      <option value="Monaco">Monaco</option>
                      <option value="Lucida Console">Lucida Console</option>
                      <option value="Andale Mono">Andale Mono</option>
                      <option value="Menlo">Menlo</option>
                    </optgroup>
                    <optgroup label="Decorativas">
                      <option value="Brush Script MT">Brush Script MT</option>
                      <option value="Copperplate">Copperplate</option>
                      <option value="Papyrus">Papyrus</option>
                      <option value="Comic Sans MS">Comic Sans MS</option>
                    </optgroup>
                    <optgroup label="Google Fonts (Requiere Internet)">
                      <option value="Roboto">Roboto</option>
                      <option value="Open Sans">Open Sans</option>
                      <option value="Lato">Lato</option>
                      <option value="Montserrat">Montserrat</option>
                      <option value="Oswald">Oswald</option>
                      <option value="Raleway">Raleway</option>
                      <option value="Poppins">Poppins</option>
                      <option value="Merriweather">Merriweather</option>
                      <option value="Playfair Display">Playfair Display</option>
                      <option value="Ubuntu">Ubuntu</option>
                      <option value="Nunito">Nunito</option>
                      <option value="PT Sans">PT Sans</option>
                      <option value="Source Sans Pro">Source Sans Pro</option>
                      <option value="Noto Sans">Noto Sans</option>
                      <option value="Inter">Inter</option>
                    </optgroup>
                  </select>
                </div>

                <div style={{ marginBottom: '15px' }}>
                  <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold', fontSize: '13px' }}>
                    Estilo de Texto
                  </label>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                    <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer', padding: '8px', background: 'white', borderRadius: '6px', border: '1px solid #ddd' }}>
                      <input
                        type="checkbox"
                        checked={(companyConfig as any).invoiceFontBold ?? false}
                        onChange={e => updateCompanyConfig({ invoiceFontBold: e.target.checked })}
                        style={{ marginRight: '8px', width: '16px', height: '16px' }}
                      />
                      <span style={{ fontWeight: 'bold' }}>Negrita</span>
                    </label>
                    <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer', padding: '8px', background: 'white', borderRadius: '6px', border: '1px solid #ddd' }}>
                      <input
                        type="checkbox"
                        checked={(companyConfig as any).invoiceFontItalic ?? false}
                        onChange={e => updateCompanyConfig({ invoiceFontItalic: e.target.checked })}
                        style={{ marginRight: '8px', width: '16px', height: '16px' }}
                      />
                      <span style={{ fontStyle: 'italic' }}>Cursiva</span>
                    </label>
                  </div>
                </div>

                <div style={{ marginBottom: '15px' }}>
                  <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold', fontSize: '13px' }}>
                    Peso de Fuente (Grosor)
                  </label>
                  <select
                    value={(companyConfig as any).invoiceFontWeight || '400'}
                    onChange={e => updateCompanyConfig({ invoiceFontWeight: e.target.value })}
                    style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)' }}
                  >
                    <option value="100">Ultraligera (100)</option>
                    <option value="200">Extraligera (200)</option>
                    <option value="300">Ligera (300)</option>
                    <option value="400">Normal (400)</option>
                    <option value="500">Media (500)</option>
                    <option value="600">Seminegrita (600)</option>
                    <option value="700">Negrita (700)</option>
                    <option value="800">Extranegrita (800)</option>
                    <option value="900">Ultranegrita (900)</option>
                  </select>
                </div>
              </>
            )}

            {/* Opciones para TICKETS POS (80mm y 57mm) */}
            {(((companyConfig as any).designFormat || 'carta') === 'ticket80' || ((companyConfig as any).designFormat || 'carta') === 'ticket57') && (
              <>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                  <div>
                    <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold', fontSize: '13px' }}>
                      Tamaño de Fuente Base
                    </label>
                    <select
                      value={(companyConfig as any).ticketFontSize || (((companyConfig as any).designFormat || 'carta') === 'ticket80' ? '11' : '9')}
                      onChange={e => updateCompanyConfig({ ticketFontSize: e.target.value })}
                      style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)' }}
                    >
                      <option value="8">Muy Pequeño (8px)</option>
                      <option value="9">Pequeño (9px)</option>
                      <option value="10">Pequeño-Mediano (10px)</option>
                      <option value="11">Mediano (11px)</option>
                      <option value="12">Grande (12px)</option>
                      <option value="13">Muy Grande (13px)</option>
                    </select>
                  </div>

                  <div>
                    <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold', fontSize: '13px' }}>
                      Fuente del Ticket
                    </label>
                    <select
                      value={(companyConfig as any).ticketFontFamily || 'Courier New'}
                      onChange={e => updateCompanyConfig({ ticketFontFamily: e.target.value })}
                      style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)' }}
                    >
                      <optgroup label="Monoespaciadas (Recomendadas para Tickets)">
                        <option value="Courier New">Courier New</option>
                        <option value="Courier">Courier</option>
                        <option value="Consolas">Consolas</option>
                        <option value="Monaco">Monaco</option>
                        <option value="Lucida Console">Lucida Console</option>
                        <option value="Andale Mono">Andale Mono</option>
                        <option value="Menlo">Menlo</option>
                        <option value="DejaVu Sans Mono">DejaVu Sans Mono</option>
                        <option value="Liberation Mono">Liberation Mono</option>
                      </optgroup>
                      <optgroup label="Sans-Serif (Compactas)">
                        <option value="Arial">Arial</option>
                        <option value="Arial Narrow">Arial Narrow</option>
                        <option value="Helvetica">Helvetica</option>
                        <option value="Helvetica Neue">Helvetica Neue</option>
                        <option value="Verdana">Verdana</option>
                        <option value="Tahoma">Tahoma</option>
                        <option value="Trebuchet MS">Trebuchet MS</option>
                        <option value="Calibri">Calibri</option>
                        <option value="Segoe UI">Segoe UI</option>
                        <option value="Geneva">Geneva</option>
                        <option value="Lucida Grande">Lucida Grande</option>
                        <option value="Corbel">Corbel</option>
                      </optgroup>
                      <optgroup label="Serif (Compactas)">
                        <option value="Times New Roman">Times New Roman</option>
                        <option value="Times">Times</option>
                        <option value="Georgia">Georgia</option>
                        <option value="Palatino">Palatino</option>
                        <option value="Garamond">Garamond</option>
                      </optgroup>
                      <optgroup label="Google Fonts Monoespaciadas (Requiere Internet)">
                        <option value="Roboto Mono">Roboto Mono</option>
                        <option value="Source Code Pro">Source Code Pro</option>
                        <option value="Fira Code">Fira Code</option>
                        <option value="JetBrains Mono">JetBrains Mono</option>
                        <option value="IBM Plex Mono">IBM Plex Mono</option>
                        <option value="Ubuntu Mono">Ubuntu Mono</option>
                      </optgroup>
                      <optgroup label="Google Fonts Sans-Serif (Requiere Internet)">
                        <option value="Roboto">Roboto</option>
                        <option value="Open Sans">Open Sans</option>
                        <option value="Lato">Lato</option>
                        <option value="Montserrat">Montserrat</option>
                        <option value="Poppins">Poppins</option>
                        <option value="Ubuntu">Ubuntu</option>
                        <option value="Nunito">Nunito</option>
                        <option value="PT Sans">PT Sans</option>
                      </optgroup>
                    </select>
                  </div>

                  <div>
                    <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold', fontSize: '13px' }}>
                      Peso de Fuente
                    </label>
                    <select
                      value={(companyConfig as any).ticketFontWeight || '400'}
                      onChange={e => updateCompanyConfig({ ticketFontWeight: e.target.value })}
                      style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)' }}
                    >
                      <option value="300">Ligera (300)</option>
                      <option value="400">Normal (400)</option>
                      <option value="500">Media (500)</option>
                      <option value="600">Seminegrita (600)</option>
                      <option value="700">Negrita (700)</option>
                      <option value="800">Extranegrita (800)</option>
                      <option value="900">Ultranegrita (900)</option>
                    </select>
                  </div>
                </div>

                <div style={{ marginBottom: '15px' }}>
                  <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold', fontSize: '13px' }}>
                    Espaciado entre líneas
                  </label>
                  <select
                    value={(companyConfig as any).ticketLineSpacing || 'normal'}
                    onChange={e => updateCompanyConfig({ ticketLineSpacing: e.target.value })}
                    style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)' }}
                  >
                    <option value="compact">Compacto (1.2)</option>
                    <option value="normal">Normal (1.4)</option>
                    <option value="relaxed">Relajado (1.6)</option>
                  </select>
                </div>

                <div style={{ marginBottom: '15px' }}>
                  <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
                    <input
                      type="checkbox"
                      checked={(companyConfig as any).ticketShowBorders ?? true}
                      onChange={e => updateCompanyConfig({ ticketShowBorders: e.target.checked })}
                      style={{ marginRight: '10px', width: '18px', height: '18px' }}
                    />
                    <span style={{ color: 'var(--text-primary, #333)', fontWeight: '500' }}>
                      Mostrar líneas separadoras
                    </span>
                  </label>
                </div>

                <div style={{ marginBottom: '15px' }}>
                  <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
                    <input
                      type="checkbox"
                      checked={(companyConfig as any).ticketBoldHeaders ?? true}
                      onChange={e => updateCompanyConfig({ ticketBoldHeaders: e.target.checked })}
                      style={{ marginRight: '10px', width: '18px', height: '18px' }}
                    />
                    <span style={{ color: 'var(--text-primary, #333)', fontWeight: '500' }}>
                      Encabezados en negrita
                    </span>
                  </label>
                </div>
              </>
            )}

            {/* Opciones para COTIZACIÓN */}
            {((companyConfig as any).designFormat || 'carta') === 'cotizacion' && (
              <>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                  <div>
                    <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold', fontSize: '13px' }}>
                      Color Principal (Header)
                    </label>
                    <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                      <input
                        type="color"
                        value={(companyConfig as any).quoteColorPrimary || '#f59e0b'}
                        onChange={e => updateCompanyConfig({ quoteColorPrimary: e.target.value })}
                        style={{ width: '50px', height: '40px', border: 'none', borderRadius: '6px', cursor: 'pointer' }}
                      />
                      <input
                        type="text"
                        value={(companyConfig as any).quoteColorPrimary || '#f59e0b'}
                        onChange={e => updateCompanyConfig({ quoteColorPrimary: e.target.value })}
                        style={{ flex: 1, padding: '8px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)', fontFamily: 'monospace' }}
                        placeholder="#f59e0b"
                      />
                    </div>
                  </div>

                  <div>
                    <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold', fontSize: '13px' }}>
                      Color Secundario (Header)
                    </label>
                    <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                      <input
                        type="color"
                        value={(companyConfig as any).quoteColorSecondary || '#d97706'}
                        onChange={e => updateCompanyConfig({ quoteColorSecondary: e.target.value })}
                        style={{ width: '50px', height: '40px', border: 'none', borderRadius: '6px', cursor: 'pointer' }}
                      />
                      <input
                        type="text"
                        value={(companyConfig as any).quoteColorSecondary || '#d97706'}
                        onChange={e => updateCompanyConfig({ quoteColorSecondary: e.target.value })}
                        style={{ flex: 1, padding: '8px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)', fontFamily: 'monospace' }}
                        placeholder="#d97706"
                      />
                    </div>
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                  <div>
                    <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold', fontSize: '13px' }}>
                      Color de Acento (Cliente)
                    </label>
                    <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                      <input
                        type="color"
                        value={(companyConfig as any).quoteColorAccent || '#3b82f6'}
                        onChange={e => updateCompanyConfig({ quoteColorAccent: e.target.value })}
                        style={{ width: '50px', height: '40px', border: 'none', borderRadius: '6px', cursor: 'pointer' }}
                      />
                      <input
                        type="text"
                        value={(companyConfig as any).quoteColorAccent || '#3b82f6'}
                        onChange={e => updateCompanyConfig({ quoteColorAccent: e.target.value })}
                        style={{ flex: 1, padding: '8px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)', fontFamily: 'monospace' }}
                        placeholder="#3b82f6"
                      />
                    </div>
                  </div>

                  <div>
                    <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold', fontSize: '13px' }}>
                      Tamaño de Fuente Base
                    </label>
                    <select
                      value={(companyConfig as any).quoteFontSize || '14'}
                      onChange={e => updateCompanyConfig({ quoteFontSize: e.target.value })}
                      style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)' }}
                    >
                      <option value="12">Pequeño (12px)</option>
                      <option value="14">Mediano (14px)</option>
                      <option value="16">Grande (16px)</option>
                    </select>
                  </div>
                </div>

                <div style={{ marginBottom: '15px' }}>
                  <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold', fontSize: '13px' }}>
                    Fuente de la Cotización
                  </label>
                  <select
                    value={(companyConfig as any).quoteFontFamily || 'Segoe UI'}
                    onChange={e => updateCompanyConfig({ quoteFontFamily: e.target.value })}
                    style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)' }}
                  >
                    <optgroup label="Sans-Serif (Modernas)">
                      <option value="Segoe UI">Segoe UI</option>
                      <option value="Arial">Arial</option>
                      <option value="Helvetica">Helvetica</option>
                      <option value="Verdana">Verdana</option>
                      <option value="Tahoma">Tahoma</option>
                      <option value="Trebuchet MS">Trebuchet MS</option>
                      <option value="Calibri">Calibri</option>
                      <option value="Century Gothic">Century Gothic</option>
                    </optgroup>
                    <optgroup label="Serif (Clásicas)">
                      <option value="Times New Roman">Times New Roman</option>
                      <option value="Georgia">Georgia</option>
                      <option value="Garamond">Garamond</option>
                      <option value="Palatino">Palatino</option>
                      <option value="Baskerville">Baskerville</option>
                    </optgroup>
                  </select>
                </div>

                <div style={{ marginBottom: '15px' }}>
                  <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold', fontSize: '13px' }}>
                    Días de validez de la cotización
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="365"
                    value={(companyConfig as any).quoteValidityDays || 15}
                    onChange={e => updateCompanyConfig({ quoteValidityDays: parseInt(e.target.value) || 15 })}
                    style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)' }}
                    placeholder="15"
                  />
                  <small style={{ color: '#6c757d', fontSize: '12px' }}>
                    Número de días que la cotización será válida (por defecto 15 días)
                  </small>
                </div>

                <div style={{ marginBottom: '15px' }}>
                  <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold', fontSize: '13px' }}>
                    Términos y Condiciones de la Cotización
                  </label>
                  <textarea
                    value={(companyConfig as any).quoteTerms || 'Después de {dias} días, no nos hacemos responsables de cambios en el valor de los productos o servicios cotizados, los precios están sujetos a disponibilidad de inventario al momento de confirmar el pedido, para confirmar su pedido se requiere un anticipo del 50% del valor total, el tiempo de entrega será confirmado al momento de realizar el pedido, los productos o servicios no incluyen instalación, transporte o configuración salvo que se especifique lo contrario, esta cotización no constituye una factura ni un compromiso de compra hasta su confirmación formal.'}
                    onChange={e => updateCompanyConfig({ quoteTerms: e.target.value })}
                    style={{ 
                      width: '100%', 
                      padding: '10px', 
                      borderRadius: '6px', 
                      border: '1px solid var(--border-color, #ddd)',
                      minHeight: '120px',
                      fontFamily: 'inherit',
                      fontSize: '13px',
                      resize: 'vertical'
                    }}
                    placeholder="Escribe los términos y condiciones..."
                  />
                  <small style={{ color: '#6c757d', fontSize: '12px' }}>
                    Usa {'{dias}'} para insertar automáticamente los días de validez. Ejemplo: "Después de {'{dias}'} días..."
                  </small>
                </div>

                <div style={{ marginBottom: '15px' }}>
                  <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
                    <input
                      type="checkbox"
                      checked={(companyConfig as any).quoteShowLogo ?? true}
                      onChange={e => updateCompanyConfig({ quoteShowLogo: e.target.checked })}
                      style={{ marginRight: '10px', width: '18px', height: '18px' }}
                    />
                    <span style={{ color: 'var(--text-primary, #333)', fontWeight: '500' }}>
                      Mostrar logo de la empresa
                    </span>
                  </label>
                </div>

                <div style={{ marginBottom: '15px' }}>
                  <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold', fontSize: '13px' }}>
                    Ancho máximo del logo (px)
                  </label>
                  <input
                    type="number"
                    min="50"
                    max="300"
                    value={(companyConfig as any).quoteLogoWidth || 120}
                    onChange={e => updateCompanyConfig({ quoteLogoWidth: parseInt(e.target.value) || 120 })}
                    style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)' }}
                    placeholder="120"
                  />
                  <small style={{ color: '#6c757d', fontSize: '12px' }}>
                    Ancho máximo del logo en píxeles (por defecto 120px)
                  </small>
                </div>

                <div style={{ marginBottom: '15px' }}>
                  <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold', fontSize: '13px' }}>
                    Altura máxima del logo (px)
                  </label>
                  <input
                    type="number"
                    min="30"
                    max="200"
                    value={(companyConfig as any).quoteLogoHeight || 70}
                    onChange={e => updateCompanyConfig({ quoteLogoHeight: parseInt(e.target.value) || 70 })}
                    style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)' }}
                    placeholder="70"
                  />
                  <small style={{ color: '#6c757d', fontSize: '12px' }}>
                    Altura máxima del logo en píxeles (por defecto 70px)
                  </small>
                </div>

                <div style={{ marginBottom: '15px', padding: '15px', background: '#f8f9fa', borderRadius: '8px', border: '1px solid #dee2e6' }}>
                  <label style={{ display: 'block', marginBottom: '10px', fontWeight: 'bold', fontSize: '14px', color: '#495057' }}>
                    Información del Cliente a Mostrar
                  </label>
                  
                  <div style={{ display: 'grid', gap: '8px' }}>
                    <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
                      <input
                        type="checkbox"
                        checked={(companyConfig as any).quoteShowClientName ?? true}
                        onChange={e => updateCompanyConfig({ quoteShowClientName: e.target.checked })}
                        style={{ marginRight: '10px', width: '16px', height: '16px' }}
                      />
                      <span style={{ color: 'var(--text-primary, #333)', fontSize: '13px' }}>
                        Nombre del cliente
                      </span>
                    </label>

                    <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
                      <input
                        type="checkbox"
                        checked={(companyConfig as any).quoteShowClientEmail ?? false}
                        onChange={e => updateCompanyConfig({ quoteShowClientEmail: e.target.checked })}
                        style={{ marginRight: '10px', width: '16px', height: '16px' }}
                      />
                      <span style={{ color: 'var(--text-primary, #333)', fontSize: '13px' }}>
                        Email del cliente
                      </span>
                    </label>

                    <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
                      <input
                        type="checkbox"
                        checked={(companyConfig as any).quoteShowClientPhone ?? false}
                        onChange={e => updateCompanyConfig({ quoteShowClientPhone: e.target.checked })}
                        style={{ marginRight: '10px', width: '16px', height: '16px' }}
                      />
                      <span style={{ color: 'var(--text-primary, #333)', fontSize: '13px' }}>
                        Teléfono del cliente
                      </span>
                    </label>

                    <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
                      <input
                        type="checkbox"
                        checked={(companyConfig as any).quoteShowClientAddress ?? false}
                        onChange={e => updateCompanyConfig({ quoteShowClientAddress: e.target.checked })}
                        style={{ marginRight: '10px', width: '16px', height: '16px' }}
                      />
                      <span style={{ color: 'var(--text-primary, #333)', fontSize: '13px' }}>
                        Dirección del cliente
                      </span>
                    </label>

                    <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
                      <input
                        type="checkbox"
                        checked={(companyConfig as any).quoteShowClientDocument ?? false}
                        onChange={e => updateCompanyConfig({ quoteShowClientDocument: e.target.checked })}
                        style={{ marginRight: '10px', width: '16px', height: '16px' }}
                      />
                      <span style={{ color: 'var(--text-primary, #333)', fontSize: '13px' }}>
                        Documento/NIT del cliente
                      </span>
                    </label>
                  </div>
                  
                  <small style={{ color: '#6c757d', fontSize: '11px', display: 'block', marginTop: '10px' }}>
                    Selecciona qué información del cliente deseas mostrar en la cotización
                  </small>
                </div>
              </>
            )}

            {/* Opciones comunes para todos los formatos */}
            <div style={{ marginTop: '20px', paddingTop: '20px', borderTop: '1px solid #dee2e6' }}>
              <h5 style={{ marginBottom: '15px', color: 'var(--text-primary, #333)' }}>Opciones Comunes</h5>
              
              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '6px', fontWeight: 'bold', fontSize: '13px' }}>
                  Pie de página de factura
                </label>
                <textarea
                  value={(companyConfig as any).invoiceFooterText || '¡Gracias por su compra!'}
                  onChange={e => updateCompanyConfig({ invoiceFooterText: e.target.value })}
                  style={{ 
                    width: '100%', 
                    padding: '10px', 
                    borderRadius: '6px', 
                    border: '1px solid var(--border-color, #ddd)',
                    minHeight: '60px',
                    resize: 'vertical',
                    fontFamily: 'inherit'
                  }}
                  placeholder="Ej: ¡Gracias por su compra! Política de devoluciones: 30 días."
                />
                <p style={{ fontSize: '11px', color: 'var(--text-secondary, #666)', marginTop: '5px' }}>
                  Este texto aparecerá al pie de todas las facturas
                </p>
              </div>

              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
                  <input
                    type="checkbox"
                    checked={(companyConfig as any).invoiceShowLogo ?? true}
                    onChange={e => updateCompanyConfig({ invoiceShowLogo: e.target.checked })}
                    style={{ marginRight: '10px', width: '18px', height: '18px' }}
                  />
                  <span style={{ color: 'var(--text-primary, #333)', fontWeight: '500' }}>
                    Mostrar logo en la factura
                  </span>
                </label>
              </div>
            </div>

            <p style={{ fontSize: '12px', color: 'var(--text-secondary, #666)', marginTop: '15px', padding: '10px', background: '#fff3cd', borderRadius: '6px', border: '1px solid #ffc107' }}>
              💡 Los cambios se aplicarán en las próximas facturas generadas. Selecciona el formato arriba para personalizar cada tipo de factura.
            </p>
          </div>

          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
            <button onClick={() => alert('Guardado') } style={{ padding: '10px 14px', borderRadius: '8px', background: '#06b6d4', color: 'white', border: 'none', fontWeight: 'bold', cursor: 'pointer' }}>💾 Guardar</button>
            <button 
              onClick={() => {
                // Generar vista previa de la factura con configuración actual
                const format = (companyConfig as any).designFormat || 'carta'
                const previewHTML = generateInvoicePreview(companyConfig, format)
                
                // Abrir en nueva ventana
                const previewWindow = window.open('', '_blank', 'width=900,height=800')
                if (previewWindow) {
                  previewWindow.document.write(previewHTML)
                  previewWindow.document.close()
                }
              }} 
              style={{ padding: '10px 14px', borderRadius: '8px', background: '#8b5cf6', color: 'white', border: 'none', fontWeight: 'bold', cursor: 'pointer' }}
            >
              👁️ Vista Previa
            </button>
            <button onClick={() => alert('Prueba de impresión enviada (simulada)')} style={{ padding: '10px 14px', borderRadius: '8px', background: '#10b981', color: 'white', border: 'none', fontWeight: 'bold', cursor: 'pointer' }}>🧾 Probar impresión</button>
            <button 
              onClick={() => {
                if (confirm('¿Restaurar todas las configuraciones de diseño a los valores por defecto?')) {
                  // Restaurar valores por defecto
                  updateCompanyConfig({
                    // Carta
                    invoiceColorPrimary: '#667eea',
                    invoiceColorSecondary: '#764ba2',
                    invoiceColorAccent: '#667eea',
                    invoiceFontSize: '14',
                    invoiceFontFamily: 'Segoe UI',
                    invoiceFontBold: false,
                    invoiceFontItalic: false,
                    invoiceFontWeight: '400',
                    // Tickets
                    ticketFontSize: '11',
                    ticketFontFamily: 'Courier New',
                    ticketFontWeight: '400',
                    ticketLineSpacing: 'normal',
                    ticketShowBorders: true,
                    ticketBoldHeaders: true,
                    // Cotizaciones
                    quoteColorPrimary: '#f59e0b',
                    quoteColorSecondary: '#d97706',
                    quoteColorAccent: '#3b82f6',
                    quoteFontSize: '14',
                    quoteFontFamily: 'Segoe UI',
                    quoteValidityDays: 15,
                    quoteShowLogo: true,
                    quoteLogoWidth: 120,
                    quoteLogoHeight: 70,
                    quoteShowClientName: true,
                    quoteShowClientEmail: false,
                    quoteShowClientPhone: false,
                    quoteShowClientAddress: false,
                    quoteShowClientDocument: false,
                    quoteTerms: 'Después de {dias} días, no nos hacemos responsables de cambios en el valor de los productos o servicios cotizados, los precios están sujetos a disponibilidad de inventario al momento de confirmar el pedido, para confirmar su pedido se requiere un anticipo del 50% del valor total, el tiempo de entrega será confirmado al momento de realizar el pedido, los productos o servicios no incluyen instalación, transporte o configuración salvo que se especifique lo contrario, esta cotización no constituye una factura ni un compromiso de compra hasta su confirmación formal.',
                    // Comunes
                    invoiceFooterText: '¡Gracias por su compra!',
                    invoiceShowLogo: true,
                    designFormat: 'carta'
                  })
                  alert('Configuraciones restauradas a valores por defecto')
                }
              }} 
              style={{ padding: '10px 14px', borderRadius: '8px', background: '#f59e0b', color: 'white', border: 'none', fontWeight: 'bold', cursor: 'pointer' }}
            >
              🔄 Restaurar por Defecto
            </button>
            { (printers || []).length > 0 && (
              <button type="button" onClick={() => {
                const selected = companyConfig.printerName || ''
                if (!selected) return alert('Seleccione una impresora primero')
                if (!confirm(`Eliminar impresora "${selected}"?`)) return
                removePrinter(selected)
                updateCompanyConfig({ printerName: '' })
              }} style={{ padding: '10px 14px', borderRadius: '8px', background: '#ef4444', color: 'white', border: 'none', fontWeight: 'bold', cursor: 'pointer' }}>🗑️ Eliminar impresora</button>
            )}
          </div>
        </div>
      )}

      {/* Company Tab */}
      {activeTab === 'company' && (
        <div style={{ 
          background: 'var(--card-bg, #fff)', 
          padding: '20px', 
          borderRadius: '12px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          maxWidth: '100%',
          width: '100%',
          overflowY: 'auto',
          maxHeight: 'calc(100vh - 200px)'
        }}>
          <h3 style={{ marginTop: 0, color: 'var(--text-primary, #333)' }}>Configuracion de la Empresa</h3>

          <div style={{ marginBottom: '15px' }}>
            <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold', color: 'var(--text-primary, #333)' }}>Nombre de la Empresa</label>
            <input
              type="text"
              value={companyConfig.companyName}
              onChange={e => updateCompanyConfig({ companyName: e.target.value })}
              style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)', background: 'var(--bg-secondary, white)', color: 'var(--text-primary, #333)' }}
            />
          </div>

          <div style={{ marginBottom: '15px' }}>
            <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold', color: 'var(--text-primary, #333)' }}>Logo de la Empresa</label>
            <input
              type="file"
              accept="image/*"
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                const file = e.target.files?.[0]
                if (file) {
                  const reader = new FileReader()
                  reader.onload = (event) => {
                    if (event.target?.result) {
                      updateCompanyConfig({ logo: event.target.result as string })
                    }
                  }
                  reader.readAsDataURL(file)
                }
              }}
              style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)', background: 'var(--bg-secondary, white)', color: 'var(--text-primary, #333)' }}
            />
            {companyConfig.logo && (
              <div style={{ marginTop: '10px', textAlign: 'center' }}>
                <img 
                  src={companyConfig.logo} 
                  alt="Logo" 
                  style={{ maxWidth: '150px', maxHeight: '80px', objectFit: 'contain' }}
                />
                <button
                  type="button"
                  onClick={() => updateCompanyConfig({ logo: '' })}
                  style={{
                    display: 'block',
                    margin: '10px auto 0',
                    padding: '6px 12px',
                    background: '#ef4444',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer'
                  }}
                >
                  Eliminar Logo
                </button>
              </div>
            )}
          </div>

          <div style={{ marginBottom: '15px' }}>
            <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold', color: 'var(--text-primary, #333)' }}>NIT de la Empresa</label>
            <input
              type="text"
              value={companyConfig.companyNIT}
              onChange={e => updateCompanyConfig({ companyNIT: e.target.value })}
              style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--border-color, #ddd)', background: 'var(--bg-secondary, white)', color: 'var(--text-primary, #333)' }}
            />
          </div>

          <div style={{ marginBottom: '15px' }}>
            <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold', color: 'var(--text-primary, #333)' }}>
              Porcentaje de IVA ({companyConfig.taxRate}%)
            </label>
            <input
              type="range"
              min="0"
              max="30"
              value={companyConfig.taxRate}
              onChange={e => updateCompanyConfig({ taxRate: Number(e.target.value) })}
              style={{ width: '100%' }}
            />
          </div>

          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer', color: 'var(--text-primary, #333)' }}>
              <input
                type="checkbox"
                checked={companyConfig.applyTax}
                onChange={e => updateCompanyConfig({ applyTax: e.target.checked })}
              />
              <span> Aplicar IVA a las ventas</span>
            </label>
          </div>

          {/* Se removieron las opciones de formato/impresión de factura */}
          {/* El pie de página de factura ahora está en la sección Impresora */}

          <button
            onClick={() => alert('Configuracion de empresa guardada')}
            style={{
              padding: '12px 24px',
              borderRadius: '8px',
              border: 'none',
              background: 'var(--accent, #0066cc)',
              color: 'white',
              cursor: 'pointer',
              fontSize: '14px',
              fontWeight: 'bold'
            }}
          >
            💾 Guardar Cambios
          </button>
        </div>
      )}

      {/* Backup Tab */}
      {activeTab === 'backup' && (
        <div style={{ 
          background: 'var(--card-bg, #fff)', 
          padding: '20px', 
          borderRadius: '12px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          maxWidth: '100%',
          width: '100%',
          overflowY: 'auto',
          maxHeight: 'calc(100vh - 200px)'
        }}>
          <h3 style={{ marginTop: 0, color: 'var(--text-primary, #333)' }}>Respaldo y Restauracion</h3>

          {/* Checkbox para respaldo automático */}
          <div style={{
            marginBottom: '30px',
            padding: '15px',
            background: 'var(--bg-tertiary, #f0f8ff)',
            borderRadius: '8px',
            border: '1px solid #0066cc'
          }}>
            <label style={{
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              cursor: 'pointer',
              fontSize: '14px',
              color: 'var(--text-primary, #333)'
            }}>
              <input
                type="checkbox"
                checked={autoBackupEnabled}
                onChange={(e) => {
                  const newValue = e.target.checked
                  setAutoBackupEnabled(newValue)
                  localStorage.setItem('pos_auto_backup', newValue.toString())
                }}
                style={{
                  width: '20px',
                  height: '20px',
                  cursor: 'pointer'
                }}
              />
              <div>
                <strong>Activar Respaldo Automático</strong>
                <p style={{ margin: '5px 0 0 0', fontSize: '12px', color: 'var(--text-secondary, #666)' }}>
                  Cuando está activo, se crea automáticamente una copia de seguridad silenciosa al cerrar sesión.
                  Los respaldos se guardan internamente y se mantienen los últimos 5 respaldos.
                </p>
              </div>
            </label>
          </div>

          <div style={{ marginBottom: '30px' }}>
            <h4 style={{ color: 'var(--text-primary, #333)' }}>Exportar Respaldo</h4>
            <p style={{ color: 'var(--text-secondary, #666)', marginBottom: '15px' }}>
              Descarga todos los datos del sistema incluyendo clientes, productos, ventas y configuracion.
            </p>
            <button
              onClick={exportBackup}
              style={{
                padding: '12px 24px',
                borderRadius: '8px',
                border: 'none',
                background: '#27ae60',
                color: 'white',
                cursor: 'pointer',
                fontSize: '14px'
              }}
            >
              📥 Descargar Respaldo
            </button>
          </div>

          <div style={{ marginBottom: '30px' }}>
            <h4 style={{ color: 'var(--text-primary, #333)' }}>Importar Respaldo</h4>
            <p style={{ color: 'var(--text-secondary, #666)', marginBottom: '15px' }}>
              Restaura los datos desde un archivo de respaldo previo.
              <br />
              <strong style={{ color: 'var(--text-primary, #333)' }}>Warning:</strong> Esto reemplazara todos los datos actuales.
            </p>
            <label
              style={{
                padding: '12px 24px',
                borderRadius: '8px',
                border: '1px solid var(--border-color)',
                background: 'var(--bg-tertiary)',
                cursor: 'pointer',
                fontSize: '14px',
                display: 'inline-block'
              }}
            >
              📤 Importar Respaldo
              <input
                ref={backupInputRef}
                type="file"
                accept=".json"
                onChange={handleBackupImport}
                style={{ display: 'none' }}
              />
            </label>
          </div>

          {/* Respaldos automáticos guardados */}
          <div style={{ marginBottom: '30px' }}>
            <div 
              onClick={() => setExpandedBackup(expandedBackup === 'main' ? null : 'main')}
              style={{ 
                cursor: 'pointer',
                padding: '15px',
                background: expandedBackup === 'main' ? 'var(--bg-secondary, #f0f0f0)' : 'var(--bg-tertiary, #f8f9fa)',
                borderRadius: '8px',
                border: '1px solid var(--border-color, #ddd)',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                transition: 'background 0.2s'
              }}
            >
              <div>
                <h4 style={{ margin: 0, color: 'var(--text-primary, #333)' }}>📦 Respaldos Automáticos</h4>
                <p style={{ margin: '5px 0 0 0', fontSize: '12px', color: 'var(--text-secondary, #666)' }}>
                  {(() => {
                    const allKeys = Object.keys(localStorage)
                    const backupKeys = allKeys.filter(k => k.startsWith('pos_backup_'))
                    return `${backupKeys.length} respaldo${backupKeys.length !== 1 ? 's' : ''} guardado${backupKeys.length !== 1 ? 's' : ''}`
                  })()}
                </p>
              </div>
              <div style={{ 
                fontSize: '24px', 
                color: 'var(--text-secondary, #666)',
                transform: expandedBackup === 'main' ? 'rotate(180deg)' : 'rotate(0deg)',
                transition: 'transform 0.3s'
              }}>
                ▼
              </div>
            </div>
            
            {expandedBackup === 'main' && (
              <div style={{ 
                marginTop: '10px',
                padding: '15px',
                background: 'var(--bg-secondary, #f8f9fa)', 
                borderRadius: '8px',
                border: '1px solid var(--border-color, #ddd)'
              }}>
                <p style={{ color: 'var(--text-secondary, #666)', marginBottom: '15px', fontSize: '12px' }}>
                  Últimos respaldos automáticos creados al cerrar sesión.
                  <br />
                  <strong>📁 Ubicación:</strong> Almacenados en localStorage del navegador (AppData/Local/Google/Chrome o similar)
                </p>
                
                {(() => {
                  const allKeys = Object.keys(localStorage)
                  const backupKeys = allKeys.filter(k => k.startsWith('pos_backup_')).sort().reverse()
                  
                  if (backupKeys.length === 0) {
                    return <p style={{ color: 'var(--text-secondary, #666)', fontSize: '13px', margin: 0 }}>No hay respaldos automáticos guardados</p>
                  }
                  
                  return (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                      {backupKeys.map((key, index) => {
                        const backup = JSON.parse(localStorage.getItem(key) || '{}')
                        const timestamp = backup.timestamp ? new Date(backup.timestamp).toLocaleString('es-ES') : 'Fecha desconocida'
                        const backupSize = new Blob([JSON.stringify(backup)]).size
                        const sizeKB = (backupSize / 1024).toFixed(2)
                        
                        return (
                          <div key={key} style={{ 
                            background: 'var(--card-bg, white)', 
                            padding: '12px', 
                            borderRadius: '6px',
                            border: '1px solid var(--border-color, #ddd)'
                          }}>
                            <div style={{ marginBottom: '10px' }}>
                              <strong style={{ fontSize: '14px', color: 'var(--text-primary, #333)' }}>
                                Respaldo #{backupKeys.length - index}
                              </strong>
                              <p style={{ margin: '5px 0 0 0', fontSize: '12px', color: 'var(--text-secondary, #666)' }}>
                                📅 {timestamp}
                              </p>
                              <p style={{ margin: '3px 0 0 0', fontSize: '11px', color: 'var(--text-secondary, #999)' }}>
                                📁 localStorage → {key}
                              </p>
                              <p style={{ margin: '3px 0 0 0', fontSize: '11px', color: 'var(--text-secondary, #999)' }}>
                                💾 Tamaño: {sizeKB} KB
                              </p>
                            </div>
                            
                            <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation()
                                  if (confirm(`¿Restaurar este respaldo?\n\nFecha: ${timestamp}\n\nEsto reemplazará todos los datos actuales.`)) {
                                    try {
                                      const backupData = JSON.parse(localStorage.getItem(key) || '{}')
                                      if (backupData.data) {
                                        Object.entries(backupData.data).forEach(([k, v]) => {
                                          localStorage.setItem(k, v as string)
                                        })
                                        alert('Respaldo restaurado exitosamente. La página se recargará.')
                                        window.location.reload()
                                      }
                                    } catch (err) {
                                      alert('Error al restaurar el respaldo')
                                    }
                                  }
                                }}
                                style={{
                                  padding: '8px 14px',
                                  borderRadius: '4px',
                                  border: 'none',
                                  background: '#27ae60',
                                  color: 'white',
                                  cursor: 'pointer',
                                  fontSize: '12px',
                                  fontWeight: 'bold'
                                }}
                              >
                                ♻️ Restaurar
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation()
                                  try {
                                    const backupData = localStorage.getItem(key)
                                    if (backupData) {
                                      const blob = new Blob([backupData], { type: 'application/json' })
                                      const url = URL.createObjectURL(blob)
                                      const a = document.createElement('a')
                                      a.href = url
                                      const date = new Date(backup.timestamp)
                                      const dateStr = date.toISOString().split('T')[0]
                                      const timeStr = date.toTimeString().split(' ')[0].replace(/:/g, '-')
                                      a.download = `respaldo_${dateStr}_${timeStr}.json`
                                      document.body.appendChild(a)
                                      a.click()
                                      document.body.removeChild(a)
                                      URL.revokeObjectURL(url)
                                    }
                                  } catch (err) {
                                    alert('Error al descargar el respaldo')
                                  }
                                }}
                                style={{
                                  padding: '8px 14px',
                                  borderRadius: '4px',
                                  border: 'none',
                                  background: '#3498db',
                                  color: 'white',
                                  cursor: 'pointer',
                                  fontSize: '12px',
                                  fontWeight: 'bold'
                                }}
                              >
                                📥 Descargar
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation()
                                  if (confirm('¿Eliminar este respaldo?')) {
                                    localStorage.removeItem(key)
                                    window.location.reload()
                                  }
                                }}
                                style={{
                                  padding: '8px 14px',
                                  borderRadius: '4px',
                                  border: 'none',
                                  background: '#dc2626',
                                  color: 'white',
                                  cursor: 'pointer',
                                  fontSize: '12px',
                                  fontWeight: 'bold'
                                }}
                              >
                                🗑️ Eliminar
                              </button>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  )
                })()}
              </div>
            )}
          </div>

          <div style={{
            borderTop: '2px solid #e74c3c',
            paddingTop: '20px',
            marginTop: '20px'
          }}>
            <h4 style={{ color: '#e74c3c', marginTop: 0 }}>Zona de Peligro</h4>
            <p style={{ color: 'var(--text-secondary, #666)', marginBottom: '15px' }}>
              Elimina todos los datos del sistema. Esta accion es irreversible.
            </p>
            <button
              onClick={clearAllData}
              style={{
                padding: '12px 24px',
                borderRadius: '8px',
                border: 'none',
                background: '#dc2626',
                color: 'white',
                fontWeight: 'bold',
                cursor: 'pointer',
                fontSize: '14px'
              }}
            >
              🗑️ Eliminar Todos los Datos
            </button>
          </div>
        </div>
      )}

      {/* License Tab */}
      {activeTab === 'license' && (
        <div style={{ 
          background: 'var(--card-bg, #fff)', 
          padding: '20px', 
          borderRadius: '12px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          maxWidth: '100%',
          width: '100%',
          overflowY: 'auto',
          maxHeight: 'calc(100vh - 200px)'
        }}>
          <h3 style={{ marginTop: 0, color: 'var(--text-primary, #333)' }}>🔑 Licencia</h3>

          {/* Sección de Licencia - Siempre mostrar contador */}
          <div style={{ marginBottom: '20px', marginTop: '20px', padding: '15px', background: 'var(--bg-tertiary, #f0f8ff)', borderRadius: '8px', border: '1px solid #0066cc' }}>
            <h4 style={{ margin: '0 0 10px 0', color: '#0066cc' }}>🔑 Licencia</h4>

            {(() => {
              const licenseDate = localStorage.getItem('pos_license_date')
              const licenseDays = localStorage.getItem('pos_license_days')
              const isLicenseValid = localStorage.getItem('pos_license') === 'valid'
              
              if (licenseDate && licenseDays) {
                const activationDate = new Date(licenseDate)
                const totalDays = parseInt(licenseDays)
                const now = new Date()
                const daysPassed = Math.floor((now.getTime() - activationDate.getTime()) / (1000 * 60 * 60 * 24))
                const remaining = Math.max(0, totalDays - daysPassed)
                
                return (
                  <>
                    <div style={{ padding: '10px', background: isLicenseValid ? '#d4edda' : '#f8d7da', borderRadius: '6px', color: isLicenseValid ? '#155724' : '#721c24', marginBottom: '10px' }}>
                      {isLicenseValid ? '✅ Licencia Activada' : '❌ Licencia no válida'}
                    </div>
                    
                    {/* Mensaje de advertencia cuando faltan pocos días */}
                    {remaining <= 5 && remaining > 0 && (
                      <div style={{ 
                        padding: '15px', 
                        background: 'linear-gradient(135deg, #ff6b6b 0%, #ee5a6f 100%)',
                        borderRadius: '8px', 
                        color: 'white',
                        marginBottom: '15px',
                        fontWeight: 'bold',
                        textAlign: 'center',
                        border: '3px solid #c92a2a',
                        boxShadow: '0 4px 12px rgba(255, 107, 107, 0.4)',
                        animation: 'pulse 2s infinite'
                      }}>
                        <div style={{ fontSize: '24px', marginBottom: '8px' }}>⚠️ ¡ATENCIÓN!</div>
                        <div style={{ fontSize: '16px', marginBottom: '5px' }}>
                          Su licencia está por vencer
                        </div>
                        <div style={{ fontSize: '14px', opacity: 0.95 }}>
                          El sistema se bloqueará en {remaining} {remaining === 1 ? 'día' : 'días'}
                        </div>
                      </div>
                    )}
                    
                    {/* Mensaje crítico cuando la licencia expiró */}
                    {remaining === 0 && (
                      <div style={{ 
                        padding: '15px', 
                        background: 'linear-gradient(135deg, #c92a2a 0%, #a61e4d 100%)',
                        borderRadius: '8px', 
                        color: 'white',
                        marginBottom: '15px',
                        fontWeight: 'bold',
                        textAlign: 'center',
                        border: '3px solid #7d1414',
                        boxShadow: '0 4px 12px rgba(201, 42, 42, 0.5)'
                      }}>
                        <div style={{ fontSize: '28px', marginBottom: '8px' }}>🚫 LICENCIA EXPIRADA</div>
                        <div style={{ fontSize: '16px', marginBottom: '5px' }}>
                          El sistema está bloqueado
                        </div>
                        <div style={{ fontSize: '14px', opacity: 0.95 }}>
                          Contacte al proveedor para renovar su licencia
                        </div>
                      </div>
                    )}
                    
                    <div style={{ 
                      padding: '12px', 
                      background: remaining === 0 ? '#f8d7da' : remaining <= 5 ? '#fff3cd' : '#d1ecf1', 
                      borderRadius: '6px', 
                      color: remaining === 0 ? '#721c24' : remaining <= 5 ? '#856404' : '#0c5460',
                      marginBottom: '10px',
                      fontWeight: 'bold',
                      textAlign: 'center',
                      border: `2px solid ${remaining === 0 ? '#dc3545' : remaining <= 5 ? '#ffc107' : '#17a2b8'}`
                    }}>
                      ⏳ Días restantes: <span style={{ fontSize: '18px', color: remaining === 0 ? '#dc3545' : remaining <= 5 ? '#ff6b00' : 'inherit' }}>{remaining}</span> / {totalDays} días
                    </div>
                  </>
                )
              }
              
              // Sin licencia configurada
              return (
                <>
                  <div style={{ padding: '10px', background: '#f8d7da', borderRadius: '6px', color: '#721c24', marginBottom: '10px' }}>
                    ❌ Sin licencia activada
                  </div>
                  <div style={{ padding: '12px', background: '#fff3cd', borderRadius: '6px', color: '#856404', marginBottom: '10px', fontWeight: 'bold', textAlign: 'center', border: '2px solid #ffc107' }}>
                    ⚠️ Ingrese una clave de licencia
                  </div>
                  <input
                    type="text"
                    id="licenseKeyInput"
                    placeholder="PRO-XXXX-XXXX-XXXX"
                    style={{
                      width: '100%',
                      padding: '10px',
                      borderRadius: '6px',
                      border: '1px solid var(--border-color, #ddd)',
                      marginBottom: '10px',
                      fontFamily: 'monospace',
                      background: 'var(--bg-secondary, white)',
                      color: 'var(--text-primary, #333)'
                    }}
                  />
                  <button
                    onClick={() => {
                      const input = document.getElementById('licenseKeyInput') as HTMLInputElement
                      const key = input?.value.trim()
                      if (!key) {
                        alert('Ingrese una clave de licencia')
                        return
                      }
                      
                      // Generar ID del dispositivo
                      let deviceId = localStorage.getItem('pos_device_id')
                      if (!deviceId) {
                        const canvas = document.createElement('canvas')
                        const ctx = canvas.getContext('2d')
                        const screenInfo = `${window.screen.width}x${window.screen.height}x${window.screen.colorDepth}`
                        const navigatorInfo = `${navigator.userAgent.substring(0, 50)}`
                        const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone
                        const fingerprint = `${screenInfo}|${navigatorInfo}|${timeZone}|${new Date().getTimezoneOffset()}`
                        let hash = 0
                        for (let i = 0; i < fingerprint.length; i++) {
                          const char = fingerprint.charCodeAt(i)
                          hash = ((hash << 5) - hash) + char
                          hash = hash & hash
                        }
                        deviceId = 'DEV-' + Math.abs(hash).toString(16).toUpperCase() + '-' + Date.now().toString(36).toUpperCase()
                        localStorage.setItem('pos_device_id', deviceId)
                      }
                      
                      // Claves predefinidas
                      const PREDEFINED_LICENSES: Record<string, number> = {
                        'PRO-2024-SYSTEM-FACTURACION': 10,
                        'PRO-2025-1YEAR-ABC123XYZ': 10,
                        'PRO-2025-6MONTH-DEF456UVW': 10,
                      }
                      
                      let days = PREDEFINED_LICENSES[key]
                      
                      // Cualquier clave válida con formato PRO-XXXX-XXXX-XXXX también da 10 días
                      if (!days && key && key.length >= 10 && key.startsWith('PRO-')) {
                        days = 10
                      }
                      
                      if (days) {
                        localStorage.setItem('pos_license', 'valid')
                        localStorage.setItem('pos_license_key', key)
                        localStorage.setItem('pos_license_days', days.toString())
                        localStorage.setItem('pos_license_date', new Date().toISOString())
                        localStorage.setItem('pos_license_device', deviceId)
                        alert('✅ Licencia activada correctamente')
                        input.value = ''
                        window.location.reload()
                      } else {
                        alert('❌ Clave de licencia inválida')
                      }
                    }}
                    style={{
                      padding: '10px 20px',
                      borderRadius: '6px',
                      border: 'none',
                      background: '#0066cc',
                      color: 'white',
                      cursor: 'pointer',
                      fontWeight: 'bold'
                    }}
                  >
                    Activar Licencia
                  </button>
                </>
              )
            })()}
           
            {/* Renovar licencia */}
            <button
              onClick={() => {
                const input = document.getElementById('licenseKeyInput') as HTMLInputElement
                const key = input?.value.trim() || prompt('Ingrese la nueva clave de licencia para renovar:')
                if (!key) return
               
                const LICENSES: Record<string, number> = {
                  'PRO-2024-SYSTEM-FACTURACION': 10,
                  'PRO-2025-1YEAR-ABC123XYZ': 10,
                  'PRO-2025-6MONTH-DEF456UVW': 10,
                }
               
                const days = LICENSES[key]
                if (days) {
                  // Generar ID del dispositivo
                  let deviceId = localStorage.getItem('pos_device_id')
                  if (!deviceId) {
                    const canvas = document.createElement('canvas')
                    const ctx = canvas.getContext('2d')
                    const screenInfo = `${window.screen.width}x${window.screen.height}x${window.screen.colorDepth}`
                    const navigatorInfo = `${navigator.userAgent.substring(0, 50)}`
                    const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone
                    const fingerprint = `${screenInfo}|${navigatorInfo}|${timeZone}|${new Date().getTimezoneOffset()}`
                    let hash = 0
                    for (let i = 0; i < fingerprint.length; i++) {
                      const char = fingerprint.charCodeAt(i)
                      hash = ((hash << 5) - hash) + char
                      hash = hash & hash
                    }
                    deviceId = 'DEV-' + Math.abs(hash).toString(16).toUpperCase() + '-' + Date.now().toString(36).toUpperCase()
                    localStorage.setItem('pos_device_id', deviceId)
                  }
                   
                  localStorage.setItem('pos_license', 'valid')
                  localStorage.setItem('pos_license_key', key)
                  localStorage.setItem('pos_license_days', days.toString())
                  localStorage.setItem('pos_license_date', new Date().toISOString())
                  localStorage.setItem('pos_license_device', deviceId)
                  alert('✅ Licencia renovada correctamente')
                  window.location.reload()
                } else {
                  alert('❌ Clave de licencia inválida')
                }
              }}
              style={{
                marginTop: '10px',
                padding: '8px 16px',
                borderRadius: '6px',
                border: '1px solid #0066cc',
                background: 'transparent',
                color: '#0066cc',
                cursor: 'pointer',
                fontSize: '13px'
              }}
            >
              🔄 Renovar Licencia
            </button>
          </div>
        </div>
      )}

      {/* Security Tab */}
      {activeTab === 'security' && (
        <div style={{ 
          background: 'var(--card-bg, #fff)', 
          padding: '20px', 
          borderRadius: '12px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          maxWidth: '100%',
          width: '100%',
          overflowY: 'auto',
          maxHeight: 'calc(100vh - 200px)'
        }}>
          <h3 style={{ marginTop: 0, color: 'var(--text-primary, #333)' }}>🔐 Seguridad - Cambiar Credenciales</h3>

          {loginMessage && (
            <div style={{ 
              padding: '12px', 
              borderRadius: '8px', 
              background: 'rgba(39, 174, 96, 0.1)', 
              border: '1px solid #27ae60',
              color: '#27ae60',
              marginBottom: '20px',
              textAlign: 'center'
            }}>
              {loginMessage}
            </div>
          )}

          {loginError && (
            <div style={{ 
              padding: '12px', 
              borderRadius: '8px', 
              background: 'rgba(231, 76, 60, 0.1)', 
              border: '1px solid #e74c3c',
              color: '#e74c3c',
              marginBottom: '20px',
              textAlign: 'center'
            }}>
              {loginError}
            </div>
          )}

          <form onSubmit={(e) => {
            e.preventDefault()
            setLoginError('')
            setLoginMessage('')
            
            // Verificar contraseña actual
            const savedUsers = JSON.parse(localStorage.getItem('pos_users') || '[]')
            let currentPassword = ''
            
            if (savedUsers.length > 0) {
              currentPassword = savedUsers[0].password
            } else {
              currentPassword = 'admin' // Contraseña por defecto
            }
            
            if (loginCredentials.password !== currentPassword) {
              setLoginError('La contraseña actual es incorrecta')
              return
            }
            
            if (loginCredentials.newPassword !== loginCredentials.confirmPassword) {
              setLoginError('Las contraseñas nuevas no coinciden')
              return
            }
            
            if (loginCredentials.newPassword.length < 4) {
              setLoginError('La nueva contraseña debe tener al menos 4 caracteres')
              return
            }
            
            // Actualizar credenciales
            const newUser = {
              username: loginCredentials.newUsername || 'admin',
              password: loginCredentials.newPassword,
              role: 'admin'
            }
            
            localStorage.setItem('pos_users', JSON.stringify([newUser]))
            
            setLoginMessage('Credenciales actualizadas exitosamente')
            setLoginCredentials(prev => ({ ...prev, password: '', newPassword: '', confirmPassword: '' }))
          }}>
            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold', color: 'var(--text-primary, #333)' }}>
                USUARIO ACTUAL
              </label>
              <input
                type="text"
                value={loginCredentials.username}
                disabled
                style={{ 
                  width: '100%', 
                  padding: '12px', 
                  borderRadius: '8px', 
                  border: '1px solid var(--border-color, #ddd)',
                  background: 'var(--bg-tertiary, #f5f5f5)',
                  color: 'var(--text-secondary, #666)'
                }}
              />
              <p style={{ fontSize: '12px', color: 'var(--text-secondary, #666)', marginTop: '5px' }}>
                El usuario no se puede cambiar, solo la contraseña
              </p>
            </div>

            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold', color: 'var(--text-primary, #333)' }}>
                Contraseña Actual *
              </label>
              <input
                type="password"
                value={loginCredentials.password}
                onChange={e => setLoginCredentials(prev => ({ ...prev, password: e.target.value }))}
                placeholder="Ingrese su contraseña actual"
                required
                style={{ 
                  width: '100%', 
                  padding: '12px', 
                  borderRadius: '8px', 
                  border: '1px solid var(--border-color, #ddd)',
                  background: 'var(--bg-secondary, white)',
                  color: 'var(--text-primary, #333)'
                }}
              />
            </div>

            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold', color: 'var(--text-primary, #333)' }}>
                Nueva Contraseña *
              </label>
              <div style={{ position: 'relative' }}>
                <input
                  type={showNewPassword ? 'text' : 'password'}
                  value={loginCredentials.newPassword}
                  onChange={e => setLoginCredentials(prev => ({ ...prev, newPassword: e.target.value }))}
                  placeholder="Ingrese la nueva contraseña"
                  required
                  style={{ 
                    width: '100%', 
                    padding: '12px 45px 12px 12px', 
                    borderRadius: '8px', 
                    border: '1px solid var(--border-color, #ddd)',
                    background: 'var(--bg-secondary, white)',
                    color: 'var(--text-primary, #333)'
                  }}
                />
                <button
                  type="button"
                  onClick={() => setShowNewPassword(!showNewPassword)}
                  style={{
                    position: 'absolute',
                    right: '12px',
                    top: '50%',
                    transform: 'translateY(-50%)',
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                    fontSize: '20px',
                    padding: '0',
                    color: 'var(--text-secondary, #666)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                >
                  {showNewPassword ? '🙈' : '👁️'}
                </button>
              </div>
            </div>

            <div style={{ marginBottom: '25px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold', color: 'var(--text-primary, #333)' }}>
                Confirmar Nueva Contraseña *
              </label>
              <div style={{ position: 'relative' }}>
                <input
                  type={showConfirmPassword ? 'text' : 'password'}
                  value={loginCredentials.confirmPassword}
                  onChange={e => setLoginCredentials(prev => ({ ...prev, confirmPassword: e.target.value }))}
                  placeholder="Confirme la nueva contraseña"
                  required
                  style={{ 
                    width: '100%', 
                    padding: '12px 45px 12px 12px', 
                    borderRadius: '8px', 
                    border: '1px solid var(--border-color, #ddd)',
                    background: 'var(--bg-secondary, white)',
                    color: 'var(--text-primary, #333)'
                  }}
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  style={{
                    position: 'absolute',
                    right: '12px',
                    top: '50%',
                    transform: 'translateY(-50%)',
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                    fontSize: '20px',
                    padding: '0',
                    color: 'var(--text-secondary, #666)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                >
                  {showConfirmPassword ? '🙈' : '👁️'}
                </button>
              </div>
            </div>

            <button
              type="submit"
              style={{
                padding: '14px 28px',
                borderRadius: '8px',
                border: 'none',
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                color: 'white',
                cursor: 'pointer',
                fontSize: '15px',
                fontWeight: 'bold',
                width: '100%'
              }}
            >
              🔑 Actualizar Contraseña
            </button>
          </form>

          {/* Sección de Gestión de Usuarios */}
          <div style={{ 
            marginTop: '40px', 
            borderTop: '2px solid #667eea', 
            paddingTop: '20px'
          }}>
            <h3 style={{ margin: '0 0 20px 0', color: '#667eea' }}>👥 Gestión de Usuarios</h3>
            
            {userMessage && (
              <div style={{ 
                padding: '12px', 
                borderRadius: '8px', 
                background: 'rgba(39, 174, 96, 0.1)', 
                border: '1px solid #27ae60',
                color: '#27ae60',
                marginBottom: '20px',
                textAlign: 'center'
              }}>
                {userMessage}
              </div>
            )}

            {userError && (
              <div style={{ 
                padding: '12px', 
                borderRadius: '8px', 
                background: 'rgba(231, 76, 60, 0.1)', 
                border: '1px solid #e74c3c',
                color: '#e74c3c',
                marginBottom: '20px',
                textAlign: 'center'
              }}>
                {userError}
              </div>
            )}

            {!showCreateUserForm ? (
              <div>
                <button
                  onClick={() => setShowCreateUserForm(true)}
                  style={{
                    padding: '14px 28px',
                    borderRadius: '8px',
                    border: 'none',
                    background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
                    color: 'white',
                    cursor: 'pointer',
                    fontSize: '15px',
                    fontWeight: 'bold',
                    width: '100%',
                    marginBottom: '20px'
                  }}
                >
                  ➕ Crear Nuevo Usuario
                </button>

                {/* Lista de usuarios existentes */}
                <div style={{ background: 'var(--bg-secondary, #f8f9fa)', borderRadius: '8px', padding: '15px' }}>
                  <h4 style={{ margin: '0 0 15px 0', fontSize: '14px', color: 'var(--text-primary, #333)' }}>Usuarios Registrados:</h4>
                  {usersList.length === 0 ? (
                    <p style={{ color: 'var(--text-secondary, #666)', fontSize: '13px' }}>No hay usuarios registrados</p>
                  ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                      {usersList.map((user, index) => (
                        <div key={index} style={{ 
                          background: 'var(--card-bg, white)', 
                          padding: '12px', 
                          borderRadius: '6px',
                          border: '1px solid var(--border-color, #ddd)',
                          display: 'flex',
                          justifyContent: 'space-between',
                          alignItems: 'center'
                        }}>
                          <div>
                            <strong style={{ fontSize: '14px', color: 'var(--text-primary, #333)' }}>{user.username}</strong>
                            <span style={{ 
                              marginLeft: '10px', 
                              padding: '2px 8px', 
                              borderRadius: '4px',
                              fontSize: '11px',
                              background: user.role === 'admin' ? '#667eea' : '#95a5a6',
                              color: 'white'
                            }}>
                              {user.role === 'admin' ? 'ADMIN' : 'USUARIO'}
                            </span>
                          </div>
                          {user.username !== 'admin' && (
                            <button
                              onClick={() => handleDeleteUser(user.username)}
                              style={{
                                padding: '6px 12px',
                                borderRadius: '4px',
                                border: 'none',
                                background: '#dc2626',
                                color: 'white',
                                fontWeight: 'bold',
                                cursor: 'pointer',
                                fontSize: '12px'
                              }}
                            >
                              🗑️ Eliminar
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <form onSubmit={handleCreateUser}>
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold', color: 'var(--text-primary, #333)' }}>
                    Nombre de Usuario *
                  </label>
                  <input
                    type="text"
                    value={newUser.username}
                    onChange={e => setNewUser(prev => ({ ...prev, username: e.target.value }))}
                    placeholder="Ingrese el nombre de usuario"
                    required
                    style={{ 
                      width: '100%', 
                      padding: '12px', 
                      borderRadius: '8px', 
                      border: '1px solid var(--border-color, #ddd)',
                      background: 'var(--bg-secondary, white)',
                      color: 'var(--text-primary, #333)'
                    }}
                  />
                </div>

                <div style={{ marginBottom: '20px' }}>
                  <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold', color: 'var(--text-primary, #333)' }}>
                    Contraseña *
                  </label>
                  <div style={{ position: 'relative' }}>
                    <input
                      type={showNewUserPassword ? 'text' : 'password'}
                      value={newUser.password}
                      onChange={e => setNewUser(prev => ({ ...prev, password: e.target.value }))}
                      placeholder="Ingrese la contraseña"
                      required
                      style={{ 
                        width: '100%', 
                        padding: '12px 45px 12px 12px', 
                        borderRadius: '8px', 
                        border: '1px solid var(--border-color, #ddd)',
                        background: 'var(--bg-secondary, white)',
                        color: 'var(--text-primary, #333)'
                      }}
                    />
                    <button
                      type="button"
                      onClick={() => setShowNewUserPassword(!showNewUserPassword)}
                      style={{
                        position: 'absolute',
                        right: '12px',
                        top: '50%',
                        transform: 'translateY(-50%)',
                        background: 'none',
                        border: 'none',
                        cursor: 'pointer',
                        fontSize: '20px',
                        padding: '0',
                        color: 'var(--text-secondary, #666)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                      }}
                    >
                      {showNewUserPassword ? '🙈' : '👁️'}
                    </button>
                  </div>
                </div>

                <div style={{ marginBottom: '20px' }}>
                  <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold', color: 'var(--text-primary, #333)' }}>
                    Confirmar Contraseña *
                  </label>
                  <div style={{ position: 'relative' }}>
                    <input
                      type={showNewUserConfirmPassword ? 'text' : 'password'}
                      value={newUser.confirmPassword}
                      onChange={e => setNewUser(prev => ({ ...prev, confirmPassword: e.target.value }))}
                      placeholder="Confirme la contraseña"
                      required
                      style={{ 
                        width: '100%', 
                        padding: '12px 45px 12px 12px', 
                        borderRadius: '8px', 
                        border: '1px solid var(--border-color, #ddd)',
                        background: 'var(--bg-secondary, white)',
                        color: 'var(--text-primary, #333)'
                      }}
                    />
                    <button
                      type="button"
                      onClick={() => setShowNewUserConfirmPassword(!showNewUserConfirmPassword)}
                      style={{
                        position: 'absolute',
                        right: '12px',
                        top: '50%',
                        transform: 'translateY(-50%)',
                        background: 'none',
                        border: 'none',
                        cursor: 'pointer',
                        fontSize: '20px',
                        padding: '0',
                        color: 'var(--text-secondary, #666)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                      }}
                    >
                      {showNewUserConfirmPassword ? '🙈' : '👁️'}
                    </button>
                  </div>
                </div>

                <div style={{ marginBottom: '20px' }}>
                  <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold', color: 'var(--text-primary, #333)' }}>
                    Rol del Usuario *
                  </label>
                  <select
                    value={newUser.role}
                    onChange={e => setNewUser(prev => ({ ...prev, role: e.target.value }))}
                    style={{ 
                      width: '100%', 
                      padding: '12px', 
                      borderRadius: '8px', 
                      border: '1px solid var(--border-color, #ddd)',
                      background: 'var(--bg-secondary, white)',
                      color: 'var(--text-primary, #333)'
                    }}
                  >
                    <option value="user">Usuario</option>
                    <option value="admin">Administrador</option>
                  </select>
                </div>

                <div style={{ marginBottom: '25px' }}>
                  <label style={{ display: 'block', marginBottom: '12px', fontWeight: 'bold', color: 'var(--text-primary, #333)' }}>
                    Permisos del Usuario
                  </label>
                  <div style={{
                    background: 'var(--bg-secondary, #f8f9fa)',
                    padding: '15px',
                    borderRadius: '8px',
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
                    gap: '10px'
                  }}>
                    {[
                      { key: 'dashboard', label: '📊 Dashboard' },
                      { key: 'sales', label: '💰 Ventas' },
                      { key: 'products', label: '📦 Productos' },
                      { key: 'clients', label: '👥 Clientes' },
                      { key: 'reports', label: '📈 Reportes' },
                      { key: 'archives', label: '📁 Archivos' },
                      { key: 'settings', label: '⚙️ Configuración' }
                    ].map(perm => (
                      <label key={perm.key} style={{ 
                        display: 'flex', 
                        alignItems: 'center', 
                        gap: '8px',
                        cursor: 'pointer',
                        padding: '8px',
                        background: 'var(--card-bg, white)',
                        borderRadius: '6px',
                        border: '1px solid var(--border-color, #ddd)',
                        color: 'var(--text-primary, #333)'
                      }}>
                        <input
                          type="checkbox"
                          checked={newUser.permissions[perm.key as keyof typeof newUser.permissions]}
                          onChange={e => setNewUser(prev => ({
                            ...prev,
                            permissions: {
                              ...prev.permissions,
                              [perm.key]: e.target.checked
                            }
                          }))}
                          style={{ cursor: 'pointer' }}
                        />
                        <span style={{ fontSize: '13px' }}>{perm.label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div style={{ display: 'flex', gap: '10px' }}>
                  <button
                    type="submit"
                    style={{
                      flex: 1,
                      padding: '14px 28px',
                      borderRadius: '8px',
                      border: 'none',
                      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                      color: 'white',
                      cursor: 'pointer',
                      fontSize: '15px',
                      fontWeight: 'bold'
                    }}
                  >
                    ✅ Crear Usuario
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowCreateUserForm(false)
                      setNewUser({
                        username: '',
                        password: '',
                        confirmPassword: '',
                        role: 'user',
                        permissions: {
                          dashboard: false,
                          sales: false,
                          products: false,
                          clients: false,
                          reports: false,
                          archives: false,
                          settings: false
                        }
                      })
                      setUserError('')
                    }}
                    style={{
                      flex: 1,
                      padding: '14px 28px',
                      borderRadius: '8px',
                      border: 'none',
                      background: '#dc2626',
                      color: 'white',
                      cursor: 'pointer',
                      fontSize: '15px',
                      fontWeight: 'bold'
                    }}
                  >
                    ❌ Cancelar
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Sección de contraseña para valores del inventario */}
          <div style={{ 
            marginTop: '40px', 
            padding: '15px', 
            background: 'var(--bg-secondary, #f0f4f8)', 
            borderRadius: '8px',
            border: '1px solid var(--border-color, #d1d5db)'
          }}>
            <h4 style={{ margin: '0 0 10px 0', color: 'var(--text-primary, #1f2937)' }}>🔐 Contraseña para Valores del Inventario</h4>
            <p style={{ fontSize: '12px', color: 'var(--text-secondary, #6b7280)', marginBottom: '10px' }}>
              Establece una contraseña para proteger la visualización de los valores del inventario (valor en ventas y valor en compra).
            </p>
            <div style={{ marginBottom: '10px' }}>
              <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold', color: 'var(--text-primary, #1f2937)' }}>
                Nueva Contraseña:
              </label>
              <input
                type="password"
                value={companyConfig.inventoryPassword || ''}
                onChange={e => updateCompanyConfig({ inventoryPassword: e.target.value })}
                placeholder="Ingresa una contraseña (deja vacío para quitar la protección)"
                style={{ 
                  width: '100%', 
                  padding: '10px', 
                  borderRadius: '6px', 
                  border: '1px solid var(--border-color, #d1d5db)',
                  fontSize: '14px',
                  background: 'var(--card-bg, white)',
                  color: 'var(--text-primary, #1f2937)'
                }}
              />
            </div>
            <div style={{ marginBottom: '10px' }}>
              <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold', color: 'var(--text-primary, #1f2937)' }}>
                Confirmar Contraseña:
              </label>
              <input
                type="password"
                placeholder="Confirma la contraseña"
                style={{ 
                  width: '100%', 
                  padding: '10px', 
                  borderRadius: '6px', 
                  border: '1px solid var(--border-color, #d1d5db)',
                  fontSize: '14px',
                  background: 'var(--card-bg, white)',
                  color: 'var(--text-primary, #1f2937)'
                }}
              />
            </div>
            <div style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
              <button
                onClick={() => {
                  // Primero pedir confirmación de la contraseña actual si ya existe
                  if (companyConfig.inventoryPassword) {
                    const currentPassword = window.prompt('Ingresa la contraseña actual:')
                    if (currentPassword !== companyConfig.inventoryPassword) {
                      alert('Contraseña actual incorrecta')
                      return
                    }
                  }
                  // Luego confirmar el cambio
                  if (window.confirm('¿Estás seguro de guardar la nueva contraseña?')) {
                    alert('Contraseña guardada correctamente')
                  }
                }}
                style={{
                  background: '#059669',
                  color: 'white',
                  border: 'none',
                  padding: '10px 20px',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontWeight: 'bold',
                  fontSize: '14px'
                }}
              >
                💾 Guardar Contraseña
              </button>
              <button
                onClick={() => {
                  if (companyConfig.inventoryPassword) {
                    const currentPassword = window.prompt('Ingresa la contraseña actual para eliminar:')
                    if (currentPassword !== companyConfig.inventoryPassword) {
                      alert('Contraseña incorrecta')
                      return
                    }
                    if (window.confirm('¿Estás seguro de eliminar la contraseña?')) {
                      updateCompanyConfig({ inventoryPassword: '' })
                      alert('Contraseña eliminada correctamente')
                    }
                  } else {
                    alert('No hay contraseña configurada')
                  }
                }}
                style={{
                  background: '#dc2626',
                  color: 'white',
                  border: 'none',
                  padding: '10px 20px',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontWeight: 'bold',
                  fontSize: '14px'
                }}
              >
                🗑️ Eliminar Contraseña
              </button>
            </div>
            {companyConfig.inventoryPassword && (
              <p style={{ fontSize: '12px', color: '#16a34a', marginTop: '10px' }}>
                ✓ Contraseña configurada. Los valores del inventario estarán protegidos.
              </p>
            )}
          </div>

        </div>
      )}

      {/* Styles Tab */}
      {activeTab === 'styles' && (
        <div style={{ 
          background: 'var(--card-bg, #fff)', 
          padding: '20px', 
          borderRadius: '12px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          maxWidth: '100%',
          width: '100%',
          overflowY: 'auto',
          maxHeight: 'calc(100vh - 200px)'
        }}>
          <h3 style={{ marginTop: 0, color: 'var(--text-primary, #333)' }}>🎨 Personalización de Atajos de Teclado</h3>
          
          <p style={{ color: 'var(--text-secondary, #666)', marginBottom: '20px', fontSize: '14px' }}>
            Personaliza las teclas de función (F1-F6) para realizar diferentes acciones en el módulo de ventas.
          </p>

          {(() => {
            // Leer configuración guardada o usar valores por defecto
            const savedShortcuts = localStorage.getItem('pos_keyboard_shortcuts')
            const shortcuts = savedShortcuts ? JSON.parse(savedShortcuts) : {
              F1: 'toggle-products',
              F2: 'toggle-clients',
              F3: 'clear-cart',
              F4: 'process-payment',
              F5: 'goto-inventory',
              F6: 'goto-clients'
            }

            // Opciones disponibles para cada tecla
            const actionOptions = [
              { value: 'toggle-products', label: 'Abrir/Cerrar productos' },
              { value: 'toggle-clients', label: 'Abrir/Cerrar clientes' },
              { value: 'clear-cart', label: 'Limpiar carrito' },
              { value: 'process-payment', label: 'Procesar pago' },
              { value: 'goto-inventory', label: 'Ir a inventario' },
              { value: 'goto-clients', label: 'Ir a clientes' },
              { value: 'none', label: 'Sin acción' }
            ]

            const handleShortcutChange = (key: string, value: string) => {
              const updated = { ...shortcuts, [key]: value }
              localStorage.setItem('pos_keyboard_shortcuts', JSON.stringify(updated))
              // Forzar actualización del componente
              window.dispatchEvent(new Event('storage'))
            }

            const handleReset = () => {
              if (confirm('¿Restaurar atajos de teclado a valores predeterminados?')) {
                const defaults = {
                  F1: 'toggle-products',
                  F2: 'toggle-clients',
                  F3: 'clear-cart',
                  F4: 'process-payment',
                  F5: 'goto-inventory',
                  F6: 'goto-clients'
                }
                localStorage.setItem('pos_keyboard_shortcuts', JSON.stringify(defaults))
                alert('Atajos restaurados. La página se recargará.')
                window.location.reload()
              }
            }

            return (
              <div>
                <div style={{
                  background: 'var(--bg-secondary, #f8f9fa)',
                  padding: '20px',
                  borderRadius: '8px',
                  marginBottom: '20px'
                }}>
                  <h4 style={{ margin: '0 0 15px 0', color: 'var(--text-primary, #333)' }}>
                    ⌨️ Configuración de Teclas
                  </h4>
                  
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
                    {['F1', 'F2', 'F3', 'F4', 'F5', 'F6'].map(key => (
                      <div key={key} style={{
                        background: 'var(--card-bg, white)',
                        padding: '15px',
                        borderRadius: '8px',
                        border: '1px solid var(--border-color, #ddd)',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '15px'
                      }}>
                        <div style={{
                          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                          color: 'white',
                          padding: '10px 16px',
                          borderRadius: '8px',
                          fontWeight: 'bold',
                          fontSize: '16px',
                          fontFamily: 'monospace',
                          minWidth: '60px',
                          textAlign: 'center',
                          boxShadow: '0 2px 8px rgba(102, 126, 234, 0.3)'
                        }}>
                          {key}
                        </div>
                        
                        <div style={{ flex: 1 }}>
                          <label style={{
                            display: 'block',
                            marginBottom: '5px',
                            fontSize: '12px',
                            color: 'var(--text-secondary, #666)',
                            fontWeight: 'bold'
                          }}>
                            Acción asignada:
                          </label>
                          <select
                            value={shortcuts[key]}
                            onChange={(e) => handleShortcutChange(key, e.target.value)}
                            style={{
                              width: '100%',
                              padding: '10px',
                              borderRadius: '6px',
                              border: '1px solid var(--border-color, #ddd)',
                              background: 'var(--bg-secondary, white)',
                              color: 'var(--text-primary, #333)',
                              fontSize: '14px',
                              cursor: 'pointer'
                            }}
                          >
                            {actionOptions.map(option => (
                              <option key={option.value} value={option.value}>
                                {option.label}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div style={{
                  background: 'var(--bg-tertiary, #fff3cd)',
                  padding: '15px',
                  borderRadius: '8px',
                  border: '1px solid #ffc107',
                  marginBottom: '20px'
                }}>
                  <p style={{ margin: 0, fontSize: '13px', color: '#856404' }}>
                    💡 <strong>Nota:</strong> Los cambios se aplicarán inmediatamente en el módulo de ventas. 
                    Si asignas la misma acción a múltiples teclas, todas funcionarán.
                  </p>
                </div>

                <div style={{ display: 'flex', gap: '10px' }}>
                  <button
                    onClick={() => {
                      alert('Los cambios se guardan automáticamente')
                    }}
                    style={{
                      padding: '12px 24px',
                      borderRadius: '8px',
                      border: 'none',
                      background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
                      color: 'white',
                      cursor: 'pointer',
                      fontSize: '14px',
                      fontWeight: 'bold'
                    }}
                  >
                    ✅ Cambios Guardados
                  </button>
                  
                  <button
                    onClick={handleReset}
                    style={{
                      padding: '12px 24px',
                      borderRadius: '8px',
                      border: '1px solid var(--border-color, #ddd)',
                      background: 'var(--card-bg, white)',
                      color: 'var(--text-secondary, #666)',
                      cursor: 'pointer',
                      fontSize: '14px',
                      fontWeight: 'bold'
                    }}
                  >
                    🔄 Restaurar Predeterminados
                  </button>
                </div>
              </div>
            )
          })()}
        </div>
      )}

      {/* Updates Tab */}
      {activeTab === 'updates' && <UpdatesPanel />}
    </div>
  )
}

