import { useState, useEffect, useCallback } from 'react'

/**
 * Hook personalizado para gestionar estado con localStorage
 * Proporciona una interfaz tipada y consistente para el manejo de persistencia
 */

// Claves de almacenamiento
export const STORAGE_KEYS = {
  PRODUCTS: 'pos_products',
  SALES: 'pos_sales',
  CLIENTS: 'pos_clients',
  USERS: 'pos_users',
  SETTINGS: 'pos_settings',
  DARK_MODE: 'pos_dark_mode',
  SESSION_START: 'pos_session_start',
  SESSION_COUNT: 'pos_session_count',
  CART: 'pos_cart',
  SALES_HISTORY: 'pos_sales_history',
  TAX_RATE: 'pos_tax_rate',
  APPLY_TAX: 'pos_apply_tax',
} as const

interface UseLocalStorageReturn<T> {
  value: T
  setValue: (value: T | ((prev: T) => T)) => void
  removeValue: () => void
  loading: boolean
}

/**
 * Hook para gestionar un valor en localStorage
 */
export function useLocalStorage<T>(
  key: string,
  defaultValue: T
): UseLocalStorageReturn<T> {
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      if (typeof window === 'undefined') {
        return defaultValue
      }
      
      const item = window.localStorage.getItem(key)
      if (item === null) {
        return defaultValue
      }
      
      try {
        return JSON.parse(item)
      } catch {
        return item as unknown as T
      }
    } catch (error) {
      console.warn(`Error reading localStorage key "${key}":`, error)
      return defaultValue
    }
  })

  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setLoading(false)
  }, [])

  const setValue = useCallback(
    (value: T | ((prev: T) => T)) => {
      try {
        const valueToStore = value instanceof Function ? value(storedValue) : value
        
        setStoredValue(valueToStore)
        
        if (typeof window !== 'undefined') {
          window.localStorage.setItem(
            key,
            typeof valueToStore === 'string' 
              ? valueToStore 
              : JSON.stringify(valueToStore)
          )
        }
      } catch (error) {
        console.warn(`Error setting localStorage key "${key}":`, error)
      }
    },
    [key, storedValue]
  )

  const removeValue = useCallback(() => {
    try {
      setStoredValue(defaultValue)
      
      if (typeof window !== 'undefined') {
        window.localStorage.removeItem(key)
      }
    } catch (error) {
      console.warn(`Error removing localStorage key "${key}":`, error)
    }
  }, [key, defaultValue])

  return { value: storedValue, setValue, removeValue, loading }
}

/**
 * Hook específico para valores booleanos en localStorage
 */
export function useLocalStorageBoolean(
  key: string,
  defaultValue: boolean = false
): [boolean, (value: boolean | ((prev: boolean) => boolean)) => void] {
  const { value, setValue } = useLocalStorage(key, defaultValue)

  const typedValue = value as boolean
  const typedSetValue = setValue as (value: boolean | ((prev: boolean) => boolean)) => void

  return [typedValue, typedSetValue]
}

/**
 * Hook específico para valores numéricos en localStorage
 */
export function useLocalStorageNumber(
  key: string,
  defaultValue: number = 0
): [number, (value: number | ((prev: number) => number)) => void] {
  const { value, setValue } = useLocalStorage(key, defaultValue)

  const typedValue = value as number
  const typedSetValue = setValue as (value: number | ((prev: number) => number)) => void

  return [typedValue, typedSetValue]
}

/**
 * Hook específico para valores string en localStorage
 */
export function useLocalStorageString(
  key: string,
  defaultValue: string = ''
): [string, (value: string | ((prev: string) => string)) => void] {
  const { value, setValue } = useLocalStorage(key, defaultValue)

  const typedValue = value as string
  const typedSetValue = setValue as (value: string | ((prev: string) => string)) => void

  return [typedValue, typedSetValue]
}

/**
 * Hook específico para objetos en localStorage
 */
export function useLocalStorageObject<T extends object>(
  key: string,
  defaultValue: T
): [T, (value: T | ((prev: T) => T)) => void] {
  const { value, setValue } = useLocalStorage<T>(key, defaultValue)

  return [value, setValue]
}

/**
 * Hook específico para arrays en localStorage
 */
export function useLocalStorageArray<T>(
  key: string,
  defaultValue: T[] = []
): [T[], (value: T[] | ((prev: T[]) => T[])) => void] {
  const { value, setValue } = useLocalStorage<T[]>(key, defaultValue)

  return [value, setValue]
}

export default useLocalStorage
