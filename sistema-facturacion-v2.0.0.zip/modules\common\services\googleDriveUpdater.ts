// Servicio SIMPLE de actualizaciones solo desde Google Drive

export interface UpdateInfo {
  available: boolean
  version: string
  currentVersion: string
  features: string[]
  downloadUrl: string
  releaseDate?: string
}

class GoogleDriveUpdater {
  private currentVersion = '1.0.0'

  /**
   * Obtener ID de Google Drive guardado
   */
  getGoogleDriveConfigId(): string {
    return localStorage.getItem('update_google_drive_id') || ''
  }

  /**
   * Guardar ID de Google Drive
   */
  setGoogleDriveConfigId(fileId: string): void {
    localStorage.setItem('update_google_drive_id', fileId)
  }

  /**
   * Verificar actualizaciones desde Google Drive
   */
  async checkUpdates(): Promise<UpdateInfo> {
    const fileId = this.getGoogleDriveConfigId()

    if (!fileId.trim()) {
      throw new Error('ID de Google Drive no configurado')
    }

    console.log('[GoogleDriveUpdater] Verificando actualizaciones...')
    console.log('[GoogleDriveUpdater] File ID:', fileId)

    try {
      // URL para descargar el JSON de Google Drive
      const url = `https://drive.google.com/uc?export=download&id=${fileId}&timestamp=${Date.now()}`

      const response = await fetch(url, {
        method: 'GET',
        cache: 'no-cache'
      })

      if (!response.ok) {
        throw new Error(`Error HTTP ${response.status}`)
      }

      const text = await response.text()
      console.log('[GoogleDriveUpdater] Respuesta recibida')

      // Parsear JSON
      const data = JSON.parse(text)
      console.log('[GoogleDriveUpdater] Datos:', data)

      // Validar que tenga los campos necesarios
      if (!data.version || !data.downloadUrl) {
        throw new Error('JSON inválido: falta version o downloadUrl')
      }

      // Comparar versiones
      const available = this.isNewerVersion(data.version, this.currentVersion)

      console.log(`[GoogleDriveUpdater] Nueva versión disponible: ${available}`)

      return {
        available,
        version: data.version,
        currentVersion: this.currentVersion,
        features: data.features || [],
        downloadUrl: data.downloadUrl,
        releaseDate: data.releaseDate
      }

    } catch (error) {
      console.error('[GoogleDriveUpdater] Error:', error)
      throw error
    }
  }

  /**
   * Comparar versiones (ej: 2.0.0 > 1.0.0)
   */
  private isNewerVersion(newVersion: string, currentVersion: string): boolean {
    const newParts = newVersion.split('.').map(Number)
    const currentParts = currentVersion.split('.').map(Number)

    for (let i = 0; i < 3; i++) {
      const newPart = newParts[i] || 0
      const currentPart = currentParts[i] || 0

      if (newPart > currentPart) return true
      if (newPart < currentPart) return false
    }

    return false
  }

  /**
   * Descargar archivo desde URL
   */
  async downloadFile(url: string, onProgress?: (percent: number) => void): Promise<Blob> {
    console.log('[GoogleDriveUpdater] Descargando desde:', url)

    const response = await fetch(url, {
      method: 'GET',
      cache: 'no-cache'
    })

    if (!response.ok) {
      throw new Error(`Error en descarga: ${response.status}`)
    }

    const total = parseInt(response.headers.get('content-length') || '0', 10)
    console.log('[GoogleDriveUpdater] Tamaño total:', total, 'bytes')

    if (!response.body) {
      throw new Error('No se pudo acceder al contenido')
    }

    const reader = response.body.getReader()
    const chunks: Uint8Array[] = []
    let receivedLength = 0

    while (true) {
      const { done, value } = await reader.read()

      if (done) break

      chunks.push(value)
      receivedLength += value.length

      if (total > 0 && onProgress) {
        const percent = Math.round((receivedLength / total) * 100)
        onProgress(percent)
      }
    }

    const blob = new Blob(chunks as BlobPart[], { type: 'application/zip' })
    console.log('[GoogleDriveUpdater] Descarga completada:', blob.size, 'bytes')

    return blob
  }

  /**
   * Guardar archivo descargado (trigger de descarga)
   */
  saveBlob(blob: Blob, filename: string): void {
    const url = window.URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = filename
    link.style.display = 'none'
    document.body.appendChild(link)
    link.click()
    
    setTimeout(() => {
      document.body.removeChild(link)
      window.URL.revokeObjectURL(url)
    }, 100)
  }
}

export const googleDriveUpdater = new GoogleDriveUpdater()
