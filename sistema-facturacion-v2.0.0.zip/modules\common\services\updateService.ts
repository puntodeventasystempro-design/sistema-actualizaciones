// Servicio para gestionar actualizaciones del sistema

export interface UpdateInfo {
  available: boolean
  version: string
  currentVersion: string
  releaseDate: string
  features: string[]
  downloadUrl?: string
  critical?: boolean // Si es una actualización crítica
  size?: string // Tamaño del archivo
}

export interface UpdateConfig {
  checkInterval: number // Intervalo en milisegundos
  autoCheck: boolean // Verificar automáticamente
}

class UpdateService {
  private config: UpdateConfig
  private currentVersion: string
  private googleDriveFileId: string
  
  constructor() {
    this.config = {
      checkInterval: 6 * 60 * 60 * 1000,
      autoCheck: true
    }
    
    this.currentVersion = '1.0.0'
    
    // Cargar ID de Google Drive desde localStorage o usar el configurado
    this.googleDriveFileId = localStorage.getItem('pos_google_drive_file_id') || '1Dsa5jPKlK_Zr1FPNM2u13iXv1sTfJBYr'
  }
  
  configure(config: Partial<UpdateConfig>) {
    this.config = { ...this.config, ...config }
  }

  setGoogleDriveFileId(fileId: string) {
    this.googleDriveFileId = fileId
    localStorage.setItem('pos_google_drive_file_id', fileId)
  }

  getGoogleDriveFileId(): string {
    return this.googleDriveFileId
  }
  
  async checkForUpdates(): Promise<UpdateInfo> {
    console.log('[UpdateService] Verificando actualizaciones...')
    console.log('[UpdateService] Versión actual:', this.currentVersion)
    
    try {
      const result = await this.checkFromGitHub()
      
      console.log('[UpdateService] ✅ Resultado:', result)
      this.saveCheckHistory(result)
      
      return result
      
    } catch (error) {
      console.error('[UpdateService] ❌ Error:', error)
      return this.getNoUpdateInfo()
    }
  }
  
  // Verificar desde GitHub
  private async checkFromGitHub(): Promise<UpdateInfo> {
    try {
      const url = `https://raw.githubusercontent.com/puntodeventasystempro-design/sistema-actualizaciones/main/updates.json?t=${Date.now()}`
      console.log('[UpdateService] Consultando GitHub:', url)
      
      const response = await fetch(url, {
        cache: 'no-cache',
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache'
        }
      })
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`)
      }
      
      const data = await response.json()
      console.log('[UpdateService] Datos de GitHub:', data)
      
      const result = this.parseUpdateInfo(data)
      console.log('[UpdateService] Resultado final:', result)
      
      return result
      
    } catch (error) {
      console.error('[UpdateService] Error consultando GitHub:', error)
      throw error
    }
  }
  
  parseUpdateInfo(data: any): UpdateInfo {
    const latestVersion = data.version || data.latestVersion
    const available = this.isNewerVersion(latestVersion, this.currentVersion)
    
    return {
      available,
      version: latestVersion,
      currentVersion: this.currentVersion,
      releaseDate: data.releaseDate || new Date().toISOString(),
      features: data.features || data.changelog || [],
      downloadUrl: data.downloadUrl || data.url,
      critical: data.critical || false,
      size: data.size || 'Desconocido'
    }
  }
  
  isNewerVersion(newVersion: string, currentVersion: string): boolean {
    console.log('[UpdateService] Comparando versiones:')
    console.log('  Nueva:', newVersion)
    console.log('  Actual:', currentVersion)
    
    const newParts = newVersion.split('.').map(Number)
    const currentParts = currentVersion.split('.').map(Number)
    
    console.log('  Partes nueva:', newParts)
    console.log('  Partes actual:', currentParts)
    
    for (let i = 0; i < 3; i++) {
      const newPart = newParts[i] || 0
      const currentPart = currentParts[i] || 0
      
      console.log(`  Comparando posición ${i}: ${newPart} vs ${currentPart}`)
      
      if (newPart > currentPart) {
        console.log('  ✅ Nueva versión es mayor')
        return true
      }
      if (newPart < currentPart) {
        console.log('  ❌ Nueva versión es menor')
        return false
      }
    }
    
    console.log('  ⚠️ Versiones son iguales')
    return false
  }
  
  getNoUpdateInfo(): UpdateInfo {
    return {
      available: false,
      version: this.currentVersion,
      currentVersion: this.currentVersion,
      releaseDate: new Date().toISOString(),
      features: []
    }
  }
  
  // Obtener plataforma
  private getPlatform(): string {
    const userAgent = navigator.userAgent.toLowerCase()
    
    if (userAgent.includes('win')) return 'windows'
    if (userAgent.includes('mac')) return 'macos'
    if (userAgent.includes('linux')) return 'linux'
    
    return 'unknown'
  }
  
  // Obtener o crear ID de dispositivo
  private getDeviceId(): string {
    let deviceId = localStorage.getItem('pos_device_id')
    
    if (!deviceId) {
      deviceId = 'DEV-' + Math.random().toString(36).substring(2, 15)
      localStorage.setItem('pos_device_id', deviceId)
    }
    
    return deviceId
  }
  
  // Descargar actualización
  async downloadUpdate(url: string): Promise<void> {
    try {
      // Abrir en nueva pestaña
      window.open(url, '_blank')
      
      // Registrar descarga
      this.logUpdateDownload()
      
    } catch (error) {
      console.error('Error al descargar actualización:', error)
      throw error
    }
  }
  
  // Registrar descarga de actualización
  private logUpdateDownload() {
    const downloads = JSON.parse(localStorage.getItem('pos_update_downloads') || '[]')
    downloads.push({
      date: new Date().toISOString(),
      version: this.currentVersion
    })
    localStorage.setItem('pos_update_downloads', JSON.stringify(downloads))
  }
  
  // Obtener historial de verificaciones
  getCheckHistory(): any[] {
    return JSON.parse(localStorage.getItem('pos_update_checks') || '[]')
  }
  
  // Guardar verificación en historial
  saveCheckHistory(updateInfo: UpdateInfo) {
    const history = this.getCheckHistory()
    history.push({
      date: new Date().toISOString(),
      available: updateInfo.available,
      version: updateInfo.version
    })
    
    // Mantener solo últimas 50 verificaciones
    if (history.length > 50) {
      history.shift()
    }
    
    localStorage.setItem('pos_update_checks', JSON.stringify(history))
  }
}

// Exportar instancia única
export const updateService = new UpdateService()
