// Servicio de instalación automática de actualizaciones

export interface InstallProgress {
  step: 'downloading' | 'extracting' | 'installing' | 'complete' | 'error'
  progress: number // 0-100
  message: string
}

class AutoInstaller {
  private onProgress?: (progress: InstallProgress) => void
  
  // Configurar callback de progreso
  setProgressCallback(callback: (progress: InstallProgress) => void) {
    this.onProgress = callback
  }
  
  // Descargar e instalar actualización automáticamente
  async downloadAndInstall(downloadUrl: string, version: string): Promise<boolean> {
    try {
      console.log('[AutoInstaller] Iniciando descarga desde:', downloadUrl)
      
      // Paso 1: Descargar
      this.reportProgress('downloading', 0, 'Descargando actualización...')
      
      // Verificar si es una URL de Google Drive
      let url = downloadUrl
      if (downloadUrl.includes('drive.google.com')) {
        url = this.convertGoogleDriveUrl(downloadUrl)
      }
      
      const blob = await this.downloadFile(url, (progress) => {
        this.reportProgress('downloading', progress, `Descargando... ${progress}%`)
      })
      
      if (!blob) {
        throw new Error('Error al descargar el archivo')
      }
      
      console.log('[AutoInstaller] Archivo descargado, tamaño:', blob.size, 'bytes')
      
      // Paso 2: Guardar localmente
      this.reportProgress('downloading', 100, 'Descarga completada')
      
      // Paso 3: Preparar instalación
      this.reportProgress('extracting', 30, 'Preparando instalación...')
      
      // Crear enlace de descarga
      const objUrl = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = objUrl
      link.download = `sistema-facturacion-v${version}.zip`
      link.style.display = 'none'
      document.body.appendChild(link)
      
      this.reportProgress('extracting', 60, 'Iniciando descarga en navegador...')
      
      // Click para descargar
      link.click()
      
      // Limpiar después de un poco de tiempo
      setTimeout(() => {
        document.body.removeChild(link)
        window.URL.revokeObjectURL(objUrl)
      }, 100)
      
      // Paso 4: Completar
      this.reportProgress('installing', 100, 'Archivo descargado correctamente')
      
      // Guardar que hay una actualización pendiente
      localStorage.setItem('pos_pending_update', JSON.stringify({
        version,
        downloadedAt: new Date().toISOString(),
        fileName: `sistema-facturacion-v${version}.zip`
      }))
      
      setTimeout(() => {
        this.reportProgress('complete', 100, '✅ ¡Descarga completada! Revisa tu carpeta Descargas')
      }, 1000)
      
      return true
      
    } catch (error) {
      console.error('[AutoInstaller] Error:', error)
      this.reportProgress('error', 0, `Error: ${(error as Error).message}`)
      return false
    }
  }

  // Convertir URL de Google Drive a descarga directa
  private convertGoogleDriveUrl(url: string): string {
    try {
      if (url.includes('/file/d/')) {
        const fileId = url.split('/file/d/')[1]?.split('/')[0]
        if (fileId) {
          return `https://drive.google.com/uc?export=download&id=${fileId}`
        }
      }
    } catch (e) {
      console.warn('Error convertiendo URL de Google Drive:', e)
    }
    return url
  }
  
  // Descargar archivo con progreso
  private async downloadFile(
    url: string, 
    onProgress: (progress: number) => void
  ): Promise<Blob | null> {
    try {
      console.log('[AutoInstaller] Iniciando descarga desde:', url)
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Cache-Control': 'no-cache'
        }
      })
      
      if (!response.ok) {
        console.error('[AutoInstaller] HTTP Error:', response.status)
        throw new Error(`Error HTTP ${response.status}: ${response.statusText}`)
      }
      
      const contentLength = response.headers.get('content-length')
      const total = contentLength ? parseInt(contentLength, 10) : 0
      
      console.log('[AutoInstaller] Tamaño total:', total, 'bytes')
      
      if (!response.body) {
        throw new Error('No se pudo acceder al contenido del archivo')
      }
      
      const reader = response.body.getReader()
      const chunks: Uint8Array[] = []
      let receivedLength = 0
      let lastProgressReport = 0
      
      while (true) {
        const { done, value } = await reader.read()
        
        if (done) {
          console.log('[AutoInstaller] Descarga completada')
          break
        }
        
        chunks.push(value)
        receivedLength += value.length
        
        if (total > 0) {
          const progress = Math.round((receivedLength / total) * 100)
          // Reportar cada 5%
          if (progress - lastProgressReport >= 5 || progress === 100) {
            onProgress(progress)
            lastProgressReport = progress
            console.log(`[AutoInstaller] Progreso: ${progress}%`)
          }
        } else {
          // Si no conocemos el tamaño, reportar cada 1MB descargado
          if (receivedLength % (1024 * 1024) === 0) {
            console.log('[AutoInstaller] Descargados:', (receivedLength / (1024 * 1024)).toFixed(1), 'MB')
          }
        }
      }
      
      // Combinar chunks en un solo Blob
      const blob = new Blob(chunks, { type: 'application/zip' })
      console.log('[AutoInstaller] Blob creado:', blob.size, 'bytes')
      return blob
      
    } catch (error) {
      console.error('[AutoInstaller] Error al descargar:', error)
      throw error
    }
  }
  
  // Reportar progreso
  private reportProgress(
    step: InstallProgress['step'], 
    progress: number, 
    message: string
  ) {
    if (this.onProgress) {
      this.onProgress({ step, progress, message })
    }
  }
  
  // Verificar si hay actualización pendiente
  hasPendingUpdate(): boolean {
    return localStorage.getItem('pos_pending_update') !== null
  }
  
  // Obtener información de actualización pendiente
  getPendingUpdate(): { version: string; downloadedAt: string } | null {
    const data = localStorage.getItem('pos_pending_update')
    return data ? JSON.parse(data) : null
  }
  
  // Marcar actualización como instalada
  markAsInstalled() {
    localStorage.removeItem('pos_pending_update')
  }
  
  // Instalar actualización (requiere permisos del sistema)
  async installUpdate(): Promise<boolean> {
    try {
      // Esta función requeriría acceso al sistema de archivos
      // En un navegador web, el usuario debe instalar manualmente
      
      // Para Electron o aplicación de escritorio:
      const w = window as any
      if (w.electronAPI && w.electronAPI.installUpdate) {
        return await w.electronAPI.installUpdate()
      }
      
      // Para navegador: mostrar instrucciones
      this.showInstallInstructions()
      return true
      
    } catch (error) {
      console.error('Error al instalar:', error)
      return false
    }
  }
  
  // Mostrar instrucciones de instalación
  private showInstallInstructions() {
    const instructions = `
📦 INSTALACIÓN DE ACTUALIZACIÓN

PASOS:
1. ✅ El archivo se descargó en tu carpeta "Descargas"
2. 🔒 Cierra este programa completamente
3. 📂 Busca el archivo ZIP descargado
4. 📦 Extrae el contenido del ZIP
5. 📋 Copia todos los archivos extraídos
6. 📁 Ve a la carpeta donde está instalado el programa
7. 📝 Pega los archivos (reemplazar cuando pregunte)
8. 🚀 Abre el programa de nuevo

¡La actualización estará instalada!

💡 TIP: Si no sabes dónde está instalado el programa,
busca el acceso directo y haz clic derecho → "Abrir ubicación"
    `.trim()
    
    alert(instructions)
  }
}

// Exportar instancia única
export const autoInstaller = new AutoInstaller()
