import { useState } from 'react'

export default function UpdatesPanel() {
  const [isChecking, setIsChecking] = useState(false)
  const [updateAvailable, setUpdateAvailable] = useState(false)
  const [updateInfo, setUpdateInfo] = useState<any>(null)
  const [message, setMessage] = useState('')

  const currentVersion = '1.0.0'

  const checkForUpdates = async () => {
    setIsChecking(true)
    setMessage('Verificando actualizaciones...')
    
    try {
      const url = `https://raw.githubusercontent.com/puntodeventasystempro-design/sistema-actualizaciones/main/updates.json?t=${Date.now()}`
      
      const response = await fetch(url, {
        cache: 'no-cache'
      })
      
      if (!response.ok) {
        throw new Error('Error al verificar actualizaciones')
      }
      
      const data = await response.json()
      
      // Comparar versiones
      const newVersion = data.version || data.latestVersion
      const isNewer = compareVersions(newVersion, currentVersion)
      
      if (isNewer) {
        setUpdateAvailable(true)
        setUpdateInfo(data)
        setMessage(`✅ Nueva versión disponible: v${newVersion}`)
      } else {
        setUpdateAvailable(false)
        setUpdateInfo(null)
        setMessage('✓ Tu sistema está actualizado')
      }
      
    } catch (error) {
      console.error('Error:', error)
      setMessage('❌ Error al verificar actualizaciones')
    } finally {
      setIsChecking(false)
    }
  }

  const compareVersions = (newVer: string, currentVer: string): boolean => {
    const newParts = newVer.split('.').map(Number)
    const currentParts = currentVer.split('.').map(Number)
    
    for (let i = 0; i < 3; i++) {
      const newPart = newParts[i] || 0
      const currentPart = currentParts[i] || 0
      
      if (newPart > currentPart) return true
      if (newPart < currentPart) return false
    }
    
    return false
  }

  const downloadUpdate = () => {
    if (updateInfo?.downloadUrl) {
      window.open(updateInfo.downloadUrl, '_blank')
      alert('📥 Descarga iniciada\n\nSigue las instrucciones del archivo descargado para instalar la actualización.')
    }
  }

  return (
    <div style={{
      background: 'var(--card-bg, #fff)',
      padding: '15px',
      borderRadius: '8px',
      boxShadow: '0 2px 4px rgba(0,0,0,0.06)',
      maxWidth: '500px',
      margin: '0 auto'
    }}>
      {/* Header Compacto */}
      <div style={{ 
        display: 'flex', 
        alignItems: 'center', 
        gap: '12px',
        marginBottom: '20px',
        paddingBottom: '15px',
        borderBottom: '2px solid #e5e7eb'
      }}>
        <div style={{ 
          width: '40px',
          height: '40px',
          background: 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)',
          borderRadius: '8px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: '20px',
          flexShrink: 0
        }}>
          🔄
        </div>
        <div style={{ flex: 1 }}>
          <h2 style={{ 
            margin: 0, 
            color: 'var(--text-primary, #333)',
            fontSize: '16px',
            fontWeight: '700'
          }}>
            Actualizaciones del Sistema
          </h2>
          <p style={{ 
            color: 'var(--text-secondary, #666)', 
            margin: '2px 0 0 0',
            fontSize: '11px'
          }}>
            Mantén tu sistema actualizado
          </p>
        </div>
      </div>

      {/* Version Cards Compactas */}
      <div style={{
        display: 'flex',
        gap: '10px',
        marginBottom: '15px'
      }}>
        {/* Current Version */}
        <div style={{
          flex: 1,
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          padding: '12px',
          borderRadius: '8px',
          color: 'white',
          textAlign: 'center'
        }}>
          <div style={{ 
            fontSize: '9px', 
            opacity: 0.85, 
            marginBottom: '4px',
            fontWeight: '600',
            textTransform: 'uppercase'
          }}>
            Actual
          </div>
          <div style={{ 
            fontSize: '18px', 
            fontWeight: 'bold'
          }}>
            v{currentVersion}
          </div>
        </div>

        {/* New Version */}
        {updateAvailable && updateInfo && (
          <div style={{
            flex: 1,
            background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
            padding: '12px',
            borderRadius: '8px',
            color: 'white',
            textAlign: 'center',
            position: 'relative'
          }}>
            <div style={{
              position: 'absolute',
              top: '4px',
              right: '4px',
              background: 'rgba(255,255,255,0.25)',
              padding: '2px 5px',
              borderRadius: '4px',
              fontSize: '7px',
              fontWeight: 'bold'
            }}>
              NUEVO
            </div>
            <div style={{ 
              fontSize: '9px', 
              opacity: 0.85, 
              marginBottom: '4px',
              fontWeight: '600',
              textTransform: 'uppercase'
            }}>
              Disponible
            </div>
            <div style={{ 
              fontSize: '18px', 
              fontWeight: 'bold'
            }}>
              v{updateInfo.version || updateInfo.latestVersion}
            </div>
          </div>
        )}
      </div>

      {/* Botones en fila */}
      <div style={{ 
        display: 'flex', 
        gap: '8px',
        marginBottom: '12px'
      }}>
        {/* Check Button */}
        <button
          onClick={checkForUpdates}
          disabled={isChecking}
          style={{
            flex: 1,
            padding: '10px 12px',
            background: isChecking 
              ? '#9ca3af'
              : 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)',
            color: 'white',
            border: 'none',
            borderRadius: '6px',
            fontSize: '12px',
            fontWeight: '600',
            cursor: isChecking ? 'not-allowed' : 'pointer',
            transition: 'all 0.2s',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '6px'
          }}
        >
          <span style={{ fontSize: '14px' }}>{isChecking ? '🔄' : '🔍'}</span>
          <span>{isChecking ? 'Verificando...' : 'Buscar'}</span>
        </button>

        {/* Download Button */}
        {updateAvailable && updateInfo && (
          <button
            onClick={downloadUpdate}
            style={{
              flex: 1,
              padding: '10px 12px',
              background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
              color: 'white',
              border: 'none',
              borderRadius: '6px',
              fontSize: '12px',
              fontWeight: '600',
              cursor: 'pointer',
              transition: 'all 0.2s',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '6px'
            }}
          >
            <span style={{ fontSize: '14px' }}>⬇️</span>
            <span>Descargar</span>
          </button>
        )}
      </div>

      {/* Message Compacto */}
      {message && (
        <div style={{
          padding: '8px 10px',
          background: updateAvailable 
            ? '#d1fae5'
            : '#e0e7ff',
          borderRadius: '6px',
          marginBottom: '12px',
          textAlign: 'center',
          fontWeight: '600',
          fontSize: '11px',
          color: updateAvailable ? '#065f46' : '#3730a3',
          borderLeft: `3px solid ${updateAvailable ? '#10b981' : '#6366f1'}`
        }}>
          {message}
        </div>
      )}

      {/* Update Details Compacto */}
      {updateAvailable && updateInfo && (
        <div style={{
          background: '#fef3c7',
          padding: '12px',
          borderRadius: '8px',
          marginBottom: '12px',
          borderLeft: '3px solid #f59e0b'
        }}>
          <h3 style={{ 
            margin: '0 0 8px 0', 
            color: '#92400e',
            fontSize: '12px',
            fontWeight: '700'
          }}>
            🎉 Novedades v{updateInfo.version || updateInfo.latestVersion}
          </h3>
          <ul style={{ 
            margin: 0, 
            paddingLeft: '18px', 
            color: '#78350f',
            fontSize: '11px'
          }}>
            {(updateInfo.features || []).map((feature: string, index: number) => (
              <li key={index} style={{ marginBottom: '4px' }}>
                {feature}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Info Compacta */}
      <div style={{
        padding: '10px',
        background: 'var(--bg-secondary, #f9fafb)',
        borderRadius: '6px',
        fontSize: '10px',
        color: 'var(--text-secondary, #666)',
        lineHeight: '1.4'
      }}>
        <div style={{ fontWeight: '600', marginBottom: '4px' }}>
          ℹ️ Información
        </div>
        <div>
          • Verificación automática cada 6 horas<br/>
          • Notificaciones de nuevas versiones<br/>
          • Mejoras de seguridad y rendimiento
        </div>
      </div>
    </div>
  )
}
