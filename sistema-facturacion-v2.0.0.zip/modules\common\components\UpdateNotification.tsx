import { useState, useEffect } from 'react'

export default function UpdateNotification() {
  const [show, setShow] = useState(false)
  const [updateInfo, setUpdateInfo] = useState<any>(null)

  useEffect(() => {
    // Verificar al cargar
    checkForUpdates()
    
    // Verificar cada 6 horas
    const interval = setInterval(() => {
      checkForUpdates()
    }, 6 * 60 * 60 * 1000)
    
    return () => clearInterval(interval)
  }, [])

  const checkForUpdates = async () => {
    try {
      const url = `https://raw.githubusercontent.com/puntodeventasystempro-design/sistema-actualizaciones/main/updates.json?t=${Date.now()}`
      
      const response = await fetch(url, {
        cache: 'no-cache'
      })
      
      if (!response.ok) return
      
      const data = await response.json()
      const currentVersion = '1.0.0'
      const newVersion = data.version || data.latestVersion
      
      // Comparar versiones
      if (compareVersions(newVersion, currentVersion)) {
        setUpdateInfo(data)
        setShow(true)
      }
      
    } catch (error) {
      console.error('Error verificando actualizaciones:', error)
    }
  }

  const compareVersions = (newVer: string, currentVer: string): boolean => {
    const newParts = newVer.split('.').map(Number)
    const currentParts = currentVer.split('.').map(Number)
    
    for (let i = 0; i < 3; i++) {
      const newPart = newParts[i] || 0
      const currentPart = currentParts[i] || 0
      
      if (newPart > currentPart) return true
      if (newPart < currentPart) return false
    }
    
    return false
  }

  const downloadUpdate = () => {
    if (updateInfo?.downloadUrl) {
      window.open(updateInfo.downloadUrl, '_blank')
      setShow(false)
    }
  }

  if (!show || !updateInfo) return null

  return (
    <div style={{
      position: 'fixed',
      top: '20px',
      right: '20px',
      width: '350px',
      background: 'white',
      borderRadius: '12px',
      boxShadow: '0 10px 40px rgba(0,0,0,0.2)',
      zIndex: 9999,
      overflow: 'hidden',
      animation: 'slideIn 0.3s ease-out'
    }}>
      <style>{`
        @keyframes slideIn {
          from {
            transform: translateX(400px);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }
      `}</style>
      
      {/* Header */}
      <div style={{
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        padding: '15px',
        color: 'white',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <span style={{ fontSize: '24px' }}>🔔</span>
          <div>
            <div style={{ fontWeight: 'bold', fontSize: '16px' }}>
              Nueva Actualización
            </div>
            <div style={{ fontSize: '12px', opacity: 0.9 }}>
              v{updateInfo.version || updateInfo.latestVersion}
            </div>
          </div>
        </div>
        <button
          onClick={() => setShow(false)}
          style={{
            background: 'transparent',
            border: 'none',
            color: 'white',
            fontSize: '20px',
            cursor: 'pointer',
            padding: '5px'
          }}
        >
          ✕
        </button>
      </div>

      {/* Body */}
      <div style={{ padding: '15px' }}>
        <div style={{ marginBottom: '15px' }}>
          <div style={{ fontWeight: '600', marginBottom: '8px', color: '#333' }}>
            Novedades:
          </div>
          <ul style={{ margin: 0, paddingLeft: '20px', fontSize: '13px', color: '#666' }}>
            {(updateInfo.features || []).slice(0, 3).map((feature: string, index: number) => (
              <li key={index} style={{ marginBottom: '5px' }}>
                {feature}
              </li>
            ))}
          </ul>
        </div>

        {/* Buttons */}
        <div style={{ display: 'flex', gap: '10px' }}>
          <button
            onClick={downloadUpdate}
            style={{
              flex: 1,
              padding: '10px',
              background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              fontSize: '14px',
              fontWeight: 'bold',
              cursor: 'pointer'
            }}
          >
            ⬇️ Descargar
          </button>
          <button
            onClick={() => setShow(false)}
            style={{
              flex: 1,
              padding: '10px',
              background: '#f3f4f6',
              color: '#374151',
              border: 'none',
              borderRadius: '8px',
              fontSize: '14px',
              fontWeight: '600',
              cursor: 'pointer'
            }}
          >
            Más tarde
          </button>
        </div>
      </div>
    </div>
  )
}
