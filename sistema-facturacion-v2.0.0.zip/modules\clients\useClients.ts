import { useState, useEffect, useMemo } from 'react'
import { Client } from '../common/types'
import { saveToVirtualFile, loadFromVirtualFile, exportModuleData } from '../common/utils'

const CLIENTS_KEY = 'pos_clients'
const MODULE_NAME = 'clients'
const FILENAME = 'clients.json'

// Tipo helper para el formulario
interface ClientFormData {
  name: string
  email: string
  phone: string
  nit: string
  address: string
  debtAmount: number
}

// Datos de prueba
const CLIENTES_PRUEBA: Client[] = [
  { id: 'CLT-001', name: 'Juan Pérez García', email: 'juan.perez@email.com', phone: '3001234567', nit: '123456789-0', address: 'Calle 123 #45-67', debtAmount: 0 },
  { id: 'CLT-002', name: 'María Rodríguez López', email: 'maria.rodriguez@email.com', phone: '3109876543', nit: '987654321-1', address: 'Carrera 45 #67-89', debtAmount: 0 },
  { id: 'CLT-003', name: 'Carlos Martínez Silva', email: 'carlos.martinez@email.com', phone: '3204567890', nit: '456789123-2', address: 'Avenida 10 #20-30', debtAmount: 0 },
  { id: 'CLT-004', name: 'Ana María González', email: 'ana.gonzalez@email.com', phone: '3012345678', nit: '789123456-3', address: 'Calle 50 #30-40', debtAmount: 0 },
  { id: 'CLT-005', name: 'Pedro Antonio Díaz', email: 'pedro.diaz@email.com', phone: '3123456789', nit: '321654987-4', address: 'Carrera 15 #25-35', debtAmount: 0 },
  { id: 'CLT-006', name: 'Laura Elena Castro', email: 'laura.castro@email.com', phone: '3156789012', nit: '654987321-5', address: 'Calle 80 #10-20', debtAmount: 0 },
  { id: 'CLT-007', name: 'Roberto Carlos Vega', email: 'roberto.vega@email.com', phone: '3189012345', nit: '159753468-6', address: 'Avenida 30 #40-50', debtAmount: 0 },
  { id: 'CLT-008', name: 'Diana Patricia Ruiz', email: 'diana.ruiz@email.com', phone: '3190123456', nit: '753951456-7', address: 'Carrera 25 #35-45', debtAmount: 0 },
  { id: 'CLT-009', name: 'Miguel Ángel Torres', email: 'miguel.torres@email.com', phone: '3145678901', nit: '357159852-8', address: 'Calle 15 #55-65', debtAmount: 0 },
  { id: 'CLT-010', name: 'Carmen Rosa Morales', email: 'carmen.morales@email.com', phone: '3167890123', nit: '951753654-9', address: 'Avenida 50 #60-70', debtAmount: 0 },
  { id: 'CLT-011', name: 'Fernando José Herrera', email: 'fernando.herrera@email.com', phone: '3178901234', nit: '258456789-0', address: 'Carrera 35 #45-55', debtAmount: 0 },
  { id: 'CLT-012', name: 'Patricia Isabel Luna', email: 'patricia.luna@email.com', phone: '3134567890', nit: '456789123-1', address: 'Calle 65 #75-85', debtAmount: 0 },
  { id: 'CLT-013', name: 'Jorge Alberto Mendoza', email: 'jorge.mendoza@email.com', phone: '3112345678', nit: '789456123-2', address: 'Avenida 20 #30-40', debtAmount: 0 },
  { id: 'CLT-014', name: 'Sofia Alejandra Reyes', email: 'sofia.reyes@email.com', phone: '3223456789', nit: '123789456-3', address: 'Carrera 55 #65-75', debtAmount: 0 },
  { id: 'CLT-015', name: 'Andrés Felipe Ortiz', email: 'andres.ortiz@email.com', phone: '3234567890', nit: '456123789-4', address: 'Calle 35 #25-15', debtAmount: 0 },
];

export function useClients() {
  const [clients, setClients] = useState<Client[]>(() => {
    // Intentar cargar desde archivo virtual primero
    const fromFile = loadFromVirtualFile<Client[]>(MODULE_NAME, FILENAME)
    if (fromFile && Array.isArray(fromFile) && fromFile.length > 0) {
      return fromFile
    }
    // Luego intentar localStorage
    try {
      const saved = localStorage.getItem(CLIENTS_KEY)
      if (saved) {
        const parsed = JSON.parse(saved)
        if (Array.isArray(parsed)) {
          return parsed
        }
      }
    } catch (e) {
      console.log('Error al cargar clientes desde localStorage')
    }
    // Iniciar con lista vacía (no cargar datos de prueba automáticamente)
    return []
  })

  // Persistir cambios en archivo virtual y localStorage
  useEffect(() => {
    // Guardar en archivo virtual
    saveToVirtualFile(MODULE_NAME, FILENAME, clients)
    // Mantener respaldo en localStorage
    localStorage.setItem(CLIENTS_KEY, JSON.stringify(clients))
  }, [clients])

  // ==================== CRUD Operations ====================

  // Función para migrar IDs existentes al nuevo formato
  const migrateClientIds = () => {
    const sortedClients = [...clients].sort((a, b) => {
      // Primero los que ya tienen el formato correcto
      const aMatch = a.id.match(/^CLT-(\d+)$/)
      const bMatch = b.id.match(/^CLT-(\d+)$/)
      if (aMatch && !bMatch) return -1
      if (!aMatch && bMatch) return 1
      if (aMatch && bMatch) return parseInt(aMatch[1]) - parseInt(bMatch[1])
      return a.name.localeCompare(b.name)
    })
    
    let counter = 1
    const migratedClients = sortedClients.map(client => {
      const match = client.id.match(/^CLT-(\d+)$/)
      if (match) {
        // Ya tiene el formato correcto
        counter = Math.max(counter, parseInt(match[1]) + 1)
        return client
      }
      // Asignar nuevo ID
      const newId = `CLT-${counter.toString().padStart(3, '0')}`
      counter++
      return { ...client, id: newId }
    })
    
    setClients(migratedClients)
    return migratedClients
  }

  // Función para migrar y establecer initialDebt en clientes existentes
  const migrateInitialDebt = () => {
    const migratedClients = clients.map(client => {
      // Si ya tiene initialDebt, no hacer nada
      if (client.initialDebt !== undefined) return client
      
      // Calcular initialDebt basándose en deuda actual + suma de abonos
      const currentDebt = client.debtAmount || 0
      const totalPaid = (client.paymentHistory || []).reduce((sum, p) => sum + p.amount, 0)
      const calculatedInitialDebt = currentDebt + totalPaid
      
      // Solo establecer initialDebt si hay deuda actual o historial de pagos
      if (calculatedInitialDebt > 0) {
        return { ...client, initialDebt: calculatedInitialDebt }
      }
      
      return client
    })
    
    setClients(migratedClients)
    return migratedClients
  }

  const addClient = (client: ClientFormData) => {
    // Obtener todos los IDs numéricos existentes
    const existingIds = clients.map(c => {
      const match = c.id.match(/^CLT-(\d+)$/)
      return match ? parseInt(match[1]) : 0
    }).filter(id => id > 0).sort((a, b) => a - b)
    
    // Buscar el primer ID faltante en la secuencia
    let newIdNumber = 1
    for (let i = 0; i < existingIds.length; i++) {
      if (existingIds[i] !== i + 1) {
        newIdNumber = i + 1
        break
      }
    }
    // Si no hay huecos, usar el siguiente número
    if (newIdNumber === 1 && existingIds.length > 0) {
      newIdNumber = existingIds[existingIds.length - 1] + 1
    }
    
    const newId = `CLT-${newIdNumber.toString().padStart(3, '0')}`
    
    const debtAmount = client.debtAmount || 0
    const newClient: Client = {
      id: newId,
      name: client.name,
      email: client.email || undefined,
      phone: client.phone || undefined,
      nit: client.nit || undefined,
      address: client.address || undefined,
      debtAmount: debtAmount,
      initialDebt: debtAmount > 0 ? debtAmount : undefined,  // Guardar deuda inicial si hay deuda
    }
    
    // Agregar y ordenar alfabéticamente por nombre
    setClients(prev => [...prev, newClient].sort((a, b) => a.name.localeCompare(b.name)))
    return newClient
  }

  const updateClient = (id: string, data: Partial<Client>) => {
    setClients(prev => prev.map(client => {
      if (client.id !== id) return client
      // Merge existing client with incoming data. If `data` provides a `paymentHistory`, use it;
      // otherwise preserve the existing `paymentHistory`.
      const merged = { ...client, ...data } as Client
      if (data.paymentHistory === undefined) {
        merged.paymentHistory = client.paymentHistory || []
      }
      
      // Si se está actualizando la deuda y no existe initialDebt, establecerla
      if (data.debtAmount !== undefined && !client.initialDebt && data.debtAmount > 0) {
        merged.initialDebt = data.debtAmount
      }
      
      // Si la deuda actual es mayor que la inicial guardada, actualizar la inicial
      if (merged.debtAmount && merged.initialDebt && merged.debtAmount > merged.initialDebt) {
        merged.initialDebt = merged.debtAmount
      }
      
      return merged
    }).sort((a, b) => a.name.localeCompare(b.name)))
  }

  const deleteClient = (id: string) => {
    setClients(prev => prev.filter(client => client.id !== id))
  }

  const getClient = (id: string) => {
    return clients.find(client => client.id === id)
  }

  // ==================== Búsqueda ====================

  const searchClients = (query: string) => {
    if (!query.trim()) return clients
    
    const lowerQuery = query.toLowerCase()
    return clients.filter(client =>
      client.name.toLowerCase().includes(lowerQuery) ||
      client.email?.toLowerCase().includes(lowerQuery) ||
      client.nit?.toLowerCase().includes(lowerQuery) ||
      client.phone?.includes(query)
    )
  }

  // ==================== Validación ====================

  const validateClient = (client: ClientFormData, excludeId?: string): { valid: boolean; errors: string[] } => {
    const errors: string[] = []

    if (!client.name.trim()) {
      errors.push('El nombre es requerido')
    }

    if (client.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(client.email)) {
      errors.push('El email no es valido')
    }

    // Verificar NIT unico (excluyendo el cliente actual si se esta editando)
    if (client.nit) {
      const existing = clients.find(c => c.nit === client.nit && c.id !== excludeId)
      if (existing) {
        errors.push('Ya existe un cliente con este NIT')
      }
    }

    return {
      valid: errors.length === 0,
      errors
    }
  }

  // ==================== Utilidades ====================

  const getClientCount = useMemo(() => {
    return clients.length
  }, [clients])

  const getClientsWithDebt = useMemo(() => {
    return clients.filter(client => (client.debtAmount || 0) > 0)
  }, [clients])

  // Clientes que han pagado toda su deuda (tienen historial pero deuda = 0)
  const getClientsWithPaidDebt = useMemo(() => {
    return clients.filter(client => 
      (client.debtAmount || 0) === 0 && 
      client.paymentHistory && 
      client.paymentHistory.length > 0
    )
  }, [clients])

  const totalDebt = useMemo(() => {
    return clients.reduce((sum, client) => sum + (client.debtAmount || 0), 0)
  }, [clients])

  // ==================== Export/Import ====================

  const exportToFile = async () => {
    await exportModuleData(MODULE_NAME, 'clients.json')
  }

  const importFromFile = (file: File): Promise<boolean> => {
    return new Promise((resolve) => {
      const reader = new FileReader()
      reader.onload = (event) => {
        try {
          const data = JSON.parse(event.target?.result as string)
          if (Array.isArray(data)) {
            setClients(data)
            resolve(true)
          } else {
            resolve(false)
          }
        } catch {
          resolve(false)
        }
      }
      reader.readAsText(file)
    })
  }

  // Eliminar un abono del historial y recalcular la deuda y los saldos
  const removePayment = (clientId: string, paymentId: string) => {
    setClients(prev => prev.map(client => {
      if (client.id !== clientId) return client
      const history = client.paymentHistory || []
      if (history.length === 0) return client

      // Calcular deuda original antes de abonos: deuda actual + suma de todos los abonos
      const totalPaid = history.reduce((s, p) => s + (p.amount || 0), 0)
      const startingDebt = (client.debtAmount || 0) + totalPaid

      // Eliminar el abono
      const remainingPayments = history.filter(p => p.id !== paymentId)

      // Recalcular deuda y reconstruir historial con initialDebt y remainingBalance
      let current = startingDebt
      const rebuilt: typeof history = []
      for (const p of remainingPayments) {
        const initial = current
        const remaining = Math.max(0, initial - p.amount)
        rebuilt.push({ ...p, initialDebt: initial, remainingBalance: remaining })
        current = remaining
      }

      return { ...client, debtAmount: current, paymentHistory: rebuilt }
    }))
  }

  return {
    // Estado
    clients,
    setClients,
    // CRUD
    addClient,
    updateClient,
    deleteClient,
    getClient,
    migrateClientIds,
    migrateInitialDebt,
    // Busqueda
    searchClients,
    // Validacion
    validateClient,
    // Utilidades
    getClientCount,
    getClientsWithDebt,
    getClientsWithPaidDebt,
    totalDebt,
    // Export/Import
    exportToFile,
    importFromFile,
    removePayment,
  }
}
