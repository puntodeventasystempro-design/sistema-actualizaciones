import { useState, useEffect } from 'react'
import { UserProfile, CompanyConfig } from '../common/types'
import { saveToVirtualFile, loadFromVirtualFile, exportModuleData } from '../common/utils'

const USER_PROFILE_KEY = 'pos_user_profile'
const COMPANY_CONFIG_KEY = 'pos_company_config'
const PRINTER_CONFIG_KEY = 'pos_printer_config'
const PRINTERS_KEY = 'pos_printers'
const THEME_KEY = 'pos_theme'
const LICENSE_KEY = 'pos_license'
const LICENSE_STATUS_KEY = 'pos_license_status'
const MODULE_NAME = 'settings'

export function useSettings() {
  // User Profile
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    // Intentar cargar desde archivo virtual primero
    const fromFile = loadFromVirtualFile<{ userProfile: UserProfile }>(MODULE_NAME, 'userProfile.json')
    if (fromFile && fromFile.userProfile) {
      return fromFile.userProfile
    }
    // Luego intentar localStorage
    try {
      const data = localStorage.getItem(USER_PROFILE_KEY)
      const parsed = data ? JSON.parse(data) : null
      // Verificar si tiene la estructura anidada
      if (parsed && parsed.userProfile) {
        return parsed.userProfile
      }
      return parsed || { name: '', email: '', phone: '', nit: '', address: '', photo: '' }
    } catch {
      return { name: '', email: '', phone: '', nit: '', address: '', photo: '' }
    }
  })

  // Company Config
  const [companyConfig, setCompanyConfig] = useState<CompanyConfig>(() => {
    // Intentar cargar desde archivo virtual primero
    const fromFile = loadFromVirtualFile<CompanyConfig>(MODULE_NAME, 'companyConfig.json')
    if (fromFile) {
      return fromFile
    }
    // Luego intentar localStorage
    try {
      const data = localStorage.getItem(COMPANY_CONFIG_KEY)
      return data ? JSON.parse(data) : { 
        companyName: '', 
        companyNIT: '', 
        taxRate: 19, 
        applyTax: true, 
        currency: 'COP', 
        invoiceFormat: 'ticket80', 
        logo: '',
        invoiceFooter: '',
        invoiceFontSize: 11,
        address: '',
        phone: '',
        email: '',
        // Opciones de impresión
        autoPrint: false,
        saveToFolder: true,
        printSilent: true
      }
    } catch {
      return { 
        companyName: '', 
        companyNIT: '', 
        taxRate: 19, 
        applyTax: true, 
        currency: 'COP', 
        invoiceFormat: 'ticket80', 
        logo: '',
        invoiceFooter: '',
        invoiceFontSize: 11,
        address: '',
        phone: '',
        email: '',
        // Opciones de impresión
        autoPrint: false,
        saveToFolder: true,
        printSilent: true
      }
    }
  })

  // Printer Config
  const [printerConfig, setPrinterConfig] = useState<any>(() => {
    try {
      const data = localStorage.getItem(PRINTER_CONFIG_KEY)
      return data ? JSON.parse(data) : {
        printerName: '',
        printerType: 'virtual',
        ipAddress: '',
        port: 9100,
        paperSize: '80mm',
        defaultCopies: 1,
        autoPrintAfterSale: false,
        savePdfToFolder: true
      }
    } catch {
      return {
        printerName: '',
        printerType: 'virtual',
        ipAddress: '',
        port: 9100,
        paperSize: '80mm',
        defaultCopies: 1,
        autoPrintAfterSale: false,
        savePdfToFolder: true
      }
    }
  })

  // Lista de impresoras guardadas (nombres)
  const [printers, setPrinters] = useState<string[]>(() => {
    try {
      const data = localStorage.getItem(PRINTERS_KEY)
      return data ? JSON.parse(data) : []
    } catch {
      return []
    }
  })

  const addPrinter = (name: string) => {
    if (!name) return
    try {
      setPrinters(prev => {
        const exists = prev.includes(name)
        if (exists) return prev
        const next = [...prev, name]
        try { localStorage.setItem(PRINTERS_KEY, JSON.stringify(next)) } catch {}
        try { saveToVirtualFile(MODULE_NAME, 'printers.json', next) } catch {}
        console.log('[useSettings] addPrinter:', name)
        return next
      })
    } catch (err) {
      console.error('[useSettings] addPrinter error:', err)
    }
  }

  const removePrinter = (name: string) => {
    setPrinters(prev => {
      const next = prev.filter(p => p !== name)
      try { localStorage.setItem(PRINTERS_KEY, JSON.stringify(next)) } catch {}
      saveToVirtualFile(MODULE_NAME, 'printers.json', next)
      return next
    })
  }

  // Theme
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const saved = localStorage.getItem(THEME_KEY)
    return saved ? saved === 'dark' : false
  })

  // Persistir cambios en archivo virtual y localStorage
  useEffect(() => {
    saveToVirtualFile(MODULE_NAME, 'userProfile.json', userProfile)
    localStorage.setItem(USER_PROFILE_KEY, JSON.stringify(userProfile))
  }, [userProfile])

  useEffect(() => {
    saveToVirtualFile(MODULE_NAME, 'companyConfig.json', companyConfig)
    localStorage.setItem(COMPANY_CONFIG_KEY, JSON.stringify(companyConfig))
    // Si se actualizó el nombre de impresora en companyConfig, asegurar que esté en la lista
    try {
      const pname = (companyConfig as any).printerName
      if (pname && typeof pname === 'string') {
        setPrinters(prev => {
          if (prev.includes(pname)) return prev
          const next = [...prev, pname]
          try { localStorage.setItem(PRINTERS_KEY, JSON.stringify(next)) } catch {}
          try { saveToVirtualFile(MODULE_NAME, 'printers.json', next) } catch {}
          console.log('[useSettings] added printer from companyConfig:', pname)
          return next
        })
      }
    } catch (err) {
      console.warn('Error syncing printerName to printers list', err)
    }
  }, [companyConfig])

  useEffect(() => {
    saveToVirtualFile(MODULE_NAME, 'printerConfig.json', printerConfig)
    localStorage.setItem(PRINTER_CONFIG_KEY, JSON.stringify(printerConfig))
  }, [printerConfig])

  useEffect(() => {
    // Ensure printers list is persisted
    try { localStorage.setItem(PRINTERS_KEY, JSON.stringify(printers)) } catch {}
    saveToVirtualFile(MODULE_NAME, 'printers.json', printers)
  }, [printers])

  useEffect(() => {
    localStorage.setItem(THEME_KEY, isDarkMode ? 'dark' : 'light')
    
    // Aplicar tema al documento
    document.documentElement.classList.toggle('dark', isDarkMode)
    document.body.classList.toggle('dark-theme', isDarkMode)
  }, [isDarkMode])

  // ==================== User Profile ====================

  const updateUserProfile = (data: Partial<UserProfile>) => {
    setUserProfile(prev => ({ ...prev, ...data }))
  }

  const updateUserPhoto = (photoData: string) => {
    setUserProfile(prev => ({ ...prev, photo: photoData || '' }))
  }

  // ==================== Company Config ====================

  const updateCompanyConfig = (data: Partial<CompanyConfig>) => {
    setCompanyConfig(prev => ({ ...prev, ...data }))
  }

  const updatePrinterConfig = (data: Partial<any>) => {
    setPrinterConfig(prev => ({ ...prev, ...data }))
  }


  // ==================== Theme ====================

  const toggleTheme = () => {
    setIsDarkMode(prev => !prev)
  }

  // ==================== Backup ====================

  const exportBackup = () => {
    const backup = {
      version: '1.0',
      createdAt: new Date().toISOString(),
      userProfile,
      companyConfig,
      // Incluir datos de localStorage
    }

    // Obtener todos los datos del localStorage
    const localStorageData: Record<string, string> = {}
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i)
      if (key) {
        localStorageData[key] = localStorage.getItem(key) || ''
      }
    }
    ;(backup as any).localStorageData = localStorageData

    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `backup_${new Date().toISOString().split('T')[0]}.json`
    link.click()
    URL.revokeObjectURL(url)
  }

  const importBackup = (file: File): Promise<boolean> => {
    return new Promise((resolve) => {
      const reader = new FileReader()
      reader.onload = (event) => {
        try {
          const backup = JSON.parse(event.target?.result as string)
          
          // Restaurar userProfile
          if (backup.userProfile) {
            setUserProfile(backup.userProfile)
          }
          
          // Restaurar companyConfig
          if (backup.companyConfig) {
            setCompanyConfig(backup.companyConfig)
          }
          
          // Restaurar localStorage
          if (backup.localStorageData) {
            Object.entries(backup.localStorageData).forEach(([key, value]) => {
              localStorage.setItem(key, value as string)
            })
          }
          
          resolve(true)
        } catch (error) {
          console.error('Error importing backup:', error)
          resolve(false)
        }
      }
      reader.readAsText(file)
    })
  }

  const clearAllData = async () => {
    const confirmed1 = window.confirm('⚠️ ATENCIÓN: Se eliminarán TODOS los datos del sistema:\n\n✓ Productos\n✓ Contactos/Clientes\n✓ Ventas/Historial\n✓ Configuración\n✓ Facturas guardadas\n\nEsta acción es IRREVERSIBLE. ¿Continuar?')
    if (!confirmed1) return
    
    const confirmed2 = window.confirm('Ultima confirmacion: ¿Realmente deseas eliminar todos los datos?')
    if (!confirmed2) return
    
    // Limpiar localStorage
    try {
      // Obtener todas las claves antes de limpiar
      const keys: string[] = []
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i)
        if (key) keys.push(key)
      }
      
      // Eliminar cada clave manualmente
      keys.forEach(key => localStorage.removeItem(key))
      
      console.log('Datos eliminados:', keys.length, 'claves borradas')
      
      // Verificar que se limpió
      if (localStorage.length > 0) {
        console.warn('Aún quedan datos en localStorage, forzando limpieza...')
        localStorage.clear()
      }
      
      // Recargar con múltiples métodos
      setTimeout(() => {
        window.location.href = '/'
        setTimeout(() => {
          window.location.reload()
          setTimeout(() => {
            window.document.location.replace(window.document.location.href)
          }, 500)
        }, 500)
      }, 100)
      
    } catch (error) {
      console.error('Error al eliminar datos:', error)
      alert('Error al eliminar los datos. Por favor intenta de nuevo.')
    }
  }

  // ==================== License System ====================
  
  // Estado de licencia
  const [licenseStatus, setLicenseStatus] = useState<'active' | 'inactive' | 'expired'>(
    () => {
      const status = localStorage.getItem(LICENSE_STATUS_KEY)
      return (status as 'active' | 'inactive' | 'expired') || 'inactive'
    }
  )
  
  const [licenseKey, setLicenseKey] = useState(() => {
    return localStorage.getItem(LICENSE_KEY) || ''
  })
  
  // Generar licencia alfanumérica
  const generateLicense = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    const segments = []
    for (let i = 0; i < 4; i++) {
      let segment = ''
      for (let j = 0; j < 5; j++) {
        segment += chars.charAt(Math.floor(Math.random() * chars.length))
      }
      segments.push(segment)
    }
    return segments.join('-') // Formato: ABCDE-FGHIJ-KLMNO-PQRST
  }
  
  // Activar licencia
  const activateLicense = (key: string): boolean => {
    const cleanedKey = key.toUpperCase().trim()
    
    // Validar formato (XXXXX-XXXXX-XXXXX-XXXXX)
    const pattern = /^[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5}$/
    
    if (!pattern.test(cleanedKey)) {
      return false
    }
    
    // Guardar licencia
    localStorage.setItem(LICENSE_KEY, cleanedKey)
    localStorage.setItem(LICENSE_STATUS_KEY, 'active')
    setLicenseKey(cleanedKey)
    setLicenseStatus('active')
    
    return true
  }
  
  // Verificar si está activado
  const isLicensed = () => {
    return licenseStatus === 'active'
  }
  
  // Verificar licencia (revisar formato y estado)
  const checkLicense = () => {
    const storedKey = localStorage.getItem(LICENSE_KEY)
    const storedStatus = localStorage.getItem(LICENSE_STATUS_KEY)
    
    if (!storedKey || !storedStatus) {
      return { valid: false, status: 'inactive', key: '' }
    }
    
    const pattern = /^[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5}$/
    
    return {
      valid: pattern.test(storedKey) && storedStatus === 'active',
      status: storedStatus as 'active' | 'inactive' | 'expired',
      key: storedKey
    }
  }

  // ==================== Export/Import a Archivo ====================

  const exportSettingsToFile = async () => {
    await exportModuleData(MODULE_NAME, 'settings.json')
  }

  const importSettingsFromFile = (file: File): Promise<boolean> => {
    return new Promise((resolve) => {
      const reader = new FileReader()
      reader.onload = (event) => {
        try {
          const data = JSON.parse(event.target?.result as string)
          if (data.userProfile) {
            setUserProfile(data.userProfile)
          }
          if (data.companyConfig) {
            setCompanyConfig(data.companyConfig)
          }
          if (data.printerConfig) {
            setPrinterConfig(data.printerConfig)
          }
          resolve(true)
        } catch {
          resolve(false)
        }
      }
      reader.readAsText(file)
    })
  }

  return {
    // User Profile
    userProfile,
    updateUserProfile,
    updateUserPhoto,
    // Company Config
    companyConfig,
    updateCompanyConfig,
    // Printer
    printerConfig,
    updatePrinterConfig,
    printers,
    addPrinter,
    removePrinter,
    // Theme
    isDarkMode,
    toggleTheme,
    // Backup
    exportBackup,
    importBackup,
    clearAllData,
    // Export/Import a Archivo
    exportSettingsToFile,
    importSettingsFromFile,
    // License
    generateLicense,
    activateLicense,
    isLicensed,
    licenseKey,
    licenseStatus,
    checkLicense,
    setLicenseStatus
  }
}
