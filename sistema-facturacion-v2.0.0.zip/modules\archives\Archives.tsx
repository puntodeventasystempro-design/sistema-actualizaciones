import React, { useState } from 'react'
import { useArchives } from './useArchives'

export default function Archives() {
  const {
    invoices,
    salesHistory,
    searchInvoices,
    deleteInvoice,
    downloadInvoiceHTML,
    printInvoiceHTML,
    getInvoiceCount,
    getTotalInvoiced,
  } = useArchives()

  const [searchQuery, setSearchQuery] = useState('')
  const [selectedInvoice, setSelectedInvoice] = useState<string | null>(null)
  const [showPreview, setShowPreview] = useState(false)

  const filteredInvoices = searchInvoices(searchQuery)

  const formatCurrency = (amount: number) => {
    return `$ ${amount.toLocaleString('es-CO')}`
  }

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    return date.toLocaleDateString('es-CO', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const getSaleDetails = (saleId: string) => {
    return salesHistory.find(s => s.id === saleId)
  }

  const handlePreview = (invoiceId: string) => {
    setSelectedInvoice(invoiceId)
    setShowPreview(true)
  }

  const handleDownload = (invoiceId: string) => {
    // Obtener configs del localStorage
    const companyConfig = JSON.parse(localStorage.getItem('pos_company_config') || '{}')
    const userProfile = JSON.parse(localStorage.getItem('pos_user_profile') || '{}')
    downloadInvoiceHTML(invoiceId, companyConfig, userProfile)
  }

  const handlePrint = (invoiceId: string) => {
    // Obtener configs del localStorage
    const companyConfig = JSON.parse(localStorage.getItem('pos_company_config') || '{}')
    const userProfile = JSON.parse(localStorage.getItem('pos_user_profile') || '{}')
    printInvoiceHTML(invoiceId, companyConfig, userProfile)
  }

  const handleDelete = (invoiceId: string) => {
    if (window.confirm('Estas seguro de eliminar esta factura?')) {
      deleteInvoice(invoiceId)
    }
  }

  return (
    <div className="module-body">

      {/* Stats */}
      <div style={{ display: 'flex', gap: '20px', marginBottom: '20px' }}>
        <div style={{ 
          background: 'var(--card-bg, #fff)', 
          padding: '15px', 
          borderRadius: '8px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          flex: 1
        }}>
          <strong>Total Facturas:</strong> {getInvoiceCount}
        </div>
        <div style={{ 
          background: 'var(--card-bg, #fff)', 
          padding: '15px', 
          borderRadius: '8px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          flex: 1
        }}>
          <strong>Total Facturado:</strong> {formatCurrency(getTotalInvoiced)}
        </div>
      </div>

      {/* Search */}
      <div style={{ marginBottom: '20px', display: 'flex', gap: '10px', alignItems: 'center' }}>
        <input
          type="text"
          placeholder="Buscar por ID de factura o venta..."
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          style={{
            flex: 1,
            padding: '12px',
            borderRadius: '8px',
            border: '1px solid #ddd',
            fontSize: '14px'
          }}
        />
        <button
          onClick={async () => {
            if (invoices.length === 0) {
              alert('No hay facturas para descargar')
              return
            }
            if (window.confirm(`¿Descargar todas las ${invoices.length} facturas en un archivo ZIP?`)) {
              try {
                // Importar JSZip dinámicamente
                const JSZip = (await import('https://cdn.jsdelivr.net/npm/jszip@3.10.1/+esm')).default
                
                const zip = new JSZip()
                const companyConfig = JSON.parse(localStorage.getItem('pos_company_config') || '{}')
                const userProfile = JSON.parse(localStorage.getItem('pos_user_profile') || '{}')
                
                // Agregar cada factura al ZIP
                for (const invoice of invoices) {
                  let html = ''
                  
                  // Si la factura tiene HTML guardado, usarlo
                  if (invoice.html) {
                    html = invoice.html
                  } else {
                    // Si no, intentar obtenerlo del servidor o regenerarlo
                    try {
                      const response = await fetch(`http://localhost:4000/invoice/${invoice.id}`)
                      const data = await response.json()
                      if (data.ok && data.html) {
                        html = data.html
                      } else {
                        throw new Error('No encontrado en servidor')
                      }
                    } catch {
                      // Regenerar desde salesHistory
                      const sale = salesHistory.find(s => s.id === invoice.saleId)
                      if (sale) {
                        // Usar la función generateInvoiceHTML del hook
                        const formatCurrency = (amount: number) => `$ ${amount.toLocaleString('es-CO')}`
                        const formatDate = (dateStr: string) => {
                          const date = new Date(dateStr)
                          return date.toLocaleDateString('es-CO', {
                            day: '2-digit',
                            month: 'long',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })
                        }
                        
                        const itemsHTML = sale.items.map(item => `
                          <tr>
                            <td style="padding: 8px; border: 1px solid #ddd;">${item.name}</td>
                            <td style="padding: 8px; border: 1px solid #ddd; text-align: center;">${item.qty}</td>
                            <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${formatCurrency(item.price)}</td>
                            <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${formatCurrency(item.price * item.qty)}</td>
                          </tr>
                        `).join('')
                        
                        html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Factura ${sale.id}</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 0; padding: 20px; color: #333; }
    .invoice { max-width: 800px; margin: 0 auto; border: 2px solid #333; padding: 20px; }
    .header { display: flex; justify-content: space-between; margin-bottom: 20px; border-bottom: 2px solid #333; padding-bottom: 10px; }
    .company-info h1 { margin: 0; color: #0066cc; }
    .invoice-info { text-align: right; }
    table { width: 100%; border-collapse: collapse; margin: 20px 0; }
    th { background: #0066cc; color: white; padding: 10px; }
    .totals { margin-top: 20px; text-align: right; }
    .total { font-size: 18px; font-weight: bold; margin: 5px 0; }
    .footer { margin-top: 30px; text-align: center; font-size: 12px; color: #666; border-top: 1px solid #ddd; padding-top: 10px; }
  </style>
</head>
<body>
  <div class="invoice">
    <div class="header">
      <div class="company-info">
        <h1>${companyConfig?.companyName || 'Mi Empresa'}</h1>
        <p>NIT: ${companyConfig?.companyNIT || 'N/A'}</p>
        <p>${userProfile?.address || ''}</p>
        <p>Tel: ${userProfile?.phone || ''}</p>
      </div>
      <div class="invoice-info">
        <h2>FACTURA</h2>
        <p><strong>No:</strong> ${sale.id}</p>
        <p><strong>Fecha:</strong> ${formatDate(sale.timestamp || sale.date)}</p>
        <p><strong>Vendedor:</strong> ${userProfile?.name || 'Admin'}</p>
      </div>
    </div>
    <div style="margin-bottom: 20px;">
      <strong>Cliente:</strong> ${sale.client || 'Consumidor Final'}
    </div>
    <table>
      <thead>
        <tr>
          <th>Producto</th>
          <th>Cantidad</th>
          <th>Precio Unitario</th>
          <th>Subtotal</th>
        </tr>
      </thead>
      <tbody>
        ${itemsHTML}
      </tbody>
    </table>
    <div class="totals">
      <p class="total">Subtotal: ${formatCurrency(sale.subtotal)}</p>
      ${sale.discount > 0 ? `<p class="total" style="color: #e74c3c;">Descuento: -${formatCurrency(sale.discount)}</p>` : ''}
      ${sale.tax > 0 ? `<p class="total">IVA (${companyConfig?.taxRate || 19}%): ${formatCurrency(sale.tax)}</p>` : ''}
      <p class="total" style="font-size: 24px; color: #0066cc;">TOTAL: ${formatCurrency(sale.total)}</p>
    </div>
    <div class="footer">
      <p>Gracias por su compra</p>
      <p>Esta factura fue generada el ${formatDate(new Date().toISOString())}</p>
    </div>
  </div>
</body>
</html>`
                      }
                    }
                  }
                  
                  if (html) {
                    zip.file(`factura_${invoice.id}.html`, html)
                  }
                }
                
                // Generar el archivo ZIP
                const content = await zip.generateAsync({ type: 'blob' })
                
                // Descargar el ZIP
                const url = URL.createObjectURL(content)
                const link = document.createElement('a')
                link.href = url
                const fecha = new Date().toISOString().split('T')[0]
                link.download = `facturas_${fecha}.zip`
                link.click()
                URL.revokeObjectURL(url)
                
                alert(`✅ Descargado archivo ZIP con ${invoices.length} facturas`)
              } catch (error) {
                console.error('Error al crear ZIP:', error)
                alert('❌ Error al crear el archivo ZIP. Por favor intenta de nuevo.')
              }
            }
          }}
          style={{
            padding: '12px 20px',
            borderRadius: '8px',
            border: 'none',
            background: '#10b981',
            color: 'white',
            fontWeight: 'bold',
            cursor: 'pointer',
            whiteSpace: 'nowrap'
          }}
        >
          📥 Descargar Todo
        </button>
        <button
          onClick={() => {
            if (invoices.length === 0) {
              alert('No hay facturas para eliminar')
              return
            }
            if (window.confirm(`¿ELIMINAR TODAS las ${invoices.length} facturas? Esta acción NO se puede deshacer.`)) {
              if (window.confirm('¿Estás completamente seguro? Se eliminarán TODAS las facturas permanentemente.')) {
                // Eliminar todas las facturas
                invoices.forEach(invoice => {
                  deleteInvoice(invoice.id)
                })
                alert('Todas las facturas han sido eliminadas')
              }
            }
          }}
          style={{
            padding: '12px 20px',
            borderRadius: '8px',
            border: 'none',
            background: '#dc2626',
            color: 'white',
            fontWeight: 'bold',
            cursor: 'pointer',
            whiteSpace: 'nowrap'
          }}
        >
          🗑️ Eliminar Todo
        </button>
      </div>

      {/* Table */}
      <div style={{ 
        background: 'var(--card-bg, #fff)', 
        borderRadius: '12px',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
        overflow: 'auto',
        maxHeight: 'calc(100vh - 200px)'
      }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: 'var(--accent, #0066cc)', color: 'white' }}>
              <th style={{ padding: '12px', textAlign: 'left' }}>ID Factura</th>
              <th style={{ padding: '12px', textAlign: 'left' }}>ID Venta</th>
              <th style={{ padding: '12px', textAlign: 'left' }}>Fecha Creación</th>
              <th style={{ padding: '12px', textAlign: 'left' }}>Cliente</th>
              <th style={{ padding: '12px', textAlign: 'right' }}>Total</th>
              <th style={{ padding: '12px', textAlign: 'center' }}>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {filteredInvoices.length === 0 ? (
              <tr>
                <td colSpan={6} style={{ padding: '40px', textAlign: 'center', color: '#666' }}>
                  {searchQuery ? 'No se encontraron facturas' : 'No hay facturas registradas'}
                </td>
              </tr>
            ) : (
              filteredInvoices.map(invoice => {
                const sale = getSaleDetails(invoice.saleId)
                return (
                  <tr key={invoice.id} style={{ borderBottom: '1px solid #eee' }}>
                    <td style={{ padding: '12px', fontFamily: 'monospace', fontSize: '12px' }}>
                      {invoice.id}
                    </td>
                    <td style={{ padding: '12px', fontFamily: 'monospace', fontSize: '12px' }}>
                      {invoice.saleId}
                    </td>
                    <td style={{ padding: '12px', fontSize: '12px' }}>
                      {formatDate(invoice.createdAt)}
                    </td>
                    <td style={{ padding: '12px' }}>
                      {sale?.client || 'Consumidor Final'}
                    </td>
                    <td style={{ padding: '12px', textAlign: 'right', fontWeight: 'bold' }}>
                      {formatCurrency(sale?.total || 0)}
                    </td>
                    <td style={{ padding: '12px', textAlign: 'center' }}>
                      <button
                        onClick={() => handlePrint(invoice.id)}
                        style={{
                          padding: '6px 12px',
                          marginRight: '5px',
                          borderRadius: '4px',
                          border: 'none',
                          background: '#9b59b6',
                          color: 'white',
                          cursor: 'pointer',
                          fontSize: '12px'
                        }}
                        title="Imprimir"
                      >
                        🖨️
                      </button>
                      <button
                        onClick={() => handlePreview(invoice.id)}
                        style={{
                          padding: '6px 12px',
                          marginRight: '5px',
                          borderRadius: '4px',
                          border: 'none',
                          background: '#3498db',
                          color: 'white',
                          cursor: 'pointer',
                          fontSize: '12px'
                        }}
                        title="Vista previa"
                      >
                        👁️
                      </button>
                      <button
                        onClick={() => handleDownload(invoice.id)}
                        style={{
                          padding: '6px 12px',
                          marginRight: '5px',
                          borderRadius: '4px',
                          border: 'none',
                          background: '#27ae60',
                          color: 'white',
                          cursor: 'pointer',
                          fontSize: '12px'
                        }}
                        title="Descargar HTML"
                      >
                        📄
                      </button>
                      <button
                        onClick={() => handleDelete(invoice.id)}
                        style={{
                          padding: '6px 12px',
                          borderRadius: '4px',
                          border: 'none',
                          background: '#dc2626',
                          color: 'white',
                          fontWeight: 'bold',
                          cursor: 'pointer',
                          fontSize: '12px'
                        }}
                        title="Eliminar"
                      >
                        🗑️
                      </button>
                    </td>
                  </tr>
                )
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Preview Modal */}
      {showPreview && selectedInvoice && (() => {
        const invoice = invoices.find(i => i.id === selectedInvoice)
        const sale = invoice ? getSaleDetails(invoice.saleId) : null
        
        return (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'rgba(0,0,0,0.7)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 2000
          }}>
            <div style={{
              background: 'white',
              borderRadius: '12px',
              width: '800px',
              maxWidth: '95%',
              maxHeight: '90vh',
              overflow: 'auto',
              display: 'flex',
              flexDirection: 'column'
            }}>
              <div style={{
                padding: '20px',
                borderBottom: '1px solid #eee',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                position: 'sticky',
                top: 0,
                background: 'white',
                zIndex: 10
              }}>
                <h3 style={{ margin: 0 }}>Vista Previa: {selectedInvoice}</h3>
                <div style={{ display: 'flex', gap: '10px' }}>
                  <button
                    onClick={() => handleDownload(selectedInvoice)}
                    style={{
                      padding: '8px 16px',
                      borderRadius: '6px',
                      border: 'none',
                      background: '#27ae60',
                      color: 'white',
                      cursor: 'pointer'
                    }}
                  >
                    📄 Descargar
                  </button>
                  <button
                    onClick={() => setShowPreview(false)}
                    style={{
                      padding: '8px 16px',
                      borderRadius: '6px',
                      border: 'none',
                      background: '#dc2626',
                      color: 'white',
                      fontWeight: 'bold',
                      cursor: 'pointer'
                    }}
                  >
                    Cerrar
                  </button>
                </div>
              </div>
              
              <div style={{ padding: '20px' }}>
                {sale ? (
                  <div className="invoice-preview">
                    <div style={{ borderBottom: '2px solid #333', paddingBottom: '15px', marginBottom: '15px' }}>
                      <h1 style={{ color: '#0066cc', margin: '0 0 10px 0' }}>
                        {JSON.parse(localStorage.getItem('pos_company_config') || '{}').companyName || 'Mi Empresa'}
                      </h1>
                      <p style={{ margin: '5px 0' }}>
                        <strong>Factura:</strong> {sale.id}
                      </p>
                      <p style={{ margin: '5px 0' }}>
                        <strong>Fecha:</strong> {formatDate(sale.timestamp || sale.date)}
                      </p>
                      <p style={{ margin: '5px 0' }}>
                        <strong>Cliente:</strong> {sale.client || 'Consumidor Final'}
                      </p>
                    </div>

                    <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '20px' }}>
                      <thead>
                        <tr style={{ background: '#0066cc', color: 'white' }}>
                          <th style={{ padding: '10px', textAlign: 'left' }}>Producto</th>
                          <th style={{ padding: '10px', textAlign: 'center' }}>Cantidad</th>
                          <th style={{ padding: '10px', textAlign: 'right' }}>Precio</th>
                          <th style={{ padding: '10px', textAlign: 'right' }}>Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        {sale.items.map((item, i) => (
                          <tr key={i} style={{ borderBottom: '1px solid #eee' }}>
                            <td style={{ padding: '10px' }}>{item.name}</td>
                            <td style={{ padding: '10px', textAlign: 'center' }}>{item.qty}</td>
                            <td style={{ padding: '10px', textAlign: 'right' }}>{formatCurrency(item.price)}</td>
                            <td style={{ padding: '10px', textAlign: 'right' }}>{formatCurrency(item.price * item.qty)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>

                    <div style={{ textAlign: 'right' }}>
                      <p style={{ margin: '5px 0' }}><strong>Subtotal:</strong> {formatCurrency(sale.subtotal)}</p>
                      {sale.discount > 0 && (
                        <p style={{ margin: '5px 0', color: '#e74c3c' }}>
                          <strong>Descuento:</strong> -{formatCurrency(sale.discount)}
                        </p>
                      )}
                      {sale.tax > 0 && (
                        <p style={{ margin: '5px 0' }}><strong>IVA:</strong> {formatCurrency(sale.tax)}</p>
                      )}
                      <p style={{ margin: '10px 0', fontSize: '20px', fontWeight: 'bold', color: '#0066cc' }}>
                        TOTAL: {formatCurrency(sale.total)}
                      </p>
                    </div>
                  </div>
                ) : (
                  <p style={{ textAlign: 'center', color: '#666' }}>
                    No se encontraron los detalles de la venta
                  </p>
                )}
              </div>
            </div>
          </div>
        )
      })()}
    </div>
  )
}
