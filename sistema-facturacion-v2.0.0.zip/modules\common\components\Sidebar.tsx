import React from 'react'

interface SidebarProps {
  activeModule: string
  onModuleChange?: (module: string) => void
  isDarkMode?: boolean
  toggleTheme?: () => void
  userName?: string
  userPhoto?: string
  isOpen?: boolean
  onClose?: () => void
  onLogout?: () => void
}

export default function Sidebar({ 
  activeModule, 
  onModuleChange,
  isDarkMode, 
  toggleTheme,
  userName,
  userPhoto,
  isOpen = false,
  onClose,
  onLogout
}: SidebarProps) {
  const modules = [
    { id: 'dashboard', icon: '🏠', label: 'Inicio' },
    { id: 'sales', icon: '💰', label: 'Punto de Venta' },
    { id: 'quotes', icon: '📋', label: 'Cotización' },
    { id: 'clients', icon: '👥', label: 'Clientes' },
    { id: 'products', icon: '📦', label: 'Inventario' },
    { id: 'reports', icon: '📈', label: 'Reportes' },
    { id: 'archives', icon: '📁', label: 'Facturas' },
    { id: 'settings', icon: '⚙️', label: 'Configuración' },
  ]

  const handleModuleClick = (moduleId: string) => {
    onModuleChange?.(moduleId)
    onClose?.()
  }

  return (
    <div className={`sidebar ${isOpen ? 'open' : ''}`} style={{
      width: 'var(--sidebar-width, 220px)',
      minWidth: '220px',
      height: '100vh',
      background: isDarkMode ? '#1a1a2e' : '#f8f9fa',
      borderRight: '1px solid var(--border-color, #e0e0e0)',
      display: 'flex',
      flexDirection: 'column',
      position: 'fixed',
      left: 0,
      top: 0,
      zIndex: 1000
    }}>
      {/* Logo/Title */}
      <div style={{
        padding: '20px',
        borderBottom: '1px solid var(--border-color, #e0e0e0)',
        textAlign: 'center'
      }}>
        <h1 style={{
          fontSize: '18px',
          margin: 0,
          color: isDarkMode ? '#fff' : '#333',
          fontWeight: 'bold'
        }}>
          💻 Facturación Pro
        </h1>
        <p style={{
          fontSize: '12px',
          margin: '5px 0 0 0',
          color: isDarkMode ? '#aaa' : '#666'
        }}>
          Sistema de Gestión
        </p>
      </div>

      {/* User Info */}
      <div style={{
        padding: '15px',
        borderBottom: '1px solid var(--border-color, #e0e0e0)',
        display: 'flex',
        alignItems: 'center',
        gap: '10px'
      }}>
        <div style={{
          width: '40px',
          height: '40px',
          borderRadius: '50%',
          background: 'var(--accent, #0066cc)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: '18px',
          overflow: 'hidden'
        }}>
          {userPhoto ? (
            <img src={userPhoto} alt="Foto" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          ) : (
            // Mostrar iniciales como fallback
            <span style={{ color: 'white', fontWeight: 700 }}>{(userName || 'U').split(' ').map(s => s[0]).slice(0,2).join('').toUpperCase()}</span>
          )}
        </div>
        <div style={{ flex: 1, overflow: 'hidden' }}>
          <p style={{
            margin: 0,
            fontSize: '14px',
            fontWeight: 'bold',
            color: isDarkMode ? '#fff' : '#333',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis'
          }}>
            {userName || 'Usuario'}
          </p>
          <p style={{
            margin: '2px 0 0 0',
            fontSize: '11px',
            color: isDarkMode ? '#aaa' : '#666'
          }}>
            Administrador
          </p>
        </div>
      </div>

      {/* Navigation */}
      <nav style={{
        flex: 1,
        padding: '10px',
        overflowY: 'auto'
      }}>
        <ul style={{
          listStyle: 'none',
          padding: 0,
          margin: 0
        }}>
          {modules.map(module => (
            <li key={module.id} style={{ marginBottom: '5px' }}>
              <button
                onClick={() => handleModuleClick(module.id)}
                style={{
                  width: '100%',
                  padding: '12px 15px',
                  border: 'none',
                  borderRadius: '8px',
                  background: activeModule === module.id 
                    ? 'var(--accent, #0066cc)' 
                    : isDarkMode ? '#2a2a4e' : '#e9ecef',
                  color: activeModule === module.id 
                    ? 'white' 
                    : isDarkMode ? '#fff' : '#333',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  fontSize: '14px',
                  fontWeight: activeModule === module.id ? 'bold' : 'normal',
                  transition: 'all 0.2s ease',
                  textAlign: 'left'
                }}
                onMouseEnter={(e) => {
                  if (activeModule !== module.id) {
                    e.currentTarget.style.background = isDarkMode ? '#3a3a5e' : '#d5d8dc'
                  }
                }}
                onMouseLeave={(e) => {
                  if (activeModule !== module.id) {
                    e.currentTarget.style.background = isDarkMode ? '#2a2a4e' : '#e9ecef'
                  }
                }}
              >
                <span style={{ fontSize: '18px' }}>{module.icon}</span>
                <span>{module.label}</span>
              </button>
            </li>
          ))}
        </ul>
      </nav>

      {/* Theme Toggle + Logout */}
      <div style={{
        padding: '15px',
        borderTop: '1px solid var(--border-color, #e0e0e0)'
      }}>
        {onLogout && (
          <div style={{ marginBottom: 10 }}>
            <button
              onClick={() => {
                try {
                  const ok = window.confirm('¿Seguro que quieres cerrar sesión?')
                  if (ok) onLogout()
                } catch (e) {
                  onLogout()
                }
              }}
              style={{
                width: '100%',
                padding: '10px',
                border: 'none',
                borderRadius: '8px',
                background: '#dc3545',
                color: 'white',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '8px',
                fontSize: '13px',
                fontWeight: 'bold'
              }}
              title="Cerrar sesión"
            >
              🔒 Cerrar sesión
            </button>
          </div>
        )}

        <button
          onClick={toggleTheme}
          style={{
            width: '100%',
            padding: '10px',
            border: 'none',
            borderRadius: '10px',
            background: isDarkMode
              ? 'linear-gradient(90deg,#0f172a,#3b82f6)'
              : 'linear-gradient(90deg,#7c3aed,#06b6d4)',
            color: '#fff',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '8px',
            fontSize: '13px',
            boxShadow: isDarkMode
              ? '0 6px 18px rgba(59,130,246,0.25), inset 0 -4px 12px rgba(0,0,0,0.2)'
              : '0 6px 18px rgba(124,58,237,0.25), inset 0 -4px 12px rgba(0,0,0,0.08)',
            transition: 'transform 0.18s ease, box-shadow 0.18s ease'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'translateY(-2px)';
            e.currentTarget.style.boxShadow = isDarkMode
              ? '0 10px 30px rgba(59,130,246,0.35), inset 0 -6px 16px rgba(0,0,0,0.25)'
              : '0 10px 30px rgba(124,58,237,0.35), inset 0 -6px 16px rgba(0,0,0,0.12)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translateY(0px)';
            e.currentTarget.style.boxShadow = isDarkMode
              ? '0 6px 18px rgba(59,130,246,0.25), inset 0 -4px 12px rgba(0,0,0,0.2)'
              : '0 6px 18px rgba(124,58,237,0.25), inset 0 -4px 12px rgba(0,0,0,0.08)';
          }}
        >
          {isDarkMode ? '☀️ Modo Claro' : '🌙 Modo Oscuro'}
        </button>
      </div>
    </div>
  )
}
