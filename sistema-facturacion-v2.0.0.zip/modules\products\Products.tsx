import React, { useState, useEffect, useRef } from 'react'
import { useProducts } from './useProducts'
import { useSettings } from '../settings/useSettings'
import { Product } from '../common/types'
import { formatNumberWithDots, formatCurrency } from '../common/utils/formatters'
import InputNumero from '../common/components/InputNumero'

// Tipo helper para el formulario
interface ProductFormData {
  name: string
  price: number | string
  stock: number | string
  category: string
  costPrice: number | string
  provider: string
}

interface ProductsProps {
  onNavigateToSales?: () => void
}

export default function Products({ onNavigateToSales }: ProductsProps) {
  const {
    products,
    addProduct,
    updateProduct,
    deleteProduct,
    searchProducts,
    importFromJSON,
    exportToJSON,
    validateProduct,
    criticalStockProducts,
    warningStockProducts,
    getTotalInventoryValue,
    getTotalCostValue,
    getCategories,
    getProviders,
    migrateProductIds,
    updateCategory,
    deleteCategory,
    addCategory,
    updateProvider,
    deleteProvider,
    addProvider,
  } = useProducts()

  const { companyConfig } = useSettings()

  const [searchQuery, setSearchQuery] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [stockSearchQuery, setStockSearchQuery] = useState('')
  const [showStockForm, setShowStockForm] = useState(false)
  const [stockFormData, setStockFormData] = useState<{
    productId: string
    additionalStock: number | string
    unitCost: number | string
    stockDate: string
    stockTime: string
  }>({
    productId: '',
    additionalStock: 0,
    unitCost: 0,
    stockDate: new Date().toISOString().split('T')[0],
    stockTime: new Date().toTimeString().split(' ')[0].substring(0, 5),
  })
  const [formData, setFormData] = useState<{
    name: string
    price: string | number
    stock: string | number
    category: string
    costPrice: string | number
    provider: string
  }>({
    name: '',
    price: '',
    stock: '',
    category: '',
    costPrice: '',
    provider: '',
  })

  // Valores sin formato para cálculos
  const [rawFormData, setRawFormData] = useState({
    price: 0,
    stock: 0,
    costPrice: 0,
  })

  // Refs para manejar el cursor
  const priceInputRef = useRef(null)
  const stockInputRef = useRef(null)
  const costPriceInputRef = useRef(null)
  const [errors, setErrors] = useState<string[]>([])
  const [selectedProductIds, setSelectedProductIds] = useState<Set<string>>(new Set())
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [newCategoryName, setNewCategoryName] = useState('')
  const [showCategoryManager, setShowCategoryManager] = useState(false)
  const [editingProvider, setEditingProvider] = useState<string | null>(null)
  const [newProviderName, setNewProviderName] = useState('')
  const [showProviderManager, setShowProviderManager] = useState(false)
  const [editingCategory, setEditingCategory] = useState<string | null>(null)
  const [showInventoryValues, setShowInventoryValues] = useState(false)
  const [showPasswordModal, setShowPasswordModal] = useState(false)
  const [passwordInput, setPasswordInput] = useState('')
  const [viewMode, setViewMode] = useState<'list' | 'grid' | 'list-no-image'>(() => {
    const saved = localStorage.getItem('products_view_mode')
    return (saved as 'list' | 'grid' | 'list-no-image') || 'list'
  })  // Vista lista, lista sin imagen o cuadrícula
  const [productImage, setProductImage] = useState<string | null>(null)  // Imagen del producto
  const [zoomImage, setZoomImage] = useState<string | null>(null)  // Imagen para zoom modal

  // Guardar viewMode en localStorage cuando cambie
  useEffect(() => {
    localStorage.setItem('products_view_mode', viewMode)
  }, [viewMode])

  const filteredProducts = searchProducts(searchQuery)

  const toggleProductSelection = (productId: string) => {
    const newSelection = new Set(selectedProductIds)
    if (newSelection.has(productId)) {
      newSelection.delete(productId)
    } else {
      newSelection.add(productId)
    }
    setSelectedProductIds(newSelection)
  }

  const handleGoToSales = () => {
    if (selectedProductIds.size === 0) {
      alert('Selecciona al menos un producto')
      return
    }
    localStorage.setItem('pos_selected_products', JSON.stringify(Array.from(selectedProductIds)))
    if (onNavigateToSales) {
      onNavigateToSales()
    }
  }

  const resetForm = () => {
    setFormData({
      name: '',
      price: '',
      stock: '',
      category: '',
      costPrice: '',
      provider: '',
    })
    setEditingProduct(null)
    setErrors([])
    setShowForm(false)
    setProductImage(null)  // Limpiar imagen
  }

  // Función para procesar imagen con fondo transparente (como ícono)
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (event) => {
      const img = new Image()
      img.onload = () => {
        // Crear canvas para procesar la imagen
        const canvas = document.createElement('canvas')
        const ctx = canvas.getContext('2d')
        if (!ctx) return

        // Redimensionar si es muy grande (máximo 800x800 para mejor calidad)
        let width = img.width
        let height = img.height
        const maxSize = 800

        if (width > maxSize || height > maxSize) {
          if (width > height) {
            height = (height / width) * maxSize
            width = maxSize
          } else {
            width = (width / height) * maxSize
            height = maxSize
          }
        }

        canvas.width = width
        canvas.height = height

        // Dibujar imagen con mejor calidad
        ctx.imageSmoothingEnabled = true
        ctx.imageSmoothingQuality = 'high'
        ctx.drawImage(img, 0, 0, width, height)

        // Obtener datos de píxeles
        const imageData = ctx.getImageData(0, 0, width, height)
        const data = imageData.data

        // Remover fondo blanco/claro (hacer transparente)
        for (let i = 0; i < data.length; i += 4) {
          const r = data[i]
          const g = data[i + 1]
          const b = data[i + 2]
          
          // Si el píxel es muy claro (casi blanco), hacerlo transparente
          if (r > 240 && g > 240 && b > 240) {
            data[i + 3] = 0  // Alpha = 0 (transparente)
          }
        }

        // Aplicar cambios
        ctx.putImageData(imageData, 0, 0)

        // Convertir a base64 PNG con máxima calidad
        const base64 = canvas.toDataURL('image/png', 1.0)
        setProductImage(base64)
      }
      img.src = event.target?.result as string
    }
    reader.readAsDataURL(file)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    const { valid, errors: validationErrors } = validateProduct(formData)
    
    if (!valid) {
      setErrors(validationErrors)
      return
    }

    if (editingProduct) {
      updateProduct(editingProduct.id, {
        name: formData.name,
        price: typeof formData.price === 'string' ? parseInt(formData.price.replace(/\D/g, '')) || 0 : formData.price,
        stock: typeof formData.stock === 'string' ? parseInt(formData.stock.replace(/\D/g, '')) || 0 : formData.stock,
        category: formData.category || undefined,
        costPrice: typeof formData.costPrice === 'string' ? parseInt(formData.costPrice.replace(/\D/g, '')) || 0 : formData.costPrice,
        provider: formData.provider || undefined,
        image: productImage || editingProduct.image,  // Mantener imagen existente si no se cambió
      })
    } else {
      addProduct({ ...formData, image: productImage || undefined })
    }
    
    resetForm()
  }

  const handleEdit = (product: Product) => {
    setEditingProduct(product)
    setFormData({
      name: product.name,
      price: product.price,
      stock: product.stock,
      category: product.category || '',
      costPrice: product.costPrice || 0,
      provider: product.provider || '',
    })
    setProductImage(product.image || null)  // Cargar imagen existente
    setShowForm(true)
    setErrors([])
  }

  const handleDelete = (id: string) => {
    if (window.confirm('Estas seguro de eliminar este producto?')) {
      deleteProduct(id)
    }
  }

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string)
        const count = importFromJSON(json)
        alert(`Se importaron ${count} productos`)
      } catch (error) {
        alert('Error al importar: formato JSON invalido')
      }
    }
    reader.readAsText(file)
  }

  const handleExport = () => {
    exportToJSON()
  }

  const formatCurrency = (amount: number) => {
    return `$ ${amount.toLocaleString('es-CO')}`
  }

  const isLightMode = () => document.documentElement.classList.contains('light')

  const getStockStatus = (stock: number) => {
    if (stock === 0) return { color: '#e74c3c', isCritical: true }
    if (stock < 10) return { color: '#e74c3c', isCritical: true }
    if (stock < 20) return { color: '#f39c12', isCritical: false }
    return { color: 'transparent', isCritical: false }
  }

  // Función para abrir el formulario de stock con un producto específico
  const openStockFormForProduct = (product: Product) => {
    setStockFormData({
      productId: product.id,
      additionalStock: 0,
      unitCost: product.costPrice || 0,
      stockDate: new Date().toISOString().split('T')[0],
      stockTime: new Date().toTimeString().split(' ')[0]
    })
    setStockSearchQuery('')
    setShowStockForm(true)
  }

  return (
    <div className="module-body" style={{ overflow: 'visible' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button
            onClick={() => {
              if (onNavigateToSales) {
                onNavigateToSales()
              }
            }}
            style={{
              background: '#27ae60',
              color: 'white',
              border: 'none',
              padding: '10px 20px',
              borderRadius: '8px',
              cursor: 'pointer',
              fontSize: '14px',
              fontWeight: 'bold'
            }}
          >
            ← Volver a Venta
          </button>
          <div style={{ display: 'flex', gap: '6px', position: 'relative' }}>
            <div className="json-dropdown" style={{ position: 'relative' }}>
              <button
                onClick={() => {
                  const dropdown = document.getElementById('jsonDropdown')
                  if (dropdown) {
                    dropdown.style.display = dropdown.style.display === 'none' ? 'block' : 'none'
                  }
                }}
                style={{
                  background: '#3498db',
                  color: 'white',
                  border: 'none',
                  padding: '10px 20px',
                  borderRadius: '8px',
                  cursor: 'pointer',
                  fontSize: '14px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px'
                }}
              >
                📁 JSON
                <span style={{ fontSize: '10px' }}>▼</span>
              </button>
              <div
                id="jsonDropdown"
                style={{
                  display: 'none',
                  position: 'absolute',
                  top: '100%',
                  left: 0,
                  marginTop: '4px',
                  background: 'var(--bg-secondary, #fff)',
                  border: '1px solid var(--border-color, #ddd)',
                  borderRadius: '8px',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
                  zIndex: 100,
                  minWidth: '160px',
                  overflow: 'hidden'
                }}
                onMouseLeave={() => {
                  const dropdown = document.getElementById('jsonDropdown')
                  if (dropdown) dropdown.style.display = 'none'
                }}
              >
                <button
                  onClick={() => {
                    handleExport()
                    const dropdown = document.getElementById('jsonDropdown')
                    if (dropdown) dropdown.style.display = 'none'
                  }}
                  style={{
                    display: 'block',
                    width: '100%',
                    padding: '12px 16px',
                    border: 'none',
                    background: 'transparent',
                    color: 'var(--text-primary, #333)',
                    textAlign: 'left',
                    cursor: 'pointer',
                    fontSize: '14px',
                    borderBottom: '1px solid var(--border-light, #eee)'
                  }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-tertiary, #f0f0f0)'}
                  onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                >
                  📤 Exportar JSON
                </button>
                <label
                  style={{
                    display: 'block',
                    width: '100%',
                    padding: '12px 16px',
                    border: 'none',
                    background: 'transparent',
                    color: 'var(--text-primary, #333)',
                    textAlign: 'left',
                    cursor: 'pointer',
                    fontSize: '14px'
                  }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-tertiary, #f0f0f0)'}
                  onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                >
                  📥 Importar JSON
                  <input
                    type="file"
                    accept=".json"
                    onChange={(e) => {
                      handleImport(e)
                      const dropdown = document.getElementById('jsonDropdown')
                      if (dropdown) dropdown.style.display = 'none'
                    }}
                    style={{ display: 'none' }}
                  />
                </label>
              </div>
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button
            onClick={() => setShowStockForm(true)}
            style={{
              background: '#9b59b6',
              color: 'white',
              border: 'none',
              padding: '10px 20px',
              borderRadius: '8px',
              cursor: 'pointer',
              fontSize: '14px',
              height: '44px',
              display: 'flex',
              alignItems: 'center',
              marginTop: '10px'
            }}
          >
            📦 Cargar Stock
          </button>
          {selectedProductIds.size > 0 && onNavigateToSales && (
            <button
              onClick={handleGoToSales}
              style={{
                background: '#27ae60',
                color: 'white',
                border: 'none',
                padding: '10px 20px',
                borderRadius: '8px',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: 'bold',
                height: '44px',
                display: 'flex',
                alignItems: 'center',
                marginTop: '10px'
              }}
            >
              🛒 Ir a Ventas ({selectedProductIds.size})
            </button>
          )}
          <button 
            onClick={() => setShowForm(true)}
            style={{
              background: 'var(--accent, #0066cc)',
              color: 'white',
              border: 'none',
              padding: '10px 20px',
              borderRadius: '8px',
              cursor: 'pointer',
              fontSize: '14px',
              height: '44px',
              display: 'flex',
              alignItems: 'center',
              marginTop: '10px'
            }}
          >
            + Nuevo Producto
          </button>
          <button 
            onClick={() => {
              if (window.confirm('Esto convertirá todos los IDs de productos al formato PRD-001, PRD-002, etc. ¿Continuar?')) {
                migrateProductIds()
                alert('IDs migrados correctamente')
              }
            }}
            style={{
              background: 'transparent',
              color: '#f59e0b',
              border: 'none',
              padding: '8px 16px',
              borderRadius: '8px',
              cursor: 'pointer',
              fontSize: '32px'
            }}
          >
            🔄
          </button>
        </div>
      </div>

      {/* Stats */}
      <div style={{ display: 'flex', gap: '20px', marginBottom: '20px', flexWrap: 'wrap' }}>
        <div style={{ 
          background: 'var(--card-bg, #fff)', 
          padding: '15px', 
          borderRadius: '8px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          flex: '1 1 200px'
        }}>
          <strong>Total Productos:</strong> {products.length}
        </div>
        <button
          onClick={() => {
            // Filtrar productos con stock crítico
            const criticalIds = criticalStockProducts.map(p => p.id).join('|')
            setSearchQuery(criticalIds)
          }}
          style={{ 
            background: 'var(--card-bg, #fff)', 
            padding: '15px', 
            borderRadius: '8px',
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
            flex: '1 1 200px',
            border: criticalStockProducts.length > 0 ? '2px solid #e74c3c' : '1px solid #ddd',
            cursor: 'pointer',
            textAlign: 'left',
            transition: 'all 0.3s'
          }}
          onMouseEnter={(e) => {
            if (criticalStockProducts.length > 0) {
              e.currentTarget.style.transform = 'scale(1.05)'
              e.currentTarget.style.boxShadow = '0 4px 12px rgba(231, 76, 60, 0.3)'
            }
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'scale(1)'
            e.currentTarget.style.boxShadow = '0 2px 8px rgba(0,0,0,0.1)'
          }}
          title="Click para ver productos con stock crítico"
        >
          <strong>🚨 Stock Crítico:</strong> <span style={{ color: '#e74c3c', fontWeight: 'bold', fontSize: '18px' }}>{criticalStockProducts.length}</span>
        </button>
        <button
          onClick={() => {
            // Si ya está mostrando valores, simplemente ocultar
            if (showInventoryValues) {
              setShowInventoryValues(false)
              return
            }
            // Si hay una clave configurada, mostrar modal
            if (companyConfig?.inventoryPassword) {
              setShowPasswordModal(true)
              setPasswordInput('')
            } else {
              // Si no hay clave, mostrar directamente
              setShowInventoryValues(true)
            }
          }}
          style={{
            background: showInventoryValues ? '#f59e0b' : '#059669',
            color: 'white',
            border: 'none',
            padding: '12px 20px',
            borderRadius: '8px',
            cursor: 'pointer',
            fontSize: '14px',
            fontWeight: 'bold',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}
        >
          {showInventoryValues ? '👁️ Ocultar Valores' : '💰 Ver Valores Inventario'}
        </button>
      </div>

      {/* Valores del Inventario - Ocultos por defecto */}
      {showInventoryValues && (
      <div style={{ display: 'flex', gap: '20px', marginBottom: '20px' }}>
        <div style={{ 
          background: 'var(--card-bg, #fff)', 
          padding: '20px', 
          borderRadius: '8px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          flex: 1,
          border: '2px solid #27ae60'
        }}>
          <strong>Valor Inventario Ventas:</strong><br/>
          <span style={{ color: '#27ae60', fontSize: '22px', fontWeight: 'bold' }}>{formatCurrency(getTotalInventoryValue)}</span>
        </div>
        <div style={{ 
          background: 'var(--card-bg, #fff)', 
          padding: '20px', 
          borderRadius: '8px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          flex: 1,
          border: '2px solid #3498db'
        }}>
          <strong>Valor Inventario Compra:</strong><br/>
          <span style={{ color: '#3498db', fontSize: '22px', fontWeight: 'bold' }}>{formatCurrency(getTotalCostValue)}</span>
        </div>
      </div>
      )}

      {/* Modal de Contraseña para ver valores del inventario */}
      {showPasswordModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.7)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 2000
        }}>
          <div style={{
            background: 'linear-gradient(135deg, #1e3a5f 0%, #2d5a87 100%)',
            padding: '40px',
            borderRadius: '16px',
            width: '380px',
            maxWidth: '90%',
            boxShadow: '0 10px 40px rgba(0,0,0,0.3)',
            textAlign: 'center'
          }}>
            <div style={{ 
              width: '60px', 
              height: '60px', 
              background: 'rgba(255,255,255,0.2)', 
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 20px'
            }}>
              <span style={{ fontSize: '28px' }}>🔐</span>
            </div>
            <h3 style={{ 
              margin: '0 0 10px 0', 
              color: 'white',
              fontSize: '22px'
            }}>
              Ingresa tu Contraseña
            </h3>
            <p style={{ 
              margin: '0 0 25px 0', 
              color: 'rgba(255,255,255,0.8)',
              fontSize: '14px'
            }}>
              Para ver los valores del inventario
            </p>
            <input
              type="password"
              value={passwordInput}
              onChange={e => setPasswordInput(e.target.value)}
              onKeyPress={e => {
                if (e.key === 'Enter') {
                  if (passwordInput === companyConfig?.inventoryPassword) {
                    setShowPasswordModal(false)
                    setShowInventoryValues(true)
                    setPasswordInput('')
                  } else {
                    alert('Contraseña incorrecta')
                    setPasswordInput('')
                  }
                }
              }}
              placeholder="••••••••"
              autoFocus
              style={{
                width: '100%',
                padding: '14px 18px',
                borderRadius: '10px',
                border: '2px solid rgba(255,255,255,0.3)',
                background: 'rgba(255,255,255,0.95)',
                fontSize: '18px',
                letterSpacing: '8px',
                textAlign: 'center',
                marginBottom: '20px',
                outline: 'none',
                fontWeight: 'bold',
                color: '#1e3a5f'
              }}
            />
            <div style={{ display: 'flex', gap: '12px' }}>
              <button
                onClick={() => {
                  setShowPasswordModal(false)
                  setPasswordInput('')
                }}
                style={{
                  flex: 1,
                  padding: '12px 20px',
                  borderRadius: '10px',
                  border: '2px solid rgba(255,255,255,0.5)',
                  background: 'transparent',
                  color: 'white',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: 'bold'
                }}
              >
                Cancelar
              </button>
              <button
                onClick={() => {
                  if (passwordInput === companyConfig?.inventoryPassword) {
                    setShowPasswordModal(false)
                    setShowInventoryValues(true)
                    setPasswordInput('')
                  } else {
                    alert('Contraseña incorrecta')
                    setPasswordInput('')
                  }
                }}
                style={{
                  flex: 1,
                  padding: '12px 20px',
                  borderRadius: '10px',
                  border: 'none',
                  background: '#10b981',
                  color: 'white',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: 'bold'
                }}
              >
                ✓ Confirmar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Form Modal */}
      {showForm && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{
            background: 'var(--card-bg, #fff)',
            padding: '30px',
            borderRadius: '12px',
            width: '600px',
            maxWidth: '95%'
          }}>
            <h3 style={{ marginTop: 0 }}>
              {editingProduct ? 'Editar Producto' : 'Nuevo Producto'}
            </h3>
            
            {errors.length > 0 && (
              <ul style={{ color: '#e74c3c', paddingLeft: '20px' }}>
                {errors.map((error, i) => (
                  <li key={i}>{error}</li>
                ))}
              </ul>
            )}

            <form onSubmit={handleSubmit}>
              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                  Nombre *
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #ddd' }}
                  required
                />
              </div>

              {/* Campo de Imagen */}
              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                  📷 Imagen del Producto
                </label>
                <div style={{ display: 'flex', gap: '15px', alignItems: 'center' }}>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    style={{ flex: 1, padding: '10px', borderRadius: '6px', border: '1px solid #ddd' }}
                  />
                  {productImage && (
                    <div style={{ position: 'relative' }}>
                      <img 
                        src={productImage} 
                        alt="Preview" 
                        style={{ 
                          width: '80px', 
                          height: '80px', 
                          objectFit: 'contain', 
                          border: '2px solid #ddd', 
                          borderRadius: '8px'
                        }} 
                      />
                      <button
                        type="button"
                        onClick={() => setProductImage(null)}
                        style={{
                          position: 'absolute',
                          top: '-8px',
                          right: '-8px',
                          background: '#dc2626',
                          color: 'white',
                          border: 'none',
                          borderRadius: '50%',
                          width: '24px',
                          height: '24px',
                          cursor: 'pointer',
                          fontSize: '12px',
                          fontWeight: 'bold'
                        }}
                      >
                        ✕
                      </button>
                    </div>
                  )}
                </div>
                <small style={{ color: '#666', fontSize: '11px' }}>
                  La imagen se ajustará automáticamente y el fondo blanco será transparente
                </small>
              </div>

              <div style={{ display: 'flex', gap: '15px' }}>
                <div style={{ marginBottom: '15px', flex: 1 }}>
                  <InputNumero
                    label="Precio Costo *"
                    value={formData.costPrice}
                    onChange={(value) => setFormData({ ...formData, costPrice: value })}
                    required
                    style={{ width: '100%' }}
                  />
                </div>
                <div style={{ marginBottom: '15px', flex: 1 }}>
                  <InputNumero
                    label="Precio de Venta *"
                    value={formData.price}
                    onChange={(value) => setFormData({ ...formData, price: value })}
                    required
                    style={{ width: '100%' }}
                  />
                </div>
                <div style={{ marginBottom: '15px', flex: 1 }}>
                  <InputNumero
                    label="Stock *"
                    value={formData.stock}
                    onChange={(value) => setFormData({ ...formData, stock: value })}
                    required
                    style={{ width: '100%' }}
                  />
                </div>
              </div>

              <div style={{ display: 'flex', gap: '15px' }}>
                <div style={{ marginBottom: '15px', flex: 1 }}>
                  <label style={{ display: 'block', marginBottom: '5px' }}>Categoria</label>
                  <select
                    value={formData.category}
                    onChange={e => setFormData({ ...formData, category: e.target.value })}
                    style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #ddd' }}
                  >
                    <option value="">-- Seleccionar Categoria --</option>
                    {getCategories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                    <option value="__new__">+ Nueva Categoria...</option>
                  </select>
                  {formData.category === '__new__' && (
                    <div style={{ marginTop: '10px' }}>
                      <input
                        type="text"
                        placeholder="Escribe el nombre de la nueva categoria"
                        value={newCategoryName}
                        onChange={e => setNewCategoryName(e.target.value)}
                        style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #ddd' }}
                        autoFocus
                      />
                      <div style={{ display: 'flex', gap: '5px', marginTop: '8px' }}>
                        <button
                          type="button"
                          onClick={() => {
                            if (newCategoryName.trim()) {
                              addCategory(newCategoryName.trim())
                              setFormData({ ...formData, category: newCategoryName.trim() })
                              setNewCategoryName('')
                            }
                          }}
                          style={{ flex: 1, padding: '8px', borderRadius: '6px', border: 'none', background: '#27ae60', color: 'white', cursor: 'pointer', fontSize: '12px' }}
                        >
                          ✓ Crear
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setFormData({ ...formData, category: '' })
                            setNewCategoryName('')
                          }}
                          style={{ flex: 1, padding: '8px', borderRadius: '6px', border: 'none', background: '#dc2626', color: 'white', cursor: 'pointer', fontSize: '12px', fontWeight: 'bold' }}
                        >
                          ✕ Cancelar
                        </button>
                      </div>
                    </div>
                  )}
                  {/* Botón para mostrar gestor de categorías */}
                  {getCategories.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setShowCategoryManager(!showCategoryManager)}
                      style={{
                        marginTop: '10px',
                        padding: '8px 15px',
                        borderRadius: '6px',
                        border: '1px solid #ddd',
                        background: showCategoryManager ? '#dc2626' : '#3498db',
                        color: 'white',
                        cursor: 'pointer',
                        fontSize: '12px',
                        fontWeight: 'bold',
                        width: '100%'
                      }}
                    >
                      {showCategoryManager ? '✕ Cerrar Gestión' : '⚙️ Gestionar Categorías'}
                    </button>
                  )}

                  {/* Lista de categorías con opciones de editar/eliminar - solo visible cuando showCategoryManager es true */}
                  {showCategoryManager && getCategories.length > 0 && (
                    <div style={{ marginTop: '15px', padding: '10px', background: '#f8f9fa', borderRadius: '6px' }}>
                      <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold', fontSize: '12px' }}>Gestionar Categorías:</label>
                      {getCategories.map(cat => (
                        <div key={cat} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '5px' }}>
                          {editingCategory === cat ? (
                            <div style={{ display: 'flex', gap: '5px', flex: 1 }}>
                              <input
                                type="text"
                                value={newCategoryName}
                                onChange={e => setNewCategoryName(e.target.value)}
                                style={{ flex: 1, padding: '5px', borderRadius: '4px', border: '1px solid #ddd', fontSize: '12px' }}
                                autoFocus
                              />
                              <button
                                onClick={() => {
                                  if (newCategoryName.trim() && newCategoryName !== cat) {
                                    updateCategory(cat, newCategoryName)
                                    if (formData.category === cat) {
                                      setFormData({ ...formData, category: newCategoryName })
                                    }
                                  }
                                  setEditingCategory(null)
                                  setNewCategoryName('')
                                }}
                                style={{ padding: '5px 8px', borderRadius: '4px', border: 'none', background: '#27ae60', color: 'white', cursor: 'pointer', fontSize: '11px' }}
                              >
                                ✓
                              </button>
                              <button
                                onClick={() => {
                                  setEditingCategory(null)
                                  setNewCategoryName('')
                                }}
                                style={{ padding: '5px 8px', borderRadius: '4px', border: 'none', background: '#95a5a6', color: 'white', cursor: 'pointer', fontSize: '11px' }}
                              >
                                ✕
                              </button>
                            </div>
                          ) : (
                            <>
                              <span
                                style={{ fontSize: '13px', cursor: 'pointer', flex: 1, padding: '4px' }}
                                onDoubleClick={() => {
                                  setEditingCategory(cat)
                                  setNewCategoryName(cat)
                                }}
                                title="Doble clic para editar"
                              >
                                {cat}
                              </span>
                              <div style={{ display: 'flex', gap: '3px' }}>
                                <button
                                  onClick={() => {
                                    setEditingCategory(cat)
                                    setNewCategoryName(cat)
                                  }}
                                  style={{ padding: '4px 8px', borderRadius: '4px', border: 'none', background: '#3498db', color: 'white', cursor: 'pointer', fontSize: '11px' }}
                                  title="Editar"
                                >
                                  ✏️
                                </button>
                                <button
                                  onClick={() => {
                                    if (confirm(`¿Eliminar la categoría "${cat}"? Los productos quedarán sin categoría.`)) {
                                      deleteCategory(cat)
                                      if (formData.category === cat) {
                                        setFormData({ ...formData, category: '' })
                                      }
                                    }
                                  }}
                                  style={{ padding: '4px 8px', borderRadius: '4px', border: 'none', background: '#dc2626', color: 'white', cursor: 'pointer', fontSize: '11px', fontWeight: 'bold' }}
                                  title="Eliminar"
                                >
                                  🗑️
                                </button>
                              </div>
                            </>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', marginBottom: '5px' }}>Proveedor</label>
                <select
                  value={formData.provider}
                  onChange={e => setFormData({ ...formData, provider: e.target.value })}
                  style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #ddd' }}
                >
                  <option value="">-- Seleccionar Proveedor --</option>
                  {getProviders.map(provider => (
                    <option key={provider} value={provider}>{provider}</option>
                  ))}
                  <option value="__new__">+ Nuevo Proveedor...</option>
              </select>
              {formData.provider === '__new__' && (
                <div style={{ marginTop: '10px' }}>
                  <input
                    type="text"
                    placeholder="Escribe el nombre del nuevo proveedor"
                    value={newProviderName}
                    onChange={e => setNewProviderName(e.target.value)}
                    style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #ddd' }}
                    autoFocus
                  />
                  <div style={{ display: 'flex', gap: '5px', marginTop: '8px' }}>
                    <button
                      type="button"
                      onClick={() => {
                        if (newProviderName.trim()) {
                          addProvider(newProviderName.trim())
                          setFormData({ ...formData, provider: newProviderName.trim() })
                          setNewProviderName('')
                        }
                      }}
                      style={{ flex: 1, padding: '8px', borderRadius: '6px', border: 'none', background: '#27ae60', color: 'white', cursor: 'pointer', fontSize: '12px' }}
                    >
                      ✓ Crear
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setFormData({ ...formData, provider: '' })
                        setNewProviderName('')
                      }}
                      style={{ flex: 1, padding: '8px', borderRadius: '6px', border: 'none', background: '#dc2626', color: 'white', cursor: 'pointer', fontSize: '12px', fontWeight: 'bold' }}
                    >
                      ✕ Cancelar
                    </button>
                  </div>
                </div>
              )}
                {/* Botón para mostrar gestor de proveedores */}
                {getProviders.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setShowProviderManager(!showProviderManager)}
                    style={{
                      marginTop: '10px',
                      padding: '8px 15px',
                      borderRadius: '6px',
                      border: '1px solid #ddd',
                      background: showProviderManager ? '#dc2626' : '#9b59b6',
                      color: 'white',
                      cursor: 'pointer',
                      fontSize: '12px',
                      fontWeight: 'bold',
                      width: '100%'
                    }}
                  >
                    {showProviderManager ? '✕ Cerrar Gestión' : '⚙️ Gestionar Proveedores'}
                  </button>
                )}

                {/* Lista de proveedores con opciones de editar/eliminar - solo visible cuando showProviderManager es true */}
                {showProviderManager && getProviders.length > 0 && (
                  <div style={{ marginTop: '15px', padding: '10px', background: '#f8f9fa', borderRadius: '6px' }}>
                    <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold', fontSize: '12px' }}>Gestionar Proveedores:</label>
                    {getProviders.map(prov => (
                      <div key={prov} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '5px' }}>
                        {editingProvider === prov ? (
                          <div style={{ display: 'flex', gap: '5px', flex: 1 }}>
                            <input
                              type="text"
                              value={newProviderName}
                              onChange={e => setNewProviderName(e.target.value)}
                              style={{ flex: 1, padding: '5px', borderRadius: '4px', border: '1px solid #ddd', fontSize: '12px' }}
                              autoFocus
                            />
                            <button
                              onClick={() => {
                                if (newProviderName.trim() && newProviderName !== prov) {
                                  updateProvider(prov, newProviderName)
                                  if (formData.provider === prov) {
                                    setFormData({ ...formData, provider: newProviderName })
                                  }
                                }
                                setEditingProvider(null)
                                setNewProviderName('')
                              }}
                              style={{ padding: '5px 8px', borderRadius: '4px', border: 'none', background: '#27ae60', color: 'white', cursor: 'pointer', fontSize: '11px' }}
                            >
                              ✓
                            </button>
                            <button
                              onClick={() => {
                                setEditingProvider(null)
                                setNewProviderName('')
                              }}
                              style={{ padding: '5px 8px', borderRadius: '4px', border: 'none', background: '#95a5a6', color: 'white', cursor: 'pointer', fontSize: '11px' }}
                            >
                              ✕
                            </button>
                          </div>
                        ) : (
                          <>
                            <span
                              style={{ fontSize: '13px', cursor: 'pointer', flex: 1, padding: '4px' }}
                              onDoubleClick={() => {
                                setEditingProvider(prov)
                                setNewProviderName(prov)
                              }}
                              title="Doble clic para editar"
                            >
                              {prov}
                            </span>
                            <div style={{ display: 'flex', gap: '3px' }}>
                              <button
                                onClick={() => {
                                  setEditingProvider(prov)
                                  setNewProviderName(prov)
                                }}
                                style={{ padding: '4px 8px', borderRadius: '4px', border: 'none', background: '#3498db', color: 'white', cursor: 'pointer', fontSize: '11px' }}
                                title="Editar"
                              >
                                ✏️
                              </button>
                              <button
                                onClick={() => {
                                  if (confirm(`¿Eliminar el proveedor "${prov}"? Los productos quedarán sin proveedor.`)) {
                                    deleteProvider(prov)
                                    if (formData.provider === prov) {
                                      setFormData({ ...formData, provider: '' })
                                    }
                                  }
                                }}
                                style={{ padding: '4px 8px', borderRadius: '4px', border: 'none', background: '#dc2626', color: 'white', cursor: 'pointer', fontSize: '11px', fontWeight: 'bold' }}
                                title="Eliminar"
                              >
                                🗑️
                              </button>
                            </div>
                          </>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end' }}>
                <button
                  type="button"
                  onClick={resetForm}
                  style={{
                    padding: '10px 20px',
                    borderRadius: '6px',
                    border: 'none',
                    background: '#dc2626',
                    color: 'white',
                    fontWeight: 'bold',
                    cursor: 'pointer'
                  }}
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  style={{
                    padding: '10px 20px',
                    borderRadius: '6px',
                    border: 'none',
                    background: 'var(--accent, #0066cc)',
                    color: 'white',
                    cursor: 'pointer'
                  }}
                >
                  {editingProduct ? 'Actualizar' : 'Crear'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal de Cargar Stock */}
      {showStockForm && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{
            background: 'var(--card-bg, #fff)',
            padding: '30px',
            borderRadius: '12px',
            width: '90%',
            maxWidth: '500px',
            maxHeight: '90vh',
            overflow: 'auto'
          }}>
            <h3 style={{ marginBottom: '20px' }}>📦 Cargar Nuevo Stock</h3>
            
            {/* Campo de búsqueda */}
            <div style={{ marginBottom: '15px' }}>
              <input
                type="text"
                placeholder="Buscar producto por nombre, categoría o ID..."
                value={stockSearchQuery}
                onChange={e => setStockSearchQuery(e.target.value)}
                autoFocus
                style={{
                  width: '100%',
                  padding: '12px',
                  borderRadius: '8px',
                  border: '1px solid var(--border-color)',
                  fontSize: '14px',
                  marginBottom: '10px',
                  background: 'var(--bg-secondary)',
                  color: 'var(--text-primary)'
                }}
              />
              
              {/* Lista de productos que aparece mientras escribes */}
              {stockSearchQuery.trim() && (
                <div style={{
                  maxHeight: '250px',
                  overflow: 'auto',
                  border: '1px solid var(--border-color)',
                  borderRadius: '8px',
                  background: 'var(--bg-secondary)',
                  boxShadow: 'var(--shadow-lg)'
                }}>
                  {products.filter(p =>
                    p.name.toLowerCase().includes(stockSearchQuery.toLowerCase()) ||
                    p.category?.toLowerCase().includes(stockSearchQuery.toLowerCase()) ||
                    p.id.toLowerCase().includes(stockSearchQuery.toLowerCase())
                  ).slice(0, 10).map(product => (
                    <div
                      key={product.id}
                      onClick={() => {
                        setStockFormData({
                          ...stockFormData,
                          productId: product.id,
                          unitCost: product.costPrice || 0,
                          stockDate: new Date().toISOString().split('T')[0],
                          stockTime: new Date().toTimeString().split(' ')[0].substring(0, 5),
                        })
                        setStockSearchQuery('')
                      }}
                      style={{
                        padding: '12px',
                        borderBottom: '1px solid var(--border-light)',
                        cursor: 'pointer',
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        transition: 'background 0.2s',
                        background: 'var(--bg-secondary)'
                      }}
                      onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-tertiary)'}
                      onMouseLeave={e => e.currentTarget.style.background = 'var(--bg-secondary)'}
                    >
                      <div>
                        <div style={{ fontWeight: 'bold', color: 'var(--text-primary)' }}>{product.name}</div>
                        <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
                          {product.id} | {product.category || 'Sin categoría'}
                        </div>
                      </div>
                      <div style={{ textAlign: 'right' }}>
                        <div style={{ fontWeight: 'bold', color: 'var(--success)' }}>{product.stock} unidades</div>
                        <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
                          ${product.price?.toLocaleString('es-CO')}
                        </div>
                      </div>
                    </div>
                  ))}
                  {products.filter(p =>
                    p.name.toLowerCase().includes(stockSearchQuery.toLowerCase()) ||
                    p.category?.toLowerCase().includes(stockSearchQuery.toLowerCase()) ||
                    p.id.toLowerCase().includes(stockSearchQuery.toLowerCase())
                  ).length === 0 && (
                    <div style={{ padding: '20px', textAlign: 'center', color: 'var(--text-secondary)' }}>
                      No se encontraron productos
                    </div>
                  )}
                </div>
              )}
            </div>
            
            {stockFormData.productId ? (
              <>
                {/* Producto seleccionado */}
                <div style={{ 
                  marginBottom: '20px', 
                  padding: '15px', 
                  background: 'var(--bg-tertiary)', 
                  borderRadius: '8px', 
                  border: '2px solid var(--primary)',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}>
                  <div>
                    <strong style={{ fontSize: '16px', color: 'var(--text-primary)' }}>
                      {products.find(p => p.id === stockFormData.productId)?.name}
                    </strong>
                    <div style={{ fontSize: '12px', color: 'var(--text-secondary)', marginTop: '4px' }}>
                      Stock actual: <strong style={{ color: 'var(--success)' }}>{products.find(p => p.id === stockFormData.productId)?.stock}</strong> unidades
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setStockFormData({ ...stockFormData, productId: '', stockDate: new Date().toISOString().split('T')[0], stockTime: new Date().toTimeString().split(' ')[0].substring(0, 5) })}
                    style={{
                      padding: '8px 16px',
                      borderRadius: '6px',
                      border: 'none',
                      background: 'var(--danger)',
                      color: 'white',
                      cursor: 'pointer'
                    }}
                  >
                    Cambiar
                  </button>
                </div>

                <div style={{ display: 'flex', gap: '15px' }}>
                  <div style={{ marginBottom: '15px', flex: 1 }}>
                    <InputNumero
                      label="Cantidad a Agregar *"
                      value={stockFormData.additionalStock || 0}
                      onChange={(value) => setStockFormData({ ...stockFormData, additionalStock: value })}
                      required
                    />
                  </div>
                  <div style={{ marginBottom: '15px', flex: 1 }}>
                    <InputNumero
                      label="Costo Unitario *"
                      value={stockFormData.unitCost || 0}
                      onChange={(value) => setStockFormData({ ...stockFormData, unitCost: value })}
                      required
                    />
                  </div>
                </div>

                <div style={{ display: 'flex', gap: '15px' }}>
                  <div style={{ marginBottom: '15px', flex: 1 }}>
                    <label style={{ display: 'block', marginBottom: '5px', fontSize: '12px', fontWeight: 'bold' }}>Fecha de Stock *</label>
                    <input
                      type="date"
                      value={stockFormData.stockDate}
                      onChange={e => setStockFormData({ ...stockFormData, stockDate: e.target.value })}
                      style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #ddd' }}
                      required
                    />
                  </div>
                  <div style={{ marginBottom: '15px', flex: 1 }}>
                    <label style={{ display: 'block', marginBottom: '5px', fontSize: '12px', fontWeight: 'bold' }}>Hora de Stock *</label>
                    <input
                      type="time"
                      value={stockFormData.stockTime}
                      onChange={e => setStockFormData({ ...stockFormData, stockTime: e.target.value })}
                      style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #ddd' }}
                      required
                    />
                  </div>
                </div>

                {/* Calculadora */}
                <div style={{
                  marginBottom: '20px',
                  padding: '15px',
                  background: 'var(--primary)',
                  borderRadius: '10px',
                  color: 'white'
                }}>
                  <label style={{ display: 'block', marginBottom: '10px', fontWeight: 'bold', fontSize: '14px' }}>
                    🧮 Resumen de Inversión
                  </label>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                    <div>
                      <label style={{ fontSize: '11px', opacity: 0.9 }}>Inversión Total:</label>
                      <div style={{ fontSize: '18px', fontWeight: 'bold' }}>
                        {formatCurrency(
                          (typeof stockFormData.additionalStock === 'string' 
                            ? parseInt(stockFormData.additionalStock.replace(/\D/g, '')) || 0 
                            : stockFormData.additionalStock) *
                          (typeof stockFormData.unitCost === 'string' 
                            ? parseInt(stockFormData.unitCost.replace(/\D/g, '')) || 0 
                            : stockFormData.unitCost)
                        )}
                      </div>
                    </div>
                    <div>
                      <label style={{ fontSize: '11px', opacity: 0.9 }}>Nuevo Stock Total:</label>
                      <div style={{ fontSize: '18px', fontWeight: 'bold' }}>
                        {(products.find(p => p.id === stockFormData.productId)?.stock || 0) + 
                          (typeof stockFormData.additionalStock === 'string' 
                            ? parseInt(stockFormData.additionalStock.replace(/\D/g, '')) || 0 
                            : stockFormData.additionalStock)} unidades
                      </div>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div style={{ marginBottom: '20px', padding: '30px', background: 'var(--bg-tertiary)', borderRadius: '8px', textAlign: 'center', color: 'var(--text-secondary)' }}>
                🔍 Escribe arriba para buscar y seleccionar un producto
              </div>
            )}

            <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end' }}>
              <button
                type="button"
                onClick={() => {
                  setShowStockForm(false)
                  setStockFormData({ productId: '', additionalStock: 0, unitCost: 0, stockDate: new Date().toISOString().split('T')[0], stockTime: new Date().toTimeString().split(' ')[0].substring(0, 5) })
                  setStockSearchQuery('')
                }}
                style={{
                  padding: '10px 20px',
                  borderRadius: '6px',
                  border: 'none',
                  background: '#dc2626',
                  color: 'white',
                  fontWeight: 'bold',
                  cursor: 'pointer'
                }}
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  const additionalStockNum = typeof stockFormData.additionalStock === 'string' 
                    ? parseInt(stockFormData.additionalStock.replace(/\D/g, '')) || 0 
                    : stockFormData.additionalStock
                  const unitCostNum = typeof stockFormData.unitCost === 'string'
                    ? parseInt(stockFormData.unitCost.replace(/\D/g, '')) || 0
                    : stockFormData.unitCost
                  
                  if (!stockFormData.productId || additionalStockNum <= 0) {
                    alert('Selecciona un producto y cantidad válida')
                    return
                  }
                  const product = products.find(p => p.id === stockFormData.productId)
                  if (product) {
                    const newStock = product.stock + additionalStockNum
                    updateProduct(product.id, {
                      stock: newStock,
                      costPrice: unitCostNum || product.costPrice
                    })
                    alert(`✅ Stock actualizado: ${product.name}\nNuevo stock: ${newStock} unidades\nFecha: ${stockFormData.stockDate} ${stockFormData.stockTime}`)
                    setShowStockForm(false)
                    setStockFormData({ productId: '', additionalStock: 0, unitCost: 0, stockDate: new Date().toISOString().split('T')[0], stockTime: new Date().toTimeString().split(' ')[0].substring(0, 5) })
                  }
                }}
                style={{
                  padding: '10px 20px',
                  borderRadius: '6px',
                  border: 'none',
                  background: '#27ae60',
                  color: 'white',
                  cursor: 'pointer'
                }}
              >
                💾 Guardar Stock
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Search y Vista */}
      <div style={{ marginBottom: '20px', display: 'flex', gap: '10px', alignItems: 'center' }}>
        <input
          type="text"
          placeholder="Buscar por nombre, categoria o proveedor..."
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          style={{
            flex: 1,
            padding: '12px',
            borderRadius: '8px',
            border: '1px solid #ddd',
            fontSize: '14px'
          }}
        />
        <div style={{ position: 'relative' }}>
          <button 
            onClick={() => {
              const dropdown = document.getElementById('viewModeDropdown')
              if (dropdown) {
                dropdown.style.display = dropdown.style.display === 'none' ? 'block' : 'none'
              }
            }}
            style={{
              background: '#3498db',
              color: 'white',
              border: 'none',
              padding: '12px 20px',
              borderRadius: '8px',
              cursor: 'pointer',
              fontSize: '14px',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              whiteSpace: 'nowrap',
              fontWeight: 'bold'
            }}
          >
            {viewMode === 'list' ? '📋 Lista' : viewMode === 'list-no-image' ? '📄 Lista sin imagen' : '🔲 Cuadrícula'}
            <span style={{ fontSize: '10px' }}>▼</span>
          </button>
          <div
            id="viewModeDropdown"
            style={{
              display: 'none',
              position: 'absolute',
              top: '100%',
              right: 0,
              marginTop: '4px',
              background: 'var(--bg-secondary, #fff)',
              border: '1px solid var(--border-color, #ddd)',
              borderRadius: '8px',
              boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
              zIndex: 100,
              minWidth: '200px',
              overflow: 'hidden'
            }}
            onMouseLeave={() => {
              const dropdown = document.getElementById('viewModeDropdown')
              if (dropdown) dropdown.style.display = 'none'
            }}
          >
            <button
              onClick={() => {
                setViewMode('list')
                const dropdown = document.getElementById('viewModeDropdown')
                if (dropdown) dropdown.style.display = 'none'
              }}
              style={{
                display: 'block',
                width: '100%',
                padding: '12px 16px',
                border: 'none',
                background: viewMode === 'list' ? 'var(--bg-tertiary, #f0f0f0)' : 'transparent',
                color: 'var(--text-primary, #333)',
                textAlign: 'left',
                cursor: 'pointer',
                fontSize: '14px',
                borderBottom: '1px solid var(--border-light, #eee)',
                fontWeight: viewMode === 'list' ? 'bold' : 'normal'
              }}
              onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-tertiary, #f0f0f0)'}
              onMouseLeave={e => e.currentTarget.style.background = viewMode === 'list' ? 'var(--bg-tertiary, #f0f0f0)' : 'transparent'}
            >
              📋 Lista con imagen
            </button>
            <button
              onClick={() => {
                setViewMode('list-no-image')
                const dropdown = document.getElementById('viewModeDropdown')
                if (dropdown) dropdown.style.display = 'none'
              }}
              style={{
                display: 'block',
                width: '100%',
                padding: '12px 16px',
                border: 'none',
                background: viewMode === 'list-no-image' ? 'var(--bg-tertiary, #f0f0f0)' : 'transparent',
                color: 'var(--text-primary, #333)',
                textAlign: 'left',
                cursor: 'pointer',
                fontSize: '14px',
                borderBottom: '1px solid var(--border-light, #eee)',
                fontWeight: viewMode === 'list-no-image' ? 'bold' : 'normal'
              }}
              onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-tertiary, #f0f0f0)'}
              onMouseLeave={e => e.currentTarget.style.background = viewMode === 'list-no-image' ? 'var(--bg-tertiary, #f0f0f0)' : 'transparent'}
            >
              📄 Lista sin imagen
            </button>
            <button
              onClick={() => {
                setViewMode('grid')
                const dropdown = document.getElementById('viewModeDropdown')
                if (dropdown) dropdown.style.display = 'none'
              }}
              style={{
                display: 'block',
                width: '100%',
                padding: '12px 16px',
                border: 'none',
                background: viewMode === 'grid' ? 'var(--bg-tertiary, #f0f0f0)' : 'transparent',
                color: 'var(--text-primary, #333)',
                textAlign: 'left',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: viewMode === 'grid' ? 'bold' : 'normal'
              }}
              onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-tertiary, #f0f0f0)'}
              onMouseLeave={e => e.currentTarget.style.background = viewMode === 'grid' ? 'var(--bg-tertiary, #f0f0f0)' : 'transparent'}
            >
              🔲 Cuadrícula
            </button>
          </div>
        </div>
      </div>

      {/* Vista de Lista o Cuadrícula */}
      {viewMode === 'list' || viewMode === 'list-no-image' ? (
        /* Vista de Lista (Tabla) */
        <div className="table-container" style={{
          background: 'var(--card-bg, #fff)',
          borderRadius: '12px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          overflow: 'visible'
        }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--accent, #0066cc)', color: 'white' }}>
                {viewMode === 'list' && <th style={{ padding: '12px', textAlign: 'left' }}>Imagen</th>}
                <th style={{ padding: '12px', textAlign: 'left' }}>ID</th>
                <th style={{ padding: '12px', textAlign: 'left' }}>Nombre</th>
                <th style={{ padding: '12px', textAlign: 'left' }}>Categoria</th>
                <th style={{ padding: '12px', textAlign: 'right' }}>P/Compra</th>
                <th style={{ padding: '12px', textAlign: 'right' }}>P/Venta</th>
                <th style={{ padding: '12px', textAlign: 'center' }}>Stock</th>
                <th style={{ padding: '12px', textAlign: 'left' }}>Proveedor</th>
                <th style={{ padding: '12px', textAlign: 'center' }}>Acciones</th>
              </tr>
            </thead>
            <tbody style={{ overflow: 'visible' }}>
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={viewMode === 'list' ? 9 : 8} style={{ padding: '40px', textAlign: 'center', color: '#666' }}>
                    No hay productos registrados
                  </td>
                </tr>
              ) : (
                filteredProducts.map((product: Product) => {
                  const status = getStockStatus(product.stock)
                  const isSelected = selectedProductIds.has(product.id)
                  return (
                    <tr
                      key={product.id}
                      style={{
                        borderBottom: '1px solid #eee',
                        cursor: 'pointer',
                        backgroundColor: isSelected ? 'rgba(135, 206, 250, 0.5)' : 'transparent',
                        position: 'relative'
                      }}
                      onClick={() => toggleProductSelection(product.id)}
                    >
                      {viewMode === 'list' && (
                        <td style={{ padding: '12px', position: 'relative', overflow: 'visible' }}>
                          {product.image ? (
                            <div style={{ position: 'relative', display: 'inline-block' }}>
                              <img 
                                src={product.image} 
                                alt={product.name}
                                className="product-image-hover"
                                style={{ 
                                  width: '50px', 
                                  height: '50px', 
                                  objectFit: 'contain',
                                  cursor: 'pointer'
                                }}
                                onClick={(e) => {
                                  e.stopPropagation()
                                  setZoomImage(product.image || null)
                                }}
                                onMouseEnter={(e) => {
                                  const img = e.currentTarget
                                  img.style.transform = 'scale(4)'
                                  img.style.zIndex = '1000'
                                  img.style.position = 'relative'
                                }}
                                onMouseLeave={(e) => {
                                  const img = e.currentTarget
                                  img.style.transform = 'scale(1)'
                                  img.style.zIndex = '1'
                                  img.style.position = 'static'
                                }}
                              />
                            </div>
                          ) : (
                            <div style={{ 
                              width: '50px', 
                              height: '50px', 
                              background: '#e0e0e0', 
                              borderRadius: '6px',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              fontSize: '20px'
                            }}>
                              📦
                            </div>
                          )}
                        </td>
                      )}
                      <td style={{ padding: '12px', fontWeight: '600', color: 'var(--accent)' }}>
                        {isSelected ? '✅ ' : ''}{product.id}
                      </td>
                      <td style={{ padding: '12px' }}>{product.name}</td>
                      <td style={{ padding: '12px' }}>{product.category || '-'}</td>
                      <td style={{ padding: '12px', textAlign: 'right', color: '#666' }}>
                        {product.costPrice ? formatCurrency(product.costPrice) : '-'}
                      </td>
                      <td style={{ padding: '12px', textAlign: 'right', fontWeight: 'bold' }}>
                        {formatCurrency(product.price)}
                      </td>
                      <td style={{ padding: '12px', textAlign: 'center' }}>
                        <span 
                          style={{ 
                            background: status.color || (product.stock <= 0 ? '#e74c3c' : status.color), 
                            color: status.color === 'transparent' ? (isLightMode() ? '#0066cc' : '#32ff00') : 'white', 
                            padding: '4px 8px', 
                            borderRadius: '4px',
                            fontSize: '16px',
                            fontWeight: 'bold',
                            cursor: status.isCritical ? 'pointer' : 'default',
                            textDecoration: status.isCritical ? 'underline' : 'none'
                          }}
                          onDoubleClick={(e) => {
                            e.stopPropagation()
                            if (status.isCritical) {
                              openStockFormForProduct(product)
                            }
                          }}
                          title={status.isCritical ? 'Doble clic para cargar stock' : ''}
                        >
                          {product.stock <= 0 ? `0 • Producto agotado` : product.stock}
                        </span>
                      </td>
                      <td style={{ padding: '12px' }}>{product.provider || '-'}</td>
                      <td style={{ padding: '12px', textAlign: 'center' }}>
                        <button
                            onClick={(e) => {
                              e.stopPropagation()
                              handleEdit(product)
                            }}
                            style={{
                              padding: '6px 10px',
                              borderRadius: '4px',
                              border: 'none',
                              background: '#3498db',
                              color: 'white',
                              cursor: 'pointer',
                              fontSize: '14px'
                            }}
                            title="Editar"
                          >
                            ✏️
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation()
                              handleDelete(product.id)
                            }}
                            style={{
                              padding: '6px 10px',
                              borderRadius: '4px',
                              border: 'none',
                              background: '#dc2626',
                              color: 'white',
                              fontWeight: 'bold',
                              cursor: 'pointer',
                              fontSize: '14px'
                            }}
                            title="Eliminar"
                          >
                            🗑️
                          </button>
                      </td>
                    </tr>
                  )
                })
              )}
            </tbody>
          </table>
        </div>
      ) : (
        /* Vista de Cuadrícula */
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))',
          gap: '15px',
          padding: '10px'
        }}>
          {filteredProducts.length === 0 ? (
            <div style={{ 
              gridColumn: '1 / -1', 
              padding: '40px', 
              textAlign: 'center', 
              color: '#666',
              background: 'var(--card-bg, #fff)',
              borderRadius: '12px'
            }}>
              No hay productos registrados
            </div>
          ) : (
            filteredProducts.map((product: Product) => {
              const status = getStockStatus(product.stock)
              const isSelected = selectedProductIds.has(product.id)
              return (
                <div
                  key={product.id}
                  onClick={() => toggleProductSelection(product.id)}
                  style={{
                    background: isSelected ? 'rgba(135, 206, 250, 0.3)' : 'var(--card-bg, #fff)',
                    borderRadius: '10px',
                    boxShadow: isSelected ? '0 4px 12px rgba(52, 152, 219, 0.4)' : 'none',
                    padding: '12px',
                    cursor: 'pointer',
                    transition: 'all 0.3s',
                    border: isSelected ? '2px solid #3498db' : 'none',
                    position: 'relative'
                  }}
                >
                  {isSelected && (
                    <div style={{
                      position: 'absolute',
                      top: '8px',
                      right: '8px',
                      background: '#27ae60',
                      color: 'white',
                      borderRadius: '50%',
                      width: '24px',
                      height: '24px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '14px',
                      fontWeight: 'bold',
                      zIndex: 1
                    }}>
                      ✓
                    </div>
                  )}
                  <div style={{ 
                    width: '100%', 
                    height: '120px', 
                    display: 'flex', 
                    alignItems: 'center', 
                    justifyContent: 'center',
                    marginBottom: '10px',
                    overflow: 'visible',
                    position: 'relative'
                  }}>
                    {product.image ? (
                      <>
                        <img 
                          src={product.image} 
                          alt={product.name}
                          style={{ 
                            maxWidth: '100%', 
                            maxHeight: '100%', 
                            objectFit: 'contain',
                            cursor: 'pointer'
                          }}
                          onClick={(e) => {
                            e.stopPropagation()
                            setZoomImage(product.image || null)
                          }}
                          onMouseEnter={(e) => {
                            const img = e.currentTarget
                            img.style.transform = 'scale(2.5)'
                            img.style.zIndex = '1000'
                            img.style.position = 'relative'
                          }}
                          onMouseLeave={(e) => {
                            const img = e.currentTarget
                            img.style.transform = 'scale(1)'
                            img.style.zIndex = '1'
                            img.style.position = 'static'
                          }}
                        />
                      </>
                    ) : (
                      <div style={{ fontSize: '40px' }}>📦</div>
                    )}
                  </div>
                  <div style={{ marginBottom: '6px' }}>
                    <div style={{ fontSize: '10px', color: '#666', marginBottom: '2px' }}>{product.id}</div>
                    <div style={{ 
                      fontSize: '13px', 
                      fontWeight: 'bold', 
                      marginBottom: '2px',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap'
                    }}>
                      {product.name}
                    </div>
                    <div style={{ fontSize: '10px', color: '#666' }}>{product.category || 'Sin categoría'}</div>
                  </div>
                  <div style={{ 
                    display: 'flex', 
                    justifyContent: 'space-between', 
                    alignItems: 'center',
                    marginBottom: '8px',
                    paddingTop: '8px',
                    borderTop: '1px solid #eee'
                  }}>
                    <div>
                      <div style={{ fontSize: '9px', color: '#666' }}>Precio</div>
                      <div style={{ fontSize: '14px', fontWeight: 'bold', color: '#27ae60' }}>
                        {formatCurrency(product.price)}
                      </div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontSize: '9px', color: '#666' }}>Stock</div>
                      <div style={{ 
                        fontSize: '13px', 
                        fontWeight: 'bold',
                        color: status.color === 'transparent' ? '#27ae60' : 'white',
                        background: status.color || (product.stock <= 0 ? '#e74c3c' : 'transparent'),
                        padding: '2px 6px',
                        borderRadius: '4px'
                      }}>
                        {product.stock}
                      </div>
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    <button
                      onClick={(e) => {
                        e.stopPropagation()
                        handleEdit(product)
                      }}
                      style={{
                        flex: 1,
                        padding: '6px',
                        borderRadius: '6px',
                        border: 'none',
                        background: '#3498db',
                        color: 'white',
                        cursor: 'pointer',
                        fontSize: '11px'
                      }}
                    >
                      ✏️
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation()
                        handleDelete(product.id)
                      }}
                      style={{
                        flex: 1,
                        padding: '6px',
                        borderRadius: '6px',
                        border: 'none',
                        background: '#dc2626',
                        color: 'white',
                        fontWeight: 'bold',
                        cursor: 'pointer',
                        fontSize: '11px'
                      }}
                    >
                      🗑️
                    </button>
                  </div>
                </div>
              )
            })
          )}
        </div>
      )}

      {/* Modal de Zoom de Imagen */}
      {zoomImage && (
        <div 
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'rgba(0,0,0,0.9)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 2000,
            padding: '20px'
          }}
          onClick={() => setZoomImage(null)}
        >
          <button
            onClick={() => setZoomImage(null)}
            style={{
              position: 'absolute',
              top: '20px',
              right: '20px',
              background: '#dc2626',
              color: 'white',
              border: 'none',
              borderRadius: '50%',
              width: '50px',
              height: '50px',
              cursor: 'pointer',
              fontSize: '24px',
              fontWeight: 'bold',
              boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
              zIndex: 2001
            }}
          >
            ✕
          </button>
          <img 
            src={zoomImage} 
            alt="Zoom"
            onClick={(e) => e.stopPropagation()}
            style={{ 
              maxWidth: '90%', 
              maxHeight: '90%', 
              objectFit: 'contain',
              borderRadius: '12px',
              boxShadow: '0 8px 32px rgba(0,0,0,0.5)'
            }} 
          />
        </div>
      )}
    </div>
  )
}
