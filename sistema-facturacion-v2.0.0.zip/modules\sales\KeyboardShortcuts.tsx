import React, { useState, useEffect } from 'react'

export default function KeyboardShortcuts() {
  const [isVisible, setIsVisible] = useState(false)
  const [shortcuts, setShortcuts] = useState<Array<{ key: string; description: string }>>([])

  // Cargar atajos personalizados desde localStorage
  useEffect(() => {
    const loadShortcuts = () => {
      const savedShortcuts = localStorage.getItem('pos_keyboard_shortcuts')
      const config = savedShortcuts ? JSON.parse(savedShortcuts) : {
        F1: 'toggle-products',
        F2: 'toggle-clients',
        F3: 'clear-cart',
        F4: 'process-payment',
        F5: 'goto-inventory',
        F6: 'goto-clients'
      }

      // Mapear acciones a descripciones
      const actionLabels: Record<string, string> = {
        'toggle-products': 'Abrir/Cerrar productos',
        'toggle-clients': 'Abrir/Cerrar clientes',
        'clear-cart': 'Limpiar carrito',
        'process-payment': 'Procesar pago',
        'goto-inventory': 'Ir a inventario',
        'goto-clients': 'Ir a clientes',
        'none': 'Sin acción'
      }

      const shortcutsList = Object.entries(config)
        .filter(([_, action]) => action !== 'none')
        .map(([key, action]) => ({
          key,
          description: actionLabels[action as string] || 'Acción desconocida'
        }))

      // Agregar ESC al final
      shortcutsList.push({ key: 'ESC', description: 'Cerrar/Cancelar' })

      setShortcuts(shortcutsList)
    }

    loadShortcuts()

    // Escuchar cambios en localStorage
    const handleStorageChange = () => {
      loadShortcuts()
    }

    window.addEventListener('storage', handleStorageChange)
    return () => window.removeEventListener('storage', handleStorageChange)
  }, [])

  return (
    <>
      {/* Botón flotante para mostrar/ocultar atajos */}
      <button
        onClick={() => setIsVisible(!isVisible)}
        style={{
          position: 'fixed',
          bottom: '20px',
          right: '20px',
          width: '50px',
          height: '50px',
          borderRadius: '50%',
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          color: 'white',
          border: 'none',
          boxShadow: '0 4px 12px rgba(102, 126, 234, 0.4)',
          cursor: 'pointer',
          fontSize: '20px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
          transition: 'all 0.3s ease'
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.transform = 'scale(1.1)'
          e.currentTarget.style.boxShadow = '0 6px 20px rgba(102, 126, 234, 0.5)'
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.transform = 'scale(1)'
          e.currentTarget.style.boxShadow = '0 4px 12px rgba(102, 126, 234, 0.4)'
        }}
        title="Atajos de teclado"
      >
        ⌨️
      </button>

      {/* Panel de atajos */}
      {isVisible && (
        <div
          style={{
            position: 'fixed',
            bottom: '80px',
            right: '20px',
            background: 'var(--card-bg)',
            borderRadius: '12px',
            padding: '20px',
            boxShadow: '0 8px 32px rgba(0, 0, 0, 0.2)',
            zIndex: 1000,
            minWidth: '280px',
            border: '1px solid var(--border-color)',
            animation: 'slideUp 0.3s ease'
          }}
        >
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '16px',
            paddingBottom: '12px',
            borderBottom: '2px solid var(--border-color)'
          }}>
            <h3 style={{
              margin: 0,
              fontSize: '1rem',
              fontWeight: '700',
              color: 'var(--text-primary)'
            }}>
              ⌨️ Atajos de Teclado
            </h3>
            <button
              onClick={() => setIsVisible(false)}
              style={{
                background: 'transparent',
                border: 'none',
                fontSize: '20px',
                cursor: 'pointer',
                color: 'var(--text-secondary)',
                padding: '4px'
              }}
            >
              ✕
            </button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {shortcuts.map((shortcut, index) => (
              <div
                key={index}
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  padding: '8px 12px',
                  background: 'var(--bg-secondary)',
                  borderRadius: '8px',
                  transition: 'all 0.2s ease'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'var(--bg-tertiary)'
                  e.currentTarget.style.transform = 'translateX(-4px)'
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'var(--bg-secondary)'
                  e.currentTarget.style.transform = 'translateX(0)'
                }}
              >
                <span style={{
                  fontSize: '0.85rem',
                  color: 'var(--text-secondary)'
                }}>
                  {shortcut.description}
                </span>
                <kbd style={{
                  background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                  color: 'white',
                  padding: '4px 10px',
                  borderRadius: '6px',
                  fontSize: '0.75rem',
                  fontWeight: '700',
                  fontFamily: 'monospace',
                  boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)',
                  minWidth: '45px',
                  textAlign: 'center'
                }}>
                  {shortcut.key}
                </kbd>
              </div>
            ))}
          </div>

          <div style={{
            marginTop: '16px',
            paddingTop: '12px',
            borderTop: '1px solid var(--border-color)',
            fontSize: '0.75rem',
            color: 'var(--text-muted)',
            textAlign: 'center'
          }}>
            Personaliza en Configuración → Estilos
          </div>
        </div>
      )}

      <style>{`
        @keyframes slideUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </>
  )
}
