import React, { useState } from 'react'
import { autoInstaller, InstallProgress } from '../services/autoInstaller'
import './AutoUpdateInstaller.css'

interface Props {
  downloadUrl: string
  version: string
  onClose: () => void
}

export default function AutoUpdateInstaller({ downloadUrl, version, onClose }: Props) {
  const [progress, setProgress] = useState<InstallProgress>({
    step: 'downloading',
    progress: 0,
    message: 'Iniciando descarga...'
  })
  const [isInstalling, setIsInstalling] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleInstall = async () => {
    setIsInstalling(true)
    setError(null)
    
    try {
      // Validar URL
      if (!downloadUrl || downloadUrl.trim() === '') {
        throw new Error('URL de descarga no disponible')
      }
      
      console.log('[AutoUpdateInstaller] Descargando desde:', downloadUrl)
      
      // Configurar callback de progreso
      autoInstaller.setProgressCallback((prog) => {
        console.log('[AutoUpdateInstaller] Progreso:', prog)
        setProgress(prog)
      })
      
      // Iniciar instalación
      const success = await autoInstaller.downloadAndInstall(downloadUrl, version)
      
      if (success) {
        // Mostrar mensaje de éxito
        setTimeout(() => {
          alert(
            '✅ ¡Actualización descargada!\n\n' +
            'El archivo se guardó en tu carpeta "Descargas".\n\n' +
            'PASOS PARA COMPLETAR:\n' +
            '1. Cierra este programa\n' +
            '2. Extrae el archivo ZIP\n' +
            '3. Copia los archivos a la carpeta del programa\n' +
            '4. Abre el programa de nuevo\n\n' +
            '¡Listo! La actualización estará instalada.'
          )
          onClose()
        }, 1500)
      } else {
        setError('Error al descargar la actualización. Intenta de nuevo.')
        setIsInstalling(false)
      }
    } catch (err) {
      console.error('[AutoUpdateInstaller] Error:', err)
      setError((err as Error).message || 'Error desconocido')
      setIsInstalling(false)
    }
  }

  const getStepIcon = () => {
    switch (progress.step) {
      case 'downloading': return '⬇️'
      case 'extracting': return '📦'
      case 'installing': return '⚙️'
      case 'complete': return '✅'
      case 'error': return '❌'
      default: return '🔄'
    }
  }

  const getStepText = () => {
    switch (progress.step) {
      case 'downloading': return 'Descargando'
      case 'extracting': return 'Extrayendo'
      case 'installing': return 'Instalando'
      case 'complete': return 'Completado'
      case 'error': return 'Error'
      default: return 'Procesando'
    }
  }

  return (
    <div className="auto-installer-overlay">
      <div className="auto-installer-modal">
        <div className="installer-header">
          <h2>🚀 Instalación Automática</h2>
          <p>Versión {version}</p>
        </div>

        {!isInstalling ? (
          <div className="installer-content">
            <div className="installer-info">
              <div className="info-icon">📦</div>
              <h3>¿Descargar e instalar automáticamente?</h3>
              <p>
                El sistema descargará la actualización y te guiará en la instalación.
              </p>
              <div className="info-steps">
                <div className="step-item">
                  <span className="step-number">1</span>
                  <span>Descarga automática del archivo</span>
                </div>
                <div className="step-item">
                  <span className="step-number">2</span>
                  <span>Instrucciones de instalación</span>
                </div>
                <div className="step-item">
                  <span className="step-number">3</span>
                  <span>Reiniciar el programa</span>
                </div>
              </div>
            </div>

            <div className="installer-actions">
              <button
                className="btn-install"
                onClick={handleInstall}
              >
                ⬇️ Descargar e Instalar
              </button>
              <button
                className="btn-cancel"
                onClick={onClose}
              >
                Cancelar
              </button>
            </div>
          </div>
        ) : (
          <div className="installer-progress">
            <div className="progress-icon">{getStepIcon()}</div>
            <div className="progress-step">{getStepText()}</div>
            <div className="progress-message">{progress.message}</div>
            
            <div className="progress-bar-container">
              <div 
                className="progress-bar-fill"
                style={{ width: `${progress.progress}%` }}
              />
            </div>
            
            <div className="progress-percentage">{progress.progress}%</div>

            {error && (
              <div className="error-message">
                ❌ {error}
              </div>
            )}

            {progress.step === 'complete' && (
              <div className="success-message">
                ✅ ¡Descarga completada! Revisa tu carpeta "Descargas"
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
