import { useState, useEffect, useMemo } from 'react'

export interface QuoteItem {
  id: string
  name: string
  price: number
  qty: number
}

export interface Quote {
  id: string
  createdAt: string
  client: string
  items: QuoteItem[]
  subtotal: number
  discount: number
  tax: number
  total: number
  status: 'pending' | 'converted'
  notes?: string
}

const QUOTES_KEY = 'pos_quotes'

export function useQuotes() {
  const [quotes, setQuotes] = useState<Quote[]>(() => {
    try {
      const data = localStorage.getItem(QUOTES_KEY)
      return data ? JSON.parse(data) : []
    } catch {
      return []
    }
  })

  // Persistir cambios
  useEffect(() => {
    localStorage.setItem(QUOTES_KEY, JSON.stringify(quotes))
  }, [quotes])

  // ==================== CRUD ====================

  const addQuote = (quote: Quote) => {
    setQuotes(prev => [...prev, quote])
  }

  const getQuote = (id: string) => {
    return quotes.find(q => q.id === id)
  }

  const deleteQuote = (id: string) => {
    setQuotes(prev => prev.filter(q => q.id !== id))
  }

  const updateQuoteStatus = (id: string, status: 'pending' | 'converted') => {
    setQuotes(prev => prev.map(q => q.id === id ? { ...q, status } : q))
  }

  // ==================== Búsqueda ====================

  const searchQuotes = (query: string) => {
    if (!query.trim()) return quotes
    
    const lowerQuery = query.toLowerCase()
    return quotes.filter(q =>
      q.id.toLowerCase().includes(lowerQuery) ||
      q.client.toLowerCase().includes(lowerQuery)
    )
  }

  // ==================== Conversión a Venta ====================

  const convertToSale = (quoteId: string) => {
    const quote = getQuote(quoteId)
    if (!quote) return

    // Crear venta desde cotización
    const sale = {
      id: `SALE-${Date.now()}`,
      timestamp: new Date().toISOString(),
      date: new Date().toISOString(),
      client: quote.client,
      items: quote.items,
      subtotal: quote.subtotal,
      discount: quote.discount,
      tax: quote.tax,
      total: quote.total,
      paymentMethod: 'Efectivo',
      fromQuote: quoteId
    }

    // Guardar venta
    const sales = JSON.parse(localStorage.getItem('pos_sales_history') || '[]')
    sales.push(sale)
    localStorage.setItem('pos_sales_history', JSON.stringify(sales))

    // Actualizar estado de cotización
    updateQuoteStatus(quoteId, 'converted')
  }

  // ==================== Generación HTML ====================

  const generateQuoteHTML = (quote: Quote, companyConfig: any, userProfile: any): string => {
    const formatCurrency = (amount: number) => {
      return `$ ${amount.toLocaleString('es-CO')}`
    }

    const formatDate = (dateStr: string) => {
      const date = new Date(dateStr)
      return date.toLocaleDateString('es-CO', {
        day: '2-digit',
        month: 'long',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      })
    }

    // Obtener configuración personalizada
    const colorPrimary = companyConfig.quoteColorPrimary || '#f59e0b'
    const colorSecondary = companyConfig.quoteColorSecondary || '#d97706'
    const colorAccent = companyConfig.quoteColorAccent || '#3b82f6'
    const fontSize = companyConfig.quoteFontSize || '14'
    const fontFamily = companyConfig.quoteFontFamily || 'Segoe UI'
    const validityDays = companyConfig.quoteValidityDays || 15
    const showLogo = companyConfig.quoteShowLogo ?? true
    const logoWidth = companyConfig.quoteLogoWidth || 120
    const logoHeight = companyConfig.quoteLogoHeight || 70
    
    // Configuración de información del cliente
    const showClientName = companyConfig.quoteShowClientName ?? true
    const showClientEmail = companyConfig.quoteShowClientEmail ?? false
    const showClientPhone = companyConfig.quoteShowClientPhone ?? false
    const showClientAddress = companyConfig.quoteShowClientAddress ?? false
    const showClientDocument = companyConfig.quoteShowClientDocument ?? false
    
    // Términos y condiciones personalizables
    const defaultTerms = 'Después de {dias} días, no nos hacemos responsables de cambios en el valor de los productos o servicios cotizados, los precios están sujetos a disponibilidad de inventario al momento de confirmar el pedido, para confirmar su pedido se requiere un anticipo del 50% del valor total, el tiempo de entrega será confirmado al momento de realizar el pedido, los productos o servicios no incluyen instalación, transporte o configuración salvo que se especifique lo contrario, esta cotización no constituye una factura ni un compromiso de compra hasta su confirmación formal.'
    const quoteTerms = (companyConfig.quoteTerms || defaultTerms).replace('{dias}', validityDays.toString())

    const itemsHTML = quote.items.map(item => `
      <tr>
        <td style="padding: 12px 10px; border-bottom: 1px solid #e5e7eb; font-weight: 500;">${item.name}</td>
        <td style="padding: 12px 10px; border-bottom: 1px solid #e5e7eb; text-align: center; font-weight: 500;">${item.qty}</td>
        <td style="padding: 12px 10px; border-bottom: 1px solid #e5e7eb; text-align: right; font-weight: 500;">${formatCurrency(item.price)}</td>
        <td style="padding: 12px 10px; border-bottom: 1px solid #e5e7eb; text-align: right; font-weight: 700; color: ${colorPrimary}; font-size: ${parseInt(fontSize) + 2}px;">${formatCurrency(item.price * item.qty)}</td>
      </tr>
    `).join('')

    return `
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="Expires" content="0">
  <title>Cotización ${quote.id}</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    html {
      width: 100%;
      min-width: 21cm;
    }
    
    body {
      font-family: '${fontFamily}', sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 20px 10px;
      color: #1f2937;
      font-size: ${fontSize}px;
      width: 100%;
      min-width: 21cm;
    }
    
    .quote-container {
      width: 21cm;
      max-width: 21cm;
      min-width: 21cm;
      margin: 0 auto;
      background: white;
      border-radius: 12px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
      overflow: hidden;
    }
    
    .quote-header {
      background: linear-gradient(135deg, ${colorPrimary} 0%, ${colorSecondary} 100%);
      padding: 18px 25px;
      color: white;
      position: relative;
      overflow: hidden;
    }
    
    .quote-header::before {
      content: '';
      position: absolute;
      top: -50%;
      right: -10%;
      width: 300px;
      height: 300px;
      background: rgba(255, 255, 255, 0.1);
      border-radius: 50%;
    }
    
    .header-content {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      position: relative;
      z-index: 1;
      gap: 20px;
    }
    
    .logo-section {
      display: flex;
      align-items: center;
      gap: 15px;
    }
    
    .company-logo {
      max-width: ${logoWidth}px;
      height: auto;
      max-height: ${logoHeight}px;
      object-fit: contain;
      padding: 5px;
      border-radius: 8px;
      flex-shrink: 0;
    }
    
    .company-info h1 {
      font-size: 20px;
      font-weight: 700;
      margin-bottom: 4px;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
    }
    
    .company-info p {
      font-size: ${parseInt(fontSize) - 3}px;
      margin: 2px 0;
      opacity: 0.95;
    }
    
    .company-info .icon-nit,
    .company-info .icon-location,
    .company-info .icon-phone,
    .company-info .icon-email {
      font-weight: bold;
      margin-right: 5px;
      font-size: ${parseInt(fontSize)}px;
      display: inline-block;
      width: 16px;
      text-align: center;
    }
    
    .quote-badge {
      background: white;
      color: ${colorPrimary};
      padding: 10px 20px;
      border-radius: 6px;
      font-size: 20px;
      font-weight: 700;
      text-align: center;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }
    
    .quote-info {
      text-align: right;
      margin-top: 8px;
    }
    
    .quote-info p {
      font-size: ${parseInt(fontSize) - 2}px;
      margin: 3px 0;
    }
    
    .quote-body {
      padding: 20px 25px;
    }
    
    .client-section {
      background: linear-gradient(135deg, ${colorAccent}08 0%, ${colorAccent}15 100%);
      padding: 8px 12px;
      border-radius: 6px;
      margin-bottom: 10px;
      border-left: 3px solid ${colorAccent};
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
    }
    
    .client-section h3 {
      display: inline-block;
      color: ${colorAccent};
      font-size: ${parseInt(fontSize) - 2}px;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-right: 10px;
      font-weight: 700;
      opacity: 0.8;
    }
    
    .client-name {
      display: inline;
      font-size: ${parseInt(fontSize) + 1}px;
      font-weight: 700;
      color: #1f2937;
      margin-right: 12px;
    }
    
    .client-details {
      display: inline-flex;
      flex-wrap: wrap;
      gap: 8px;
      font-size: ${parseInt(fontSize) - 2}px;
      color: #4b5563;
      align-items: center;
    }
    
    .client-detail-item {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 2px 4px;
      font-weight: 500;
      white-space: nowrap;
    }
    
    .client-detail-icon {
      font-size: ${parseInt(fontSize) - 1}px;
      flex-shrink: 0;
    }
    
    .client-detail-icon {
      font-size: ${parseInt(fontSize)}px;
    }
    
    .client-section p {
      font-size: ${parseInt(fontSize) + 2}px;
      font-weight: 600;
      color: #1f2937;
    }
    
    .items-table {
      width: 100%;
      border-collapse: collapse;
      margin: 15px 0;
      border: 2px solid #e5e7eb;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
    }
    
    .items-table thead {
      background: linear-gradient(135deg, ${colorPrimary} 0%, ${colorSecondary} 100%);
    }
    
    .items-table th {
      padding: 8px 8px;
      text-align: left;
      font-size: ${parseInt(fontSize) - 1}px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: white;
      border-bottom: 2px solid ${colorPrimary};
    }
    
    .items-table th:nth-child(2),
    .items-table th:nth-child(3),
    .items-table th:nth-child(4) {
      text-align: right;
    }
    
    .items-table th:nth-child(2) {
      text-align: center;
    }
    
    .items-table tbody tr:hover {
      background: linear-gradient(90deg, #f0f9ff 0%, #e0f2fe 100%);
    }
    
    .items-table tbody tr {
      border-bottom: 1px solid #e5e7eb;
      transition: background 0.2s;
    }
    
    .items-table tbody tr:last-child {
      border-bottom: 2px solid ${colorPrimary};
    }
    
    .items-table td {
      color: #1f2937;
      font-size: ${parseInt(fontSize)}px;
      padding: 8px 8px;
      font-weight: 500;
    }
    
    .items-table td:last-child {
      font-weight: 700;
      color: ${colorPrimary};
    }
    
    .totals-section {
      margin-top: 12px;
      display: flex;
      justify-content: flex-end;
    }
    
    .totals-box {
      width: 280px;
      background: linear-gradient(135deg, #f9fafb 0%, #f3f4f6 100%);
      border-radius: 6px;
      padding: 10px 12px;
      border: 2px solid #e5e7eb;
    }
    
    .total-row {
      display: flex;
      justify-content: space-between;
      padding: 3px 0;
      font-size: ${parseInt(fontSize) - 1}px;
      color: #4b5563;
    }
    
    .total-row.discount {
      color: #dc2626;
      font-weight: 600;
    }
    
    .total-row.final {
      border-top: 2px solid ${colorPrimary};
      margin-top: 6px;
      padding-top: 6px;
      font-size: ${parseInt(fontSize) + 3}px;
      font-weight: 700;
      color: #1f2937;
    }
    
    .total-row.final .amount {
      color: ${colorPrimary};
    }
    
    .notes-section {
      margin-top: 12px;
      background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
      padding: 8px 10px;
      border-radius: 6px;
      border-left: 3px solid ${colorPrimary};
    }
    
    .notes-section h4 {
      color: #92400e;
      font-size: ${parseInt(fontSize) - 2}px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 5px;
    }
    
    .notes-section p {
      color: #78350f;
      font-size: ${parseInt(fontSize) - 2}px;
      line-height: 1.4;
    }
    
    .quote-footer {
      background: #f9fafb;
      padding: 12px 20px;
      text-align: center;
      border-top: 2px solid #e5e7eb;
    }
    
    .validity-notice {
      background: linear-gradient(135deg, ${colorAccent}25 0%, ${colorAccent}35 100%);
      padding: 8px;
      border-radius: 6px;
      margin-bottom: 10px;
      border: 2px solid ${colorAccent};
    }
    
    .validity-notice p {
      color: ${colorAccent};
      font-weight: 600;
      font-size: ${parseInt(fontSize) - 1}px;
      margin: 0;
    }
    
    .footer-info {
      font-size: ${parseInt(fontSize) - 2}px;
      color: #6b7280;
    }
    
    @media print {
      body {
        background: white;
        padding: 0;
      }
      
      .quote-container {
        box-shadow: none;
        border-radius: 0;
        max-width: 21cm;
        min-height: 29.7cm;
      }
      
      .quote-header::before {
        display: none;
      }
      
      @page {
        size: letter;
        margin: 1cm;
      }
    }
  </style>
</head>
<body>
  <!-- Cotización formato CARTA - ${new Date().getTime()} -->
  <div class="quote-container">
    <!-- Header -->
    <div class="quote-header">
      <div class="header-content">
        <div class="logo-section">
          ${showLogo && companyConfig?.logo ? `<img src="${companyConfig.logo}" alt="Logo" class="company-logo" />` : ''}
          <div class="company-info">
            <h1>${companyConfig?.companyName || 'Mi Empresa'}</h1>
            <p>📄 NIT: ${companyConfig?.companyNIT || 'N/A'}</p>
            <p>📍 ${userProfile?.address || 'Dirección no especificada'}</p>
            <p>📞 Tel: ${userProfile?.phone || 'Teléfono no especificado'}</p>
            <p>✉️ ${userProfile?.email || ''}</p>
          </div>
        </div>
        <div>
          <div class="quote-badge">COTIZACIÓN</div>
          <div class="quote-info">
            <p><strong>No:</strong> ${quote.id}</p>
            <p><strong>Fecha:</strong> ${formatDate(quote.createdAt)}</p>
            <p><strong>Vendedor:</strong> ${userProfile?.name || 'Admin'}</p>
          </div>
        </div>
      </div>
    </div>

    <!-- Body -->
    <div class="quote-body">
      <!-- Cliente -->
      <div class="client-section">
        <h3>Cliente:</h3>
        ${showClientName ? `<span class="client-name">${quote.client || 'Cliente General'}</span>` : ''}
        <div class="client-details">
          ${showClientDocument && quote.clientDocument ? `<span class="client-detail-item">${quote.clientDocument}</span>` : ''}
          ${showClientEmail && quote.clientEmail ? `<span class="client-detail-item">${quote.clientEmail}</span>` : ''}
          ${showClientPhone && quote.clientPhone ? `<span class="client-detail-item">${quote.clientPhone}</span>` : ''}
          ${showClientAddress && quote.clientAddress ? `<span class="client-detail-item">${quote.clientAddress}</span>` : ''}
        </div>
      </div>

      <!-- Items -->
      <table class="items-table">
        <thead>
          <tr>
            <th>Producto / Servicio</th>
            <th>Cantidad</th>
            <th>Precio Unitario</th>
            <th>Subtotal</th>
          </tr>
        </thead>
        <tbody>
          ${itemsHTML}
        </tbody>
      </table>

      <!-- Totales -->
      <div class="totals-section">
        <div class="totals-box">
          <div class="total-row">
            <span>Subtotal:</span>
            <span class="amount">${formatCurrency(quote.subtotal)}</span>
          </div>
          ${quote.discount > 0 ? `
          <div class="total-row discount">
            <span>Descuento:</span>
            <span class="amount">-${formatCurrency(quote.discount)}</span>
          </div>
          ` : ''}
          ${quote.tax > 0 ? `
          <div class="total-row">
            <span>IVA (${companyConfig?.taxRate || 19}%):</span>
            <span class="amount">${formatCurrency(quote.tax)}</span>
          </div>
          ` : ''}
          <div class="total-row final">
            <span>TOTAL:</span>
            <span class="amount">${formatCurrency(quote.total)}</span>
          </div>
        </div>
      </div>

      <!-- Notas -->
      ${quote.notes ? `
      <div class="notes-section">
        <h4>📝 Notas Adicionales</h4>
        <p>${quote.notes}</p>
      </div>
      ` : ''}
    </div>

    <!-- Footer -->
    <div class="quote-footer">
      <div class="validity-notice">
        <p>⏰ Esta cotización es válida por ${validityDays} días calendario</p>
      </div>
      
      <div style="background: white; padding: 10px; border-radius: 6px; margin-bottom: 12px; border: 1px solid #e5e7eb; text-align: left;">
        <h4 style="color: #374151; font-size: ${parseInt(fontSize) - 5}px; margin-bottom: 4px; font-weight: 700;">📋 Términos y Condiciones</h4>
        <p style="color: #6b7280; font-size: ${parseInt(fontSize) - 6}px; line-height: 1.3; margin: 0; text-align: justify;">
          ${quoteTerms}
        </p>
      </div>
      
      <div style="background: linear-gradient(135deg, ${colorPrimary}15 0%, ${colorSecondary}15 100%); padding: 10px; border-radius: 6px; margin-bottom: 12px; border-left: 3px solid ${colorPrimary};">
        <p style="color: #374151; font-size: ${parseInt(fontSize) - 2}px; font-weight: 600; margin: 0;">
          💼 Para más información o aclarar dudas sobre esta cotización, no dude en contactarnos.
        </p>
      </div>
      
      <div class="footer-info">
        <p style="font-weight: 600; color: #374151; margin: 0; font-size: ${parseInt(fontSize) - 1}px;">¡Gracias por su preferencia!</p>
      </div>
    </div>
  </div>
</body>
</html>
    `
  }

  const downloadQuoteHTML = (quoteId: string, companyConfig: any, userProfile: any) => {
    const quote = getQuote(quoteId)
    if (!quote) return

    const html = generateQuoteHTML(quote, companyConfig, userProfile)
    const blob = new Blob([html], { type: 'text/html' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `cotizacion_${quote.id}.html`
    link.click()
    URL.revokeObjectURL(url)
  }

  const printQuoteHTML = (quoteId: string, companyConfig: any, userProfile: any) => {
    const quote = getQuote(quoteId)
    if (!quote) {
      alert('Cotización no encontrada')
      return
    }

    const html = generateQuoteHTML(quote, companyConfig, userProfile)
    const printWindow = window.open('', '_blank')
    if (printWindow) {
      printWindow.document.write(html)
      printWindow.document.close()
      printWindow.onload = () => {
        printWindow.print()
      }
    }
  }

  // ==================== Utilidades ====================

  const getQuoteCount = useMemo(() => {
    return quotes.length
  }, [quotes])

  const getTotalQuoted = useMemo(() => {
    return quotes.reduce((sum, q) => sum + q.total, 0)
  }, [quotes])

  return {
    // Estado
    quotes,
    setQuotes,
    // CRUD
    addQuote,
    getQuote,
    deleteQuote,
    updateQuoteStatus,
    // Búsqueda
    searchQuotes,
    // Conversión
    convertToSale,
    // Generación
    generateQuoteHTML,
    downloadQuoteHTML,
    printQuoteHTML,
    // Utilidades
    getQuoteCount,
    getTotalQuoted,
  }
}
