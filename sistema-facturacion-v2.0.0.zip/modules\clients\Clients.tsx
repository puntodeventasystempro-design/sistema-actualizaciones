import React, { useState, useEffect } from 'react'
import { useClients } from './useClients'
import { Client } from '../common/types'
import InputNumero from '../common/components/InputNumero'

// Tipo helper para el formulario
interface ClientFormData {
  name: string
  email: string
  phone: string
  nit: string
  address: string
  debtAmount: number
  debtNote: string
}

interface ClientsProps {
  onNavigateToSales?: () => void
}

export default function Clients({ onNavigateToSales }: ClientsProps) {
  const {
    clients,
    addClient,
    updateClient,
    removePayment,
    deleteClient,
    searchClients,
    validateClient,
    getClientCount,
    getClientsWithDebt,
    totalDebt,
    migrateClientIds,
    migrateInitialDebt,
  } = useClients()

  const [searchQuery, setSearchQuery] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [showDebtModal, setShowDebtModal] = useState(false)
  const [showHistoryModal, setShowHistoryModal] = useState(false)
  const [debtClient, setDebtClient] = useState<Client | null>(null)
  const [debtAmount, setDebtAmount] = useState<number>(0)
  const [paymentAmount, setPaymentAmount] = useState<number>(0)
  const [paymentNote, setPaymentNote] = useState('')
  const [isReadOnly, setIsReadOnly] = useState(false)
  const [editingClient, setEditingClient] = useState<Client | null>(null)
  const [debtSearch, setDebtSearch] = useState('')
  const [expandedPayments, setExpandedPayments] = useState<string | null>(null) // Estado para controlar qué cliente tiene los abonos expandidos

  // Migrar initialDebt automáticamente al cargar el componente
  useEffect(() => {
    migrateInitialDebt()
  }, [])

  // Sincronizar en tiempo real el cliente mostrado en el modal con el estado global `clients`.
  useEffect(() => {
    if (!debtClient) return
    const updated = clients.find(c => c.id === debtClient.id)
    if (updated) {
      setDebtClient(updated)
      setDebtAmount(updated.debtAmount || 0)
    }
  }, [clients])
  const [formData, setFormData] = useState<ClientFormData>({
    name: '',
    email: '',
    phone: '',
    nit: '',
    address: '',
    debtAmount: 0,
    debtNote: '',
  })
  const [errors, setErrors] = useState<string[]>([])
  const [selectedClientId, setSelectedClientId] = useState<string | null>(null)

  const filteredClients = searchClients(searchQuery)

  const resetForm = () => {
    setFormData({
      name: '',
      email: '',
      phone: '',
      nit: '',
      address: '',
      debtAmount: 0,
      debtNote: '',
    })
    setEditingClient(null)
    setErrors([])
    setShowForm(false)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    const { valid, errors: validationErrors } = validateClient(formData, editingClient?.id)
    
    if (!valid) {
      setErrors(validationErrors)
      return
    }

    if (editingClient) {
      updateClient(editingClient.id, {
        name: formData.name,
        email: formData.email || undefined,
        phone: formData.phone || undefined,
        nit: formData.nit || undefined,
        address: formData.address || undefined,
        debtAmount: formData.debtAmount,
      })
    } else {
      addClient(formData)
    }
    
    resetForm()
  }

  const handleEdit = (client: Client) => {
    setEditingClient(client)
    setFormData({
      name: client.name,
      email: client.email || '',
      phone: client.phone || '',
      nit: client.nit || '',
      address: client.address || '',
      debtAmount: client.debtAmount || 0,
      debtNote: client.debtNote || '',
    })
    setShowForm(true)
    setErrors([])
  }

  const handleDelete = (id: string) => {
    if (window.confirm('Estas seguro de eliminar este cliente?')) {
      deleteClient(id)
    }
  }

  const openDebtModal = (client: Client, readOnly: boolean = false) => {
    // Refresh client data from the list
    const currentClient = clients.find(c => c.id === client.id) || client
    setDebtClient(currentClient)
    setDebtAmount(currentClient.debtAmount || 0)
    setPaymentAmount(0)
    setPaymentNote('')
    setIsReadOnly(readOnly)
    setShowDebtModal(true)
  }

  const handleSaveDebt = () => {
    if (debtClient) {
      updateClient(debtClient.id, {
        debtAmount: debtAmount
      })
      setShowDebtModal(false)
      setDebtClient(null)
      setDebtAmount(0)
    }
  }

  const handleAddPayment = () => {
    if (debtClient && paymentAmount > 0) {
      const currentDebt = debtClient.debtAmount || 0
      const newDebt = Math.max(0, currentDebt - paymentAmount)
      
      const newPayment = {
        id: `PAY-${Date.now()}`,
        amount: paymentAmount,
        date: new Date().toISOString(),
        note: paymentNote || undefined,
        initialDebt: currentDebt,
        remainingBalance: newDebt
      }

      const updatedHistory = [...(debtClient.paymentHistory || []), newPayment]
      
      // Si no existe initialDebt, establecerla con la deuda actual antes del primer abono
      const updateData: Partial<Client> = {
        debtAmount: newDebt,
        paymentHistory: updatedHistory
      }
      
      if (!debtClient.initialDebt) {
        updateData.initialDebt = currentDebt
      }
      
      updateClient(debtClient.id, updateData)
      
      setPaymentAmount(0)
      setPaymentNote('')
      // Refresh the debt client
      const updatedClient = clients.find(c => c.id === debtClient.id)
      if (updatedClient) {
        setDebtClient(updatedClient)
      }
    }
  }

  const formatCurrency = (amount: number) => {
    return `$ ${amount.toLocaleString('es-CO')}`
  }

  return (
    <div className="module-body">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <button 
          onClick={() => onNavigateToSales?.()}
          style={{
            background: 'var(--success, #10b981)',
            color: 'white',
            border: 'none',
            padding: '10px 20px',
            borderRadius: '8px',
            cursor: 'pointer',
            fontSize: '14px'
          }}
        >
          ← Volver a Ventas
        </button>
        <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
          <button 
            onClick={() => setShowHistoryModal(true)}
            style={{
              background: '#059669',
              color: 'white',
              border: 'none',
              padding: '10px 20px',
              borderRadius: '8px',
              cursor: 'pointer',
              fontSize: '14px',
              fontWeight: 'bold'
            }}
          >
            📋 Historial Deudas
          </button>
          <button 
            onClick={() => {
              // Abrir modal de gestión de deudas en modo selección
              setDebtClient(null)
              setDebtAmount(0)
              setPaymentAmount(0)
              setPaymentNote('')
              setIsReadOnly(false)
              setDebtSearch('')
              setShowDebtModal(true)
            }}
            style={{
              background: '#f59e0b',
              color: 'white',
              border: 'none',
              padding: '10px 20px',
              borderRadius: '8px',
              cursor: 'pointer',
              fontSize: '14px',
              fontWeight: 'bold'
            }}
          >
            💰 Gestionar Deudas
          </button>
          <button 
            onClick={() => setShowForm(true)}
            style={{
              background: 'var(--accent, #0066cc)',
              color: 'white',
              border: 'none',
              padding: '10px 20px',
              borderRadius: '8px',
              cursor: 'pointer',
              fontSize: '14px'
            }}
          >
            + Nuevo Cliente
          </button>
          <button 
            onClick={() => {
              if (window.confirm('Esto convertirá todos los IDs de clientes al formato CLT-001, CLT-002, etc. ¿Continuar?')) {
                migrateClientIds()
                alert('IDs migrados correctamente')
              }
            }}
            style={{
              background: 'transparent',
              color: 'var(--warning, #f59e0b)',
              border: 'none',
              padding: '10px 20px',
              borderRadius: '8px',
              cursor: 'pointer',
              fontSize: '28px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}
            title="Migrar IDs de clientes"
          >
            🔄
          </button>
        </div>
      </div>

      {/* Stats */}
      <div style={{ display: 'flex', gap: '20px', marginBottom: '20px' }}>
        <div style={{ 
          background: 'var(--card-bg, #fff)', 
          padding: '15px', 
          borderRadius: '8px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          flex: 1
        }}>
          <strong>Total Clientes:</strong> {getClientCount}
        </div>
        <div style={{ 
          background: 'var(--card-bg, #fff)', 
          padding: '15px', 
          borderRadius: '8px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          flex: 1
        }}>
          <strong>Clientes con Deuda:</strong> {getClientsWithDebt.length}
        </div>
        <div style={{ 
          background: 'var(--card-bg, #fff)', 
          padding: '15px', 
          borderRadius: '8px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          flex: 1
        }}>
          <strong>Total Deuda:</strong> {formatCurrency(totalDebt)}
        </div>
      </div>

      {/* Form Modal */}
      {showForm && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{
            background: 'var(--card-bg, #fff)',
            padding: '30px',
            borderRadius: '12px',
            width: '400px',
            maxWidth: '90%'
          }}>
            <h3 style={{ marginTop: 0 }}>
              {editingClient ? 'Editar Cliente' : 'Nuevo Cliente'}
            </h3>
            
            {errors.length > 0 && (
              <ul style={{ color: '#e74c3c', paddingLeft: '20px' }}>
                {errors.map((error, i) => (
                  <li key={i}>{error}</li>
                ))}
              </ul>
            )}

            <form onSubmit={handleSubmit}>
              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                  Nombre *
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #ddd' }}
                  required
                />
              </div>

              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '5px' }}>Email</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={e => setFormData({ ...formData, email: e.target.value })}
                  style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #ddd' }}
                />
              </div>

              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '5px' }}>Telefono</label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={e => setFormData({ ...formData, phone: e.target.value })}
                  style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #ddd' }}
                />
              </div>

              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '5px' }}>NIT</label>
                <input
                  type="text"
                  value={formData.nit}
                  onChange={e => setFormData({ ...formData, nit: e.target.value })}
                  style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #ddd' }}
                />
              </div>

              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '5px' }}>Direccion</label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={e => setFormData({ ...formData, address: e.target.value })}
                  style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #ddd' }}
                />
              </div>

              <div style={{ marginBottom: '20px' }}>
                <InputNumero
                  label="Monto Deuda"
                  value={formData.debtAmount}
                  onChange={(value) => setFormData({ ...formData, debtAmount: typeof value === 'string' ? parseInt(value) || 0 : value })}
                />
              </div>

              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '5px' }}>Observaciones</label>
                <textarea
                  value={formData.debtNote}
                  onChange={e => setFormData({ ...formData, debtNote: e.target.value })}
                  placeholder="Observaciones adicionales del cliente..."
                  style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #ddd', minHeight: '60px', resize: 'vertical', fontFamily: 'inherit' }}
                />
              </div>

              <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end' }}>
                <button
                  type="button"
                  onClick={resetForm}
                  style={{
                    padding: '10px 20px',
                    borderRadius: '6px',
                    border: 'none',
                    background: '#dc2626',
                    color: 'white',
                    cursor: 'pointer',
                    fontWeight: 'bold'
                  }}
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  style={{
                    padding: '10px 20px',
                    borderRadius: '6px',
                    border: 'none',
                    background: 'var(--accent, #0066cc)',
                    color: 'white',
                    cursor: 'pointer'
                  }}
                >
                  {editingClient ? 'Actualizar' : 'Crear'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Historial General de Deudas Modal */}
      {showHistoryModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.6)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
          backdropFilter: 'blur(4px)'
        }}>
          <div style={{
            background: 'var(--card-bg, #fff)',
            padding: '30px',
            borderRadius: '12px',
            width: '600px',
            maxWidth: '95%',
            maxHeight: '85vh',
            overflowY: 'auto',
            boxShadow: 'var(--shadow-lg, 0 4px 20px rgba(0,0,0,0.15))'
          }}>
            <h2 style={{ marginTop: 0, marginBottom: '20px', color: '#8b5cf6' }}>📋 Cuentas Saldadas</h2>
            
            {clients.filter(c => c.paymentHistory && c.paymentHistory.length > 0 && (c.debtAmount || 0) === 0).length === 0 ? (
              <p style={{ color: 'var(--text-secondary, #666)', textAlign: 'center', padding: '40px' }}>
                No hay cuentas saldadas
              </p>
            ) : (
              <div style={{ maxHeight: '60vh', overflowY: 'auto' }}>
                {clients
                  .filter(c => c.paymentHistory && c.paymentHistory.length > 0 && (c.debtAmount || 0) === 0)
                  .map(client => (
                    <div key={client.id} style={{ 
                      marginBottom: '15px', 
                      padding: '15px', 
                      borderRadius: '8px',
                      background: 'rgba(16, 185, 129, 0.1)',
                      border: '1px solid rgba(16, 185, 129, 0.3)'
                    }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <div>
                          <strong style={{ fontSize: '16px', color: '#10b981' }}>{client.name}</strong>
                          <span style={{ marginLeft: '10px', color: '#10b981', fontSize: '12px' }}>✓ Saldada</span>
                        </div>
                        <button
                          onClick={() => openDebtModal(client, true)}
                          style={{
                            padding: '6px 12px',
                            borderRadius: '4px',
                            border: 'none',
                            background: '#8b5cf6',
                            color: 'white',
                            cursor: 'pointer',
                            fontSize: '12px'
                          }}
                        >
                          📋 Ver Historial
                        </button>
                      </div>
                      <p style={{ margin: '8px 0 0 0', color: 'var(--text-secondary, #666)', fontSize: '12px' }}>
                        Total abonos: {client.paymentHistory?.length} | 
                        Monto total: {formatCurrency(client.paymentHistory?.reduce((sum, p) => sum + p.amount, 0) || 0)}
                      </p>
                    </div>
                  ))}
              </div>
            )}

            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '20px' }}>
              <button
                onClick={() => setShowHistoryModal(false)}
                style={{
                  padding: '10px 20px',
                  borderRadius: '6px',
                  border: 'none',
                  background: '#dc2626',
                  color: 'white',
                  cursor: 'pointer',
                  fontWeight: 'bold'
                }}
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Debt Modal */}
      {showDebtModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.6)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
          backdropFilter: 'blur(4px)'
        }}>
          <div style={{
            background: 'var(--card-bg, #fff)',
            padding: '30px',
            borderRadius: '12px',
            width: isReadOnly ? '500px' : '500px',
            maxWidth: '90%',
            maxHeight: '80vh',
            overflowY: 'auto',
            boxShadow: 'var(--shadow-lg, 0 4px 20px rgba(0,0,0,0.15))'
          }}>
            {debtClient == null ? (
              <div>
                <h3 style={{ marginTop: 0, marginBottom: '10px', color: '#f59e0b' }}>💰 Seleccionar Cliente para Abonar</h3>
                <input
                  type="text"
                  placeholder="Buscar cliente por nombre, NIT o teléfono..."
                  value={debtSearch}
                  onChange={e => setDebtSearch(e.target.value)}
                  style={{ 
                    width: '100%', 
                    padding: '10px', 
                    borderRadius: '6px', 
                    border: '1px solid var(--border-color, #ddd)', 
                    marginBottom: '12px',
                    background: 'var(--bg-secondary, white)',
                    color: 'var(--text-primary, #333)'
                  }}
                />
                <div style={{ maxHeight: '50vh', overflowY: 'auto' }}>
                  {(clients.filter(c => {
                    const q = debtSearch.trim().toLowerCase()
                    if (!q) return true
                    return c.name.toLowerCase().includes(q) || (c.nit || '').toLowerCase().includes(q) || (c.phone || '').includes(q) || c.id.toLowerCase().includes(q)
                  })).map(client => (
                    <div key={client.id} style={{ 
                      display: 'flex', 
                      justifyContent: 'space-between', 
                      alignItems: 'center', 
                      padding: '10px', 
                      borderBottom: '1px solid var(--border-light, #eee)' 
                    }}>
                      <div>
                        <strong style={{ color: 'var(--text-primary, #333)' }}>{client.name}</strong>
                        <div style={{ fontSize: '12px', color: 'var(--text-secondary, #666)' }}>{client.id} • {formatCurrency(client.debtAmount || 0)}</div>
                      </div>
                      <div style={{ display: 'flex', gap: '8px' }}>
                        <button
                          onClick={() => {
                            setDebtClient(client)
                            setDebtAmount(client.debtAmount || 0)
                            setPaymentAmount(0)
                            setPaymentNote('')
                            setIsReadOnly(false)
                          }}
                          style={{ padding: '6px 10px', borderRadius: '6px', border: 'none', background: '#16a34a', color: 'white', cursor: 'pointer' }}
                        >
                          Seleccionar
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
                <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '12px' }}>
                  <button
                    onClick={() => {
                      setShowDebtModal(false)
                      setDebtClient(null)
                      setDebtSearch('')
                    }}
                    style={{ 
                      padding: '8px 14px', 
                      borderRadius: '6px', 
                      border: 'none', 
                      background: '#dc2626', 
                      color: 'white',
                      cursor: 'pointer',
                      fontWeight: 'bold'
                    }}
                  >
                    Cerrar
                  </button>
                </div>
              </div>
            ) : (
              <>
                <h3 style={{ marginTop: 0, marginBottom: '15px', color: '#f59e0b' }}>💰 {isReadOnly ? 'Historial de Abonos' : 'Gestión de Deuda'}</h3>
                
                <div style={{ 
                  background: 'var(--bg-tertiary, linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%))', 
                  padding: '15px', 
                  borderRadius: '10px',
                  marginBottom: '15px',
                  border: '2px solid var(--border-color, #e2e8f0)',
                  boxShadow: '0 2px 8px rgba(0, 0, 0, 0.05)'
                }}>
                  <div style={{ marginBottom: '8px' }}>
                    <strong style={{ color: 'var(--text-primary, #1e293b)' }}>Cliente:</strong> 
                    <span style={{ marginLeft: '8px', color: 'var(--text-primary, #0f172a)', fontSize: '16px', fontWeight: 'bold' }}>{debtClient.name}</span>
                  </div>
                  
                  {debtClient.initialDebt && debtClient.initialDebt > 0 && (
                    <div style={{ 
                      background: 'linear-gradient(135deg, #f3e8ff 0%, #e9d5ff 100%)',
                      padding: '10px 12px',
                      borderRadius: '8px',
                      marginBottom: '10px',
                      border: '2px solid #d8b4fe',
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center'
                    }}>
                      <span style={{ color: '#6b21a8', fontWeight: 'bold', fontSize: '14px' }}>💎 Deuda Inicial:</span>
                      <span style={{ color: '#7c3aed', fontSize: '18px', fontWeight: 'bold' }}>{formatCurrency(debtClient.initialDebt)}</span>
                    </div>
                  )}
                  
                  <div style={{ 
                    background: (debtClient.debtAmount || 0) > 0 ? 'linear-gradient(135deg, #fee2e2 0%, #fecaca 100%)' : 'linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%)',
                    padding: '10px 12px',
                    borderRadius: '8px',
                    border: (debtClient.debtAmount || 0) > 0 ? '2px solid #fca5a5' : '2px solid #6ee7b7',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                  }}>
                    <span style={{ 
                      color: (debtClient.debtAmount || 0) > 0 ? '#991b1b' : '#065f46', 
                      fontWeight: 'bold',
                      fontSize: '14px'
                    }}>
                      {(debtClient.debtAmount || 0) > 0 ? '⚠️ Deuda Actual:' : '✅ Deuda Actual:'}
                    </span>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span style={{ 
                        color: (debtClient.debtAmount || 0) > 0 ? '#dc2626' : '#059669', 
                        fontSize: '20px', 
                        fontWeight: 'bold' 
                      }}>
                        {formatCurrency(debtClient.debtAmount || 0)}
                      </span>
                      {(debtClient.debtAmount || 0) === 0 && debtClient.initialDebt && debtClient.initialDebt > 0 && (
                        <span style={{ 
                          background: '#10b981',
                          color: 'white',
                          padding: '4px 8px',
                          borderRadius: '4px',
                          fontSize: '12px',
                          fontWeight: 'bold'
                        }}>
                          SALDADA
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Formulario para nuevo abono - solo si no es solo lectura */}
                {!isReadOnly && (
                <div style={{ 
                  background: 'rgba(16, 185, 129, 0.1)', 
                  padding: '15px', 
                  borderRadius: '8px', 
                  marginBottom: '20px',
                  border: '1px solid rgba(16, 185, 129, 0.3)'
                }}>
                  <h4 style={{ margin: '0 0 10px 0', color: '#10b981' }}>➕ Registrar Abono</h4>
                  <div style={{ marginBottom: '10px' }}>
                    <InputNumero
                      label="Monto del Abono"
                      value={paymentAmount}
                      onChange={(value) => setPaymentAmount(typeof value === 'string' ? parseInt(value) || 0 : value)}
                    />
                  </div>
                  <input
                    type="text"
                    placeholder="Nota (opcional)"
                    value={paymentNote}
                    onChange={e => setPaymentNote(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '8px',
                      marginBottom: '10px',
                      borderRadius: '4px',
                      border: '1px solid var(--border-color, #ddd)',
                      background: 'var(--bg-secondary, white)',
                      color: 'var(--text-primary, #333)'
                    }}
                  />
                  <button
                    onClick={() => {
                      // Registrar pago y mantener modal abierto para seguir gestionando
                      handleAddPayment()
                      // Refrescar cliente mostrado
                      const updated = clients.find(c => c.id === debtClient.id)
                      if (updated) {
                        setDebtClient(updated)
                        setDebtAmount(updated.debtAmount || 0)
                      }
                    }}
                    disabled={paymentAmount <= 0 || paymentAmount > (debtClient.debtAmount || 0)}
                    style={{
                      padding: '10px 20px',
                      borderRadius: '6px',
                      border: 'none',
                      background: paymentAmount > 0 && paymentAmount <= (debtClient.debtAmount || 0) ? '#16a34a' : '#ccc',
                      color: 'white',
                      cursor: paymentAmount > 0 && paymentAmount <= (debtClient.debtAmount || 0) ? 'pointer' : 'not-allowed',
                      fontWeight: 'bold',
                      width: '100%'
                    }}
                  >
                    Registrar Abono
                  </button>
                </div>
                )}

                {/* Historial de abonos */}
                <div style={{ marginBottom: '20px' }}>
                  <h4 style={{ margin: '0 0 10px 0', color: 'var(--text-secondary, #666)' }}>📋 Historial de Abonos</h4>
                  {(!debtClient.paymentHistory || debtClient.paymentHistory.length === 0) ? (
                    <p style={{ color: 'var(--text-muted, #999)', fontStyle: 'italic' }}>No hay abonos registrados</p>
                  ) : (
                    <div style={{ maxHeight: '200px', overflowY: 'auto' }}>
                      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px' }}>
                        <thead>
                          <tr style={{ background: 'var(--bg-tertiary, #f5f5f5)' }}>
                            <th style={{ padding: '8px', textAlign: 'left', color: 'var(--text-primary, #333)' }}>Fecha</th>
                            <th style={{ padding: '8px', textAlign: 'right', color: 'var(--text-primary, #333)' }}>Abono</th>
                            <th style={{ padding: '8px', textAlign: 'right', color: 'var(--text-primary, #333)' }}>Saldo</th>
                            <th style={{ padding: '8px', textAlign: 'left', color: 'var(--text-primary, #333)' }}>Nota</th>
                          </tr>
                        </thead>
                        <tbody>
                          {debtClient.paymentHistory.slice().reverse().map((payment) => (
                            <tr key={payment.id} style={{ borderBottom: '1px solid var(--border-light, #eee)' }}>
                              <td style={{ padding: '8px', color: 'var(--text-primary, #333)' }}>
                                {new Date(payment.date).toLocaleDateString('es-CO')}
                              </td>
                                  <td style={{ padding: '8px', textAlign: 'right', color: '#10b981', fontWeight: 'bold' }}>
                                    -{formatCurrency(payment.amount)}
                                  </td>
                                  <td style={{ padding: '8px', textAlign: 'right', color: 'var(--text-primary, #333)' }}>
                                    {formatCurrency(payment.remainingBalance || 0)}
                                  </td>
                                  <td style={{ padding: '8px', color: 'var(--text-secondary, #666)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                                    <span>{payment.note || '-'}</span>
                                    {!isReadOnly && (
                                      <button
                                        onClick={() => {
                                          if (window.confirm('Eliminar este abono? Esta acción actualizará la deuda.')) {
                                            removePayment(debtClient.id, payment.id)
                                          }
                                        }}
                                        style={{ marginLeft: '8px', padding: '4px 8px', borderRadius: '4px', border: 'none', background: '#e53e3e', color: 'white', cursor: 'pointer' }}
                                        title="Eliminar abono"
                                      >
                                        🗑️
                                      </button>
                                    )}
                                  </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>

                <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end' }}>
                  <button
                    type="button"
                    onClick={() => {
                      setShowDebtModal(false)
                      setDebtClient(null)
                      setDebtAmount(0)
                      setPaymentAmount(0)
                      setPaymentNote('')
                      setDebtSearch('')
                    }}
                    style={{
                      padding: '10px 20px',
                      borderRadius: '6px',
                      border: 'none',
                      background: '#dc2626',
                      color: 'white',
                      cursor: 'pointer',
                      fontWeight: 'bold'
                    }}
                  >
                    Cerrar
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Search */}
      <div style={{ marginBottom: '20px' }}>
        <input
          type="text"
          placeholder="Buscar por nombre, email, NIT o telefono..."
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          style={{
            width: '100%',
            padding: '12px',
            borderRadius: '8px',
            border: '1px solid #ddd',
            fontSize: '14px'
          }}
        />
      </div>

      {/* Table */}
      <div className="table-container" style={{
        background: 'var(--card-bg, #fff)',
        borderRadius: '12px',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
      }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: 'var(--accent, #0066cc)', color: 'white' }}>
              <th style={{ padding: '12px', textAlign: 'left' }}>ID</th>
              <th style={{ padding: '12px', textAlign: 'left' }}>Nombre</th>
              <th style={{ padding: '12px', textAlign: 'left' }}>Email</th>
              <th style={{ padding: '12px', textAlign: 'left' }}>Telefono</th>
              <th style={{ padding: '12px', textAlign: 'left' }}>NIT</th>
              <th style={{ padding: '12px', textAlign: 'right' }}>Deuda</th>
              <th style={{ padding: '12px', textAlign: 'center' }}>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {filteredClients.length === 0 ? (
              <tr>
                <td colSpan={7} style={{ padding: '40px', textAlign: 'center', color: '#666' }}>
                  No hay clientes registrados
                </td>
              </tr>
            ) : (
              filteredClients.map((client: Client) => (
                <React.Fragment key={client.id}>
                  <tr
                    style={{
                      borderBottom: '1px solid #eee',
                      cursor: 'pointer',
                      backgroundColor: selectedClientId === client.id ? 'rgba(59, 130, 246, 0.1)' : 'transparent'
                    }}
                    onClick={() => setSelectedClientId(client.id === selectedClientId ? null : client.id)}
                    onDoubleClick={() => {
                        if (onNavigateToSales) {
                          console.log('Selected client to navigate:', client)
                          try {
                            localStorage.setItem('pos_selected_client', JSON.stringify({ id: client.id, name: client.name }))
                            localStorage.setItem('pos_selected_client_name', client.name)
                          } catch (e) {
                            // Fallback a id string
                            localStorage.setItem('pos_selected_client', client.id)
                            localStorage.setItem('pos_selected_client_name', client.name)
                          }
                          // Navegar primero para que Sales se monte y pueda escuchar el evento
                          onNavigateToSales()
                          // Dispatch en el siguiente tick para asegurar que el listener de Sales exista
                          try { setTimeout(() => { window.dispatchEvent(new CustomEvent('pos_client_selected', { detail: { id: client.id, name: client.name } })) }, 0) } catch (e) {}
                        }
                      }}
                  >
                    <td style={{ padding: '12px', fontWeight: '600', color: 'var(--accent)' }}>
                      {selectedClientId === client.id && <span style={{ marginRight: '8px', color: 'green', fontWeight: 'bold' }}>✔️</span>}
                      {client.id}
                    </td>
                    <td style={{ padding: '12px' }}>{client.name}</td>
                    <td style={{ padding: '12px' }}>{client.email || '-'}</td>
                    <td style={{ padding: '12px' }}>{client.phone || '-'}</td>
                    <td style={{ padding: '12px' }}>{client.nit || '-'}</td>
                    <td style={{ padding: '12px', textAlign: 'right', verticalAlign: 'middle' }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '8px' }}>
                        <div style={{ 
                          color: (client.debtAmount || 0) > 0 ? '#e74c3c' : '#10b981',
                          fontSize: '16px',
                          fontWeight: 'bold',
                          whiteSpace: 'nowrap'
                        }}>
                          {(client.debtAmount || 0) === 0 && client.initialDebt && client.initialDebt > 0 ? '✓ ' : ''}
                          {formatCurrency(client.debtAmount || 0)}
                        </div>
                        {client.paymentHistory && client.paymentHistory.length > 0 && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation()
                              setExpandedPayments(expandedPayments === client.id ? null : client.id)
                            }}
                            style={{
                              padding: '5px 9px',
                              borderRadius: '6px',
                              border: 'none',
                              background: expandedPayments === client.id ? 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)' : 'linear-gradient(135deg, #94a3b8 0%, #64748b 100%)',
                              color: 'white',
                              cursor: 'pointer',
                              fontSize: '11px',
                              fontWeight: 'bold',
                              boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                              whiteSpace: 'nowrap',
                              flexShrink: 0
                            }}
                            title={expandedPayments === client.id ? 'Ocultar abonos' : 'Ver abonos'}
                          >
                            {expandedPayments === client.id ? '▼' : '▶'} {client.paymentHistory.length}
                          </button>
                        )}
                      </div>
                    </td>
                    <td style={{ padding: '12px', textAlign: 'center' }}>
                      <button
                        onClick={(e) => {
                          e.stopPropagation()
                          handleEdit(client)
                        }}
                        style={{
                          padding: '6px 12px',
                          marginRight: '5px',
                          borderRadius: '4px',
                          border: 'none',
                          background: '#3498db',
                          color: 'white',
                          cursor: 'pointer'
                        }}
                      >
                        ✏️
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation()
                          openDebtModal(client)
                        }}
                        style={{
                          padding: '6px 12px',
                          marginRight: '5px',
                          borderRadius: '4px',
                          border: 'none',
                          background: '#f59e0b',
                          color: 'white',
                          cursor: 'pointer'
                        }}
                        title="Agregar Deuda"
                      >
                        💰
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation()
                          handleDelete(client.id)
                        }}
                        style={{
                          padding: '6px 12px',
                          marginRight: '5px',
                          borderRadius: '4px',
                          border: 'none',
                          background: '#dc2626',
                          color: 'white',
                          fontWeight: 'bold',
                          cursor: 'pointer'
                        }}
                      >
                        🗑️
                      </button>
                      {selectedClientId === client.id && onNavigateToSales && (
                        <button
                            onClick={(e) => {
                            e.stopPropagation()
                            try {
                              localStorage.setItem('pos_selected_client', JSON.stringify({ id: client.id, name: client.name }))
                              localStorage.setItem('pos_selected_client_name', client.name)
                            } catch (err) {
                              localStorage.setItem('pos_selected_client', client.id)
                              localStorage.setItem('pos_selected_client_name', client.name)
                            }
                            // Navegar primero
                            onNavigateToSales()
                            try { setTimeout(() => { window.dispatchEvent(new CustomEvent('pos_client_selected', { detail: { id: client.id, name: client.name } })) }, 0) } catch (e) {}
                          }}
                          style={{
                            padding: '6px 12px',
                            borderRadius: '4px',
                            border: 'none',
                            background: '#27ae60',
                            color: 'white',
                            cursor: 'pointer',
                            fontWeight: 'bold'
                          }}
                        >
                          🛒
                        </button>
                      )}
                    </td>
                  </tr>
                  
                  {/* Fila desplegable con historial de abonos */}
                  {expandedPayments === client.id && client.paymentHistory && client.paymentHistory.length > 0 && (
                    <tr style={{ backgroundColor: 'var(--bg-tertiary, rgba(59, 130, 246, 0.05))' }}>
                      <td colSpan={7} style={{ padding: '20px' }}>
                        <div style={{ 
                          background: 'var(--card-bg, white)', 
                          padding: '20px', 
                          borderRadius: '12px',
                          border: '2px solid var(--primary, #3b82f6)',
                          boxShadow: 'var(--shadow-md, 0 4px 12px rgba(59, 130, 246, 0.15))'
                        }}>
                          {/* Header con título y badge de deuda inicial */}
                          <div style={{ 
                            display: 'flex', 
                            alignItems: 'center', 
                            justifyContent: 'space-between',
                            marginBottom: '16px',
                            paddingBottom: '12px',
                            borderBottom: '2px solid var(--border-color, rgba(59, 130, 246, 0.2))'
                          }}>
                            <h4 style={{ margin: 0, color: 'var(--primary, #3b82f6)', fontSize: '16px', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '8px' }}>
                              <span>📋 Historial de Abonos</span>
                              <span style={{ color: 'var(--text-secondary, #6b7280)', fontWeight: 'normal', fontSize: '14px' }}>
                                - {client.name}
                              </span>
                            </h4>
                            {client.initialDebt && client.initialDebt > 0 && (
                              <div style={{ 
                                fontSize: '13px', 
                                color: '#8b5cf6',
                                fontWeight: '700',
                                background: 'linear-gradient(135deg, #f3e8ff 0%, #e9d5ff 100%)',
                                padding: '6px 14px',
                                borderRadius: '8px',
                                border: '2px solid #d8b4fe',
                                boxShadow: '0 2px 6px rgba(139, 92, 246, 0.2)'
                              }}>
                                💎 Deuda Inicial: {formatCurrency(client.initialDebt)}
                              </div>
                            )}
                          </div>

                          {/* Tabla de abonos */}
                          <div style={{ 
                            maxHeight: '320px', 
                            overflowY: 'auto',
                            borderRadius: '8px',
                            border: '1px solid var(--border-color, rgba(59, 130, 246, 0.15))'
                          }}>
                            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px' }}>
                              <thead style={{ position: 'sticky', top: 0, zIndex: 1 }}>
                                <tr style={{ background: 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)', color: 'white' }}>
                                  <th style={{ padding: '10px 12px', textAlign: 'left', fontWeight: '600', borderRadius: '8px 0 0 0' }}>📅 Fecha</th>
                                  <th style={{ padding: '10px 12px', textAlign: 'right', fontWeight: '600' }}>💵 Abono</th>
                                  <th style={{ padding: '10px 12px', textAlign: 'right', fontWeight: '600' }}>💰 Saldo Restante</th>
                                  <th style={{ padding: '10px 12px', textAlign: 'left', fontWeight: '600', borderRadius: '0 8px 0 0' }}>📝 Nota</th>
                                </tr>
                              </thead>
                              <tbody>
                                {client.paymentHistory.map((payment, idx) => (
                                  <tr key={idx} style={{ 
                                    borderBottom: idx < client.paymentHistory.length - 1 ? '1px solid var(--border-light, rgba(59, 130, 246, 0.1))' : 'none',
                                    transition: 'background 0.2s',
                                    background: idx % 2 === 0 ? 'transparent' : 'var(--bg-tertiary, rgba(59, 130, 246, 0.03))'
                                  }}>
                                    <td style={{ padding: '10px 12px', color: 'var(--text-primary, #1f2937)', fontSize: '12px' }}>
                                      {new Date(payment.date).toLocaleDateString('es-CO', { 
                                        day: '2-digit', 
                                        month: 'short', 
                                        year: 'numeric',
                                        hour: '2-digit',
                                        minute: '2-digit'
                                      })}
                                    </td>
                                    <td style={{ 
                                      padding: '10px 12px', 
                                      textAlign: 'right', 
                                      color: '#10b981', 
                                      fontWeight: 'bold',
                                      fontSize: '13px'
                                    }}>
                                      +{formatCurrency(payment.amount)}
                                    </td>
                                    <td style={{ 
                                      padding: '10px 12px', 
                                      textAlign: 'right', 
                                      fontWeight: 'bold', 
                                      color: 'var(--text-primary, #1f2937)',
                                      fontSize: '13px'
                                    }}>
                                      {formatCurrency(payment.remainingBalance || 0)}
                                    </td>
                                    <td style={{ 
                                      padding: '10px 12px', 
                                      color: 'var(--text-secondary, #6b7280)', 
                                      fontStyle: payment.note ? 'normal' : 'italic',
                                      fontSize: '12px'
                                    }}>
                                      {payment.note || 'Sin nota'}
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>

                          {/* Footer con resumen */}
                          <div style={{ 
                            marginTop: '16px', 
                            padding: '12px 16px', 
                            background: 'var(--bg-tertiary, linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, rgba(37, 99, 235, 0.1) 100%))', 
                            borderRadius: '8px',
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            border: '1px solid var(--border-color, rgba(59, 130, 246, 0.2))'
                          }}>
                            <span style={{ fontSize: '13px', color: 'var(--primary, #3b82f6)', fontWeight: 'bold' }}>
                              📊 Total de abonos: {client.paymentHistory.length}
                            </span>
                            <span style={{ fontSize: '15px', color: 'var(--primary, #3b82f6)', fontWeight: 'bold' }}>
                              💵 Suma total: {formatCurrency(client.paymentHistory.reduce((sum, p) => sum + p.amount, 0))}
                            </span>
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}

