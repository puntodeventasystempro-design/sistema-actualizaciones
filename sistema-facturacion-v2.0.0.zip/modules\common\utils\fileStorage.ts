/**
 * Utilidades para persistencia de datos en archivos JSON
 * Esto permite guardar y cargar datos desde archivos JSON en carpetas "data" de cada módulo
 */

// Ruta base para los archivos de datos (relativa al public)
const DATA_BASE_PATH = '/data'

/**
 * Guarda datos en un archivo JSON
 * Nota: En el navegador, esto descarga el archivo. Para persistencia real,
 * se recomienda usar un backend o la API File System Access
 */
export async function saveToFile<T>(data: T, filename: string): Promise<void> {
  try {
    const jsonStr = JSON.stringify(data, null, 2)
    const blob = new Blob([jsonStr], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = filename
    link.click()
    URL.revokeObjectURL(url)
    console.log(`Datos guardados en ${filename}`)
  } catch (error) {
    console.error(`Error guardando ${filename}:`, error)
    throw error
  }
}

/**
 * Carga datos desde un archivo JSON
 */
export async function loadFromFile<T>(file: File): Promise<T> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target?.result as string)
        resolve(data)
      } catch (error) {
        reject(new Error('Error al parsear el archivo JSON'))
      }
    }
    reader.onerror = () => reject(new Error('Error al leer el archivo'))
    reader.readAsText(file)
  })
}

/**
 * Genera un nombre de archivo con timestamp
 */
export function getFilenameWithTimestamp(baseName: string): string {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-').split('T')[0] + '_' + 
                    new Date().toTimeString().split(' ')[0].replace(/:/g, '-')
  return `${baseName}_${timestamp}.json`
}

/**
 * Obtiene la ruta del archivo de datos para un módulo específico
 */
export function getModuleDataPath(moduleName: string, filename: string): string {
  return `${DATA_BASE_PATH}/${moduleName}/${filename}`
}

// Tipos para el sistema de archivos virtual
export interface VirtualFile {
  name: string
  content: string
  lastModified: Date
}

export interface VirtualDirectory {
  name: string
  files: Record<string, VirtualFile>
  subdirs: Record<string, VirtualDirectory>
}

// Simulador de sistema de archivos en localStorage
const FS_KEY = 'pos_virtual_fs'

function getVirtualFS(): VirtualDirectory {
  try {
    const saved = localStorage.getItem(FS_KEY)
    if (saved) {
      const fs = JSON.parse(saved)
      // Convertir fechas de string a Date
      const restoreDates = (obj: any): any => {
        if (obj && typeof obj === 'object') {
          if (obj instanceof Array) {
            return obj.map(restoreDates)
          }
          const result: any = {}
          for (const key in obj) {
            if (key === 'lastModified' || key === 'createdAt') {
              result[key] = new Date(obj[key])
            } else {
              result[key] = restoreDates(obj[key])
            }
          }
          return result
        }
        return obj
      }
      return restoreDates(fs)
    }
  } catch {
    // Ignorar errores
  }
  return { name: 'root', files: {}, subdirs: {} }
}

function saveVirtualFS(fs: VirtualDirectory): void {
  localStorage.setItem(FS_KEY, JSON.stringify(fs))
}

/**
 * Escribe un archivo en el sistema de archivos virtual
 */
export function writeVirtualFile(moduleName: string, filename: string, content: string): void {
  const fs = getVirtualFS()
  
  // Crear estructura de directorios
  if (!fs.subdirs[moduleName]) {
    fs.subdirs[moduleName] = { name: moduleName, files: {}, subdirs: {} }
  }
  
  const moduleDir = fs.subdirs[moduleName]
  moduleDir.files[filename] = {
    name: filename,
    content,
    lastModified: new Date()
  }
  
  saveVirtualFS(fs)
}

/**
 * Lee un archivo del sistema de archivos virtual
 */
export function readVirtualFile(moduleName: string, filename: string): string | null {
  const fs = getVirtualFS()
  const moduleDir = fs.subdirs[moduleName]
  
  if (!moduleDir?.files[filename]) {
    return null
  }
  
  return moduleDir.files[filename].content
}

/**
 * Lista archivos en un directorio del sistema virtual
 */
export function listVirtualFiles(moduleName: string): string[] {
  const fs = getVirtualFS()
  const moduleDir = fs.subdirs[moduleName]
  return moduleDir ? Object.keys(moduleDir.files) : []
}

/**
 * Elimina un archivo del sistema virtual
 */
export function deleteVirtualFile(moduleName: string, filename: string): boolean {
  const fs = getVirtualFS()
  const moduleDir = fs.subdirs[moduleName]
  
  if (moduleDir?.files[filename]) {
    delete moduleDir.files[filename]
    saveVirtualFS(fs)
    return true
  }
  
  return false
}

/**
 * Guarda datos como JSON en el sistema virtual
 */
export function saveToVirtualFile<T>(moduleName: string, filename: string, data: T): void {
  const content = JSON.stringify(data, null, 2)
  writeVirtualFile(moduleName, filename, content)
}

/**
 * Lee datos como JSON del sistema virtual
 */
export function loadFromVirtualFile<T>(moduleName: string, filename: string): T | null {
  const content = readVirtualFile(moduleName, filename)
  if (!content) return null
  
  try {
    return JSON.parse(content)
  } catch {
    return null
  }
}

/**
 * Obtiene todos los datos de un módulo como objeto
 */
export function getModuleAllData(moduleName: string): Record<string, any> {
  const fs = getVirtualFS()
  const moduleDir = fs.subdirs[moduleName]
  
  if (!moduleDir) return {}
  
  const result: Record<string, any> = {}
  for (const [filename, file] of Object.entries(moduleDir.files)) {
    try {
      const data = JSON.parse(file.content)
      const key = filename.replace('.json', '')
      result[key] = data
    } catch {
      // Ignorar archivos que no son JSON válidos
    }
  }
  
  return result
}

/**
 * Exporta todos los datos de un módulo como archivo JSON
 */
export async function exportModuleData(moduleName: string, baseFilename?: string): Promise<void> {
  const data = getModuleAllData(moduleName)
  const filename = baseFilename || `${moduleName}_data.json`
  await saveToFile(data, filename)
}
