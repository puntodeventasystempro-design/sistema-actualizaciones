// Re-export hooks
export { 
  useLocalStorage, 
  useLocalStorageBoolean,
  useLocalStorageNumber,
  useLocalStorageString,
  useLocalStorageObject,
  useLocalStorageArray,
  STORAGE_KEYS
} from './useLocalStorage'

export { default as useLocalStorageDefault } from './useLocalStorage'
