import { useState, useEffect } from 'react'
import { updateService } from '../services/updateService'
import AutoUpdateInstaller from './AutoUpdateInstaller'
import './UpdateChecker.css'

interface UpdateInfo {
  available: boolean
  version: string
  currentVersion: string
  releaseDate: string
  features: string[]
  downloadUrl?: string
  critical?: boolean
}

export default function UpdateChecker() {
  const [updateInfo, setUpdateInfo] = useState<UpdateInfo | null>(null)
  const [showNotification, setShowNotification] = useState(false)
  const [showInstaller, setShowInstaller] = useState(false)
  const [checkResult, setCheckResult] = useState<string>('Verificando...')

  useEffect(() => {
    checkForUpdates()
    
    // Verificar cada 6 horas
    const interval = setInterval(() => {
      checkForUpdates()
    }, 6 * 60 * 60 * 1000)
    
    const handleUpdateEvent = (event: CustomEvent) => {
      setUpdateInfo(event.detail)
      setShowNotification(true)
      playNotificationSound()
      sendBrowserNotification(event.detail)
    }
    
    window.addEventListener('update-available', handleUpdateEvent as EventListener)
    
    // Verificar si hay actualización guardada
    const savedUpdate = localStorage.getItem('pos_update_available')
    const dismissed = localStorage.getItem('pos_update_dismissed')
    
    if (savedUpdate && !dismissed) {
      try {
        const update = JSON.parse(savedUpdate)
        setUpdateInfo(update)
        setShowNotification(true)
      } catch (error) {
        console.error('Error al cargar actualización guardada:', error)
      }
    }
    
    return () => {
      clearInterval(interval)
      window.removeEventListener('update-available', handleUpdateEvent as EventListener)
    }
  }, [])

  const checkForUpdates = async () => {
    try {
      setCheckResult('Verificando...')
      
      // Usar Google Drive por defecto
      const useGoogleDrive = localStorage.getItem('pos_use_google_drive') !== 'false'
      const response = await updateService.checkForUpdates(useGoogleDrive)
      
      if (response.available) {
        setUpdateInfo(response)
        setShowNotification(true)
        setCheckResult(`✅ Nueva versión disponible: v${response.version}`)
        localStorage.setItem('pos_update_available', JSON.stringify(response))
        localStorage.removeItem('pos_update_dismissed')
        
        // Reproducir sonido y mostrar notificación
        playNotificationSound()
        sendBrowserNotification(response)
      } else {
        setUpdateInfo(null)
        setCheckResult('✓ Tu sistema está actualizado')
        localStorage.removeItem('pos_update_available')
      }
    } catch (error) {
      console.error('[UpdateChecker] Error:', error)
      setCheckResult('Error al verificar actualizaciones')
    }
  }

  const playNotificationSound = () => {
    try {
      // Crear un sonido de notificación simple usando Web Audio API
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
      const oscillator = audioContext.createOscillator()
      const gainNode = audioContext.createGain()
      
      oscillator.connect(gainNode)
      gainNode.connect(audioContext.destination)
      
      oscillator.frequency.value = 800
      oscillator.type = 'sine'
      
      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime)
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5)
      
      oscillator.start(audioContext.currentTime)
      oscillator.stop(audioContext.currentTime + 0.5)
    } catch (error) {
      console.warn('No se pudo reproducir sonido de notificación:', error)
    }
  }

  const sendBrowserNotification = (info: UpdateInfo) => {
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification('🔄 Nueva Actualización Disponible', {
        body: `Se encuentra disponible la versión ${info.version}. Haz clic para actualizar.`,
        icon: '🔔',
        tag: 'update-notification',
        requireInteraction: true
      })
    } else if ('Notification' in window && Notification.permission !== 'denied') {
      Notification.requestPermission().then(permission => {
        if (permission === 'granted') {
          sendBrowserNotification(info)
        }
      })
    }
  }

  const handleDownloadUpdate = async () => {
    setShowInstaller(true)
  }

  const dismissNotification = () => {
    setShowNotification(false)
    localStorage.setItem('pos_update_dismissed', new Date().toISOString())
  }

  if (showInstaller && updateInfo) {
    return (
      <AutoUpdateInstaller
        downloadUrl={updateInfo.downloadUrl || ''}
        version={updateInfo.version}
        onClose={() => setShowInstaller(false)}
      />
    )
  }

  if (!showNotification || !updateInfo?.available) {
    return null
  }

  return (
    <div className={`update-notification ${updateInfo.critical ? 'critical' : ''}`}>
      <div className="update-content">
        <div className="update-header">
          <div className="update-icon">🔔</div>
          <div className="update-title">
            <h3>Nueva Actualización Disponible</h3>
            <p>Versión {updateInfo.version}</p>
            {updateInfo.critical && <span className="critical-badge">⚠️ CRÍTICA</span>}
          </div>
          <button 
            className="update-close"
            onClick={dismissNotification}
            aria-label="Cerrar notificación"
          >
            ✕
          </button>
        </div>
        
        <div className="update-body">
          <div className="update-version-info">
            <span className="version-badge current">
              Actual: v{updateInfo.currentVersion}
            </span>
            <span className="version-arrow">→</span>
            <span className="version-badge new">
              Nueva: v{updateInfo.version}
            </span>
          </div>
          
          {updateInfo.releaseDate && (
            <div className="release-date">
              📅 {new Date(updateInfo.releaseDate).toLocaleDateString('es-ES')}
            </div>
          )}
          
          <div className="update-features">
            <h4>Novedades:</h4>
            <ul>
              {updateInfo.features && updateInfo.features.length > 0 ? (
                updateInfo.features.map((feature, index) => (
                  <li key={index}>{feature}</li>
                ))
              ) : (
                <li>Mejoras y correcciones del sistema</li>
              )}
            </ul>
          </div>
          
          <div className="update-actions">
            <button 
              className="btn-update-now"
              onClick={handleDownloadUpdate}
            >
              ⬇️ Descargar Actualización
            </button>
            <button 
              className="btn-update-later"
              onClick={dismissNotification}
            >
              Recordar más tarde
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
