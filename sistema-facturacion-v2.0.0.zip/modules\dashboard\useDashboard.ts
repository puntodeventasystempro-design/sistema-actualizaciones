import { useState, useEffect, useMemo } from 'react'
import { Sale, Product } from '../common/types'
import { formatCurrency } from '../common/utils/formatters'

const SALES_HISTORY_KEY = 'pos_sales_history'
const PRODUCTS_KEY = 'pos_products'

export function useDashboard() {
  const [salesHistory, setSalesHistory] = useState<Sale[]>(() => {
    try {
      const data = localStorage.getItem(SALES_HISTORY_KEY)
      return data ? JSON.parse(data) : []
    } catch {
      return []
    }
  })

  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const data = localStorage.getItem(PRODUCTS_KEY)
      return data ? JSON.parse(data) : []
    } catch {
      return []
    }
  })

  useEffect(() => {
    localStorage.setItem(SALES_HISTORY_KEY, JSON.stringify(salesHistory))
  }, [salesHistory])

  useEffect(() => {
    localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products))
  }, [products])

  // Calcular métricas desde salesHistory
  const totalRevenue = useMemo(() => {
    return salesHistory.reduce((sum, sale) => sum + (sale.total || 0), 0)
  }, [salesHistory])

  const transactionCount = useMemo(() => {
    return salesHistory.length
  }, [salesHistory])

  const averageTicket = useMemo(() => {
    if (salesHistory.length === 0) return 0
    return Math.round(totalRevenue / salesHistory.length)
  }, [salesHistory, totalRevenue])

  const criticalStockProducts = useMemo(() => products.filter(p => p.stock < 10), [products])
  const warningStockProducts = useMemo(() => products.filter(p => p.stock >= 10 && p.stock < 20), [products])

  const trendingProducts = useMemo(() => {
    const productSales: Record<string, number> = {}
    salesHistory.forEach(sale => {
      sale.items.forEach(item => {
        productSales[item.productId] = (productSales[item.productId] || 0) + item.qty
      })
    })
    return Object.entries(productSales)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([productId, count]) => {
        const product = products.find(p => p.id === productId)
        return { productId, name: product?.name || 'Desconocido', count }
      })
  }, [salesHistory, products])

  const recentSales = useMemo(() => {
    return [...salesHistory]
      .sort((a, b) => new Date(b.timestamp || b.date).getTime() - new Date(a.timestamp || a.date).getTime())
      .slice(0, 10)
  }, [salesHistory])

  const salesByDay = useMemo(() => {
    const last7Days: Record<string, number> = {}
    const today = new Date()
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today)
      date.setDate(date.getDate() - i)
      const dateStr = date.toISOString().split('T')[0]
      last7Days[dateStr] = 0
    }
    salesHistory.forEach(sale => {
      const saleDate = (sale.timestamp || sale.date).split('T')[0]
      if (last7Days.hasOwnProperty(saleDate)) {
        last7Days[saleDate] += sale.total
      }
    })
    return Object.entries(last7Days).map(([date, amount]) => ({ date, amount }))
  }, [salesHistory])

  return {
    salesHistory,
    setSalesHistory,
    products,
    setProducts,
    totalRevenue,
    transactionCount,
    averageTicket,
    criticalStockProducts,
    warningStockProducts,
    trendingProducts,
    recentSales,
    salesByDay,
  }
}
