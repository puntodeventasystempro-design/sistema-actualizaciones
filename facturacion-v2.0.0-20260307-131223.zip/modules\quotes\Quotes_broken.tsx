import React, { useState, useEffect } from 'react'
import { useQuotes, Quote, QuoteItem } from './useQuotes'

interface QuotesProps {
  onNavigateToProducts?: () => void
  onNavigateToClients?: () => void
}

export default function Quotes({ onNavigateToProducts, onNavigateToClients }: QuotesProps) {
  const {
    quotes,
    searchQuotes,
    deleteQuote,
    convertToSale,
    downloadQuoteHTML,
    printQuoteHTML,
    getQuoteCount,
    getTotalQuoted,
    addQuote,
  } = useQuotes()

  const [searchQuery, setSearchQuery] = useState('')
  const [selectedQuote, setSelectedQuote] = useState<string | null>(null)
  const [showPreview, setShowPreview] = useState(false)
  const [showCreateForm, setShowCreateForm] = useState(false)

  // Estados para crear cotización
  const [clientName, setClientName] = useState('')
  const [clientSearch, setClientSearch] = useState('')
  const [showClientList, setShowClientList] = useState(false)
  const [cart, setCart] = useState<QuoteItem[]>([])
  const [productSearch, setProductSearch] = useState('')
  const [selectedProduct, setSelectedProduct] = useState<any>(null)
  const [showProductList, setShowProductList] = useState(false)
  const [quantity, setQuantity] = useState(1)
  const [discount, setDiscount] = useState(0)
  const [notes, setNotes] = useState('')

  // Cargar productos y clientes
  const [products, setProducts] = useState<any[]>([])
  const [clients, setClients] = useState<any[]>([])

  useEffect(() => {
    const productsData = JSON.parse(localStorage.getItem('pos_products') || '[]')
    setProducts(productsData)
    const clientsData = JSON.parse(localStorage.getItem('pos_clients') || '[]')
    setClients(clientsData)
  }, [showCreateForm])

  // Cerrar listas al hacer clic fuera
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as HTMLElement
      if (!target.closest('.client-dropdown') && !target.closest('input[placeholder*="cliente"]')) {
        setShowClientList(false)
      }
      if (!target.closest('.product-dropdown') && !target.closest('input[placeholder*="producto"]')) {
        setShowProductList(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const filteredQuotes = searchQuotes(searchQuery)
  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(productSearch.toLowerCase()) ||
    p.barcode?.toLowerCase().includes(productSearch.toLowerCase())
  )
  const filteredClients = clients.filter(c =>
    c.name.toLowerCase().includes(clientSearch.toLowerCase()) ||
    c.email?.toLowerCase().includes(clientSearch.toLowerCase()) ||
    c.phone?.toLowerCase().includes(clientSearch.toLowerCase())
  )

  const formatCurrency = (amount: number) => {
    return `$ ${amount.toLocaleString('es-CO')}`
  }

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    return date.toLocaleDateString('es-CO', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const handlePreview = (quoteId: string) => {
    setSelectedQuote(quoteId)
    setShowPreview(true)
  }

  const handleDownload = (quoteId: string) => {
    const companyConfig = JSON.parse(localStorage.getItem('pos_company_config') || '{}')
    const userProfile = JSON.parse(localStorage.getItem('pos_user_profile') || '{}')
    downloadQuoteHTML(quoteId, companyConfig, userProfile)
  }

  const handlePrint = (quoteId: string) => {
    const companyConfig = JSON.parse(localStorage.getItem('pos_company_config') || '{}')
    const userProfile = JSON.parse(localStorage.getItem('pos_user_profile') || '{}')
    printQuoteHTML(quoteId, companyConfig, userProfile)
  }

  const handleDelete = (quoteId: string) => {
    if (window.confirm('¿Estás seguro de eliminar esta cotización?')) {
      deleteQuote(quoteId)
    }
  }

  const handleConvertToSale = (quoteId: string) => {
    if (window.confirm('¿Convertir esta cotización en una venta?')) {
      convertToSale(quoteId)
      alert('Cotización convertida a venta exitosamente')
    }
  }

  const addToCart = () => {
    if (!selectedProduct) {
      alert('Selecciona un producto')
      return
    }
    const existingItem = cart.find(item => item.id === selectedProduct.id)
    if (existingItem) {
      setCart(cart.map(item =>
        item.id === selectedProduct.id ? { ...item, qty: item.qty + quantity } : item
      ))
    } else {
      setCart([...cart, {
        id: selectedProduct.id,
        name: selectedProduct.name,
        price: selectedProduct.price,
        qty: quantity
      }])
    }
    setSelectedProduct(null)
    setProductSearch('')
    setQuantity(1)
  }

  const removeFromCart = (productId: string) => {
    setCart(cart.filter(item => item.id !== productId))
  }

  const updateCartQuantity = (productId: string, newQty: number) => {
    if (newQty <= 0) {
      removeFromCart(productId)
      return
    }
    setCart(cart.map(item =>
      item.id === productId ? { ...item, qty: newQty } : item
    ))
  }

  const calculateSubtotal = () => {
    return cart.reduce((sum, item) => sum + (item.price * item.qty), 0)
  }

  const calculateTax = () => {
    const companyConfig = JSON.parse(localStorage.getItem('pos_company_config') || '{}')
    const taxRate = companyConfig.taxRate || 0
    const applyTax = companyConfig.applyTax ?? false
    if (!applyTax) return 0
    const subtotal = calculateSubtotal()
    return (subtotal - discount) * (taxRate / 100)
  }

  const calculateTotal = () => {
    return calculateSubtotal() - discount + calculateTax()
  }

  const handleCreateQuote = () => {
    if (!clientName.trim()) {
      alert('Ingresa el nombre del cliente')
      return
    }
    if (cart.length === 0) {
      alert('Agrega al menos un producto')
      return
    }
    const newQuote: Quote = {
      id: `COT-${Date.now()}`,
      createdAt: new Date().toISOString(),
      client: clientName,
      items: cart,
      subtotal: calculateSubtotal(),
      discount: discount,
      tax: calculateTax(),
      total: calculateTotal(),
      status: 'pending',
      notes: notes
    }
    addQuote(newQuote)
    setClientName('')
    setClientSearch('')
    setShowClientList(false)
    setCart([])
    setDiscount(0)
    setNotes('')
    setProductSearch('')
    setSelectedProduct(null)
    setShowProductList(false)
    setShowCreateForm(false)
    alert('✅ Cotización creada exitosamente')
  }

  const cancelCreateQuote = () => {
    if (cart.length > 0) {
      if (!window.confirm('¿Cancelar la cotización? Se perderán los datos ingresados.')) {
        return
      }
    }
    setClientName('')
    setClientSearch('')
    setShowClientList(false)
    setCart([])
    setDiscount(0)
    setNotes('')
    setProductSearch('')
    setSelectedProduct(null)
    setShowProductList(false)
    setShowCreateForm(false)
  }

  const selectClient = (client: any) => {
    setClientName(client.name)
    setClientSearch(client.name)
    setShowClientList(false)
  }

  const selectProduct = (product: any) => {
    setSelectedProduct(product)
    setProductSearch(product.name)
    setShowProductList(false)
  }

  return (
    <div className="module-body">
      {/* Botón Nueva Cotización */}
      {!showCreateForm && (
        <div style={{ marginBottom: '20px' }}>
          <button
            onClick={() => setShowCreateForm(true)}
            style={{
              padding: '12px 24px',
              borderRadius: '8px',
              border: 'none',
              background: '#10b981',
              color: 'white',
              fontWeight: 'bold',
              cursor: 'pointer',
              fontSize: '14px'
            }}
          >
            ➕ Nueva Cotización
          </button>
        </div>
      )}

      {/* Formulario */}
      {showCreateForm && (
        <div style={{ background: 'white', padding: '25px', borderRadius: '12px', marginBottom: '20px' }}>
          <h3>📋 Nueva Cotización</h3>
          <button onClick={cancelCreateQuote}>✕ Cancelar</button>
          {/* Aquí iría todo el formulario pero lo simplificaré por ahora */}
          <p>Formulario de cotización aquí</p>
        </div>
      )}

      {/* Lista de cotizaciones */}
      {!showCreateForm && (
        <div>
          <p>Total Cotizaciones: {getQuoteCount}</p>
          <p>Total Cotizado: {formatCurrency(getTotalQuoted)}</p>
        </div>
      )}
    </div>
  )
}
