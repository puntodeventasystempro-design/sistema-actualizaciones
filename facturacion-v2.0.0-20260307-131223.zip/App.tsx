﻿import React, { useState, useEffect } from 'react'
import { useSettings } from './modules/settings/useSettings'
import { useLocalStorageString, useLocalStorageNumber } from './modules/common/hooks'
// EmailJS para envío de correos
import emailjs from '@emailjs/browser'

// Importar módulos
import Dashboard from './modules/dashboard/Dashboard'
import Sales from './modules/sales/Sales'
import Quotes from './modules/quotes/Quotes'
import Clients from './modules/clients/Clients'
import Products from './modules/products/Products'
import Reports from './modules/reports/Reports'
import Archives from './modules/archives/Archives'
import Settings from './modules/settings/Settings'
import Sidebar from './modules/common/components/Sidebar'
import UpdateChecker from './modules/common/components/UpdateChecker'

import './styles.css'
import './styles-login.css'

// Tipo para datos de login
interface LoginData {
  username: string
  password: string
}

// Tipo para Usuario del sistema
interface User {
  id: string
  username: string
  password: string
  role: 'admin' | 'seller' | 'viewer'
  createdAt?: string
  email?: string
  phone?: string
}

// Tipo para paso de recuperación
type RecoveryStep = 'method' | 'verify' | 'reset'

export default function App() {
  // Usar el hook de settings para obtener estado global
  const { 
    isDarkMode,
    toggleTheme,
    userProfile
  } = useSettings()

  // ========== SISTEMA DE FOOTER ==========
  const [currentTime, setCurrentTime] = useState(new Date())
  const [sessionStart] = useState(() => {
    // Iniciar tiempo de uso al cargar
    const stored = localStorage.getItem('pos_session_start')
    if (!stored) {
      localStorage.setItem('pos_session_start', Date.now().toString())
      return Date.now()
    }
    return parseInt(stored, 10)
  })
  const [usageTime, setUsageTime] = useState('0h 0m 0s')

  // Contador de sesiones (se incrementa en cada login exitoso)
  const [sessionCount, setSessionCount] = useState(() => {
    return parseInt(localStorage.getItem('pos_session_count') || '0', 10)
  })

  // Actualizar hora cada segundo
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
      // Calcular tiempo de uso
      const elapsed = Date.now() - sessionStart
      const hours = Math.floor(elapsed / 3600000)
      const minutes = Math.floor((elapsed % 3600000) / 60000)
      const seconds = Math.floor((elapsed % 60000) / 1000)
      setUsageTime(`${hours}h ${minutes}m ${seconds}s`)
    }, 1000)
    return () => clearInterval(timer)
  }, [sessionStart])

  // Formatear hora
  const formattedTime = currentTime.toLocaleTimeString('es-CO', { 
    hour: '2-digit', 
    minute: '2-digit', 
    second: '2-digit',
    hour12: true 
  })
  // ========== FIN SISTEMA DE FOOTER ==========

  // Estado del módulo activo (iniciar en dashboard)
  const [activeModule, setActiveModule] = useState('dashboard')
  
  // Estado del sidebar para móvil
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)

  // Estado de autenticación
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [loginData, setLoginData] = useState<LoginData>({
    username: '',
    password: ''
  })
  const [loginError, setLoginError] = useState('')
  
  // Estados para recuperación de contraseña
  const [showRecovery, setShowRecovery] = useState(false)
  const [recoveryStep, setRecoveryStep] = useState<RecoveryStep>('method')
  const [recoveryMethod, setRecoveryMethod] = useState<'email' | 'phone'>('email')
  const [recoveryInput, setRecoveryInput] = useState('')
  const [verificationCode, setVerificationCode] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmNewPassword, setConfirmNewPassword] = useState('')
  const [recoveryMessage, setRecoveryMessage] = useState('')
  const [recoveryError, setRecoveryError] = useState('')
  const [isSendingCode, setIsSendingCode] = useState(false)
  const [codeSent, setCodeSent] = useState(false)

  // Estado para bloqueo de licencia
  const [isLicenseBlocked, setIsLicenseBlocked] = useState(false)
  const [daysRemaining, setDaysRemaining] = useState(10)
  const [licenseKey, setLicenseKey] = useState('')
  const [licenseError, setLicenseError] = useState('')
  const [showLicenseError, setShowLicenseError] = useState(false)

  // Verificar autenticación al cargar
  useEffect(() => {
    const auth = localStorage.getItem('pos_authenticated')
    if (auth === 'true') {
      setIsAuthenticated(true)
    }
  }, [])

  // Verificar estado de licencia
  useEffect(() => {
    const checkLicenseStatus = () => {
      const licenseDate = localStorage.getItem('pos_license_date')
      const isLicenseValid = localStorage.getItem('pos_license') === 'valid'
      
      if (!licenseDate) {
        // Primera vez - establecer fecha de inicio
        localStorage.setItem('pos_license_date', new Date().toISOString())
        setDaysRemaining(10)
        return
      }
      
      if (isLicenseValid) {
        // Licencia activada - no bloquear
        setIsLicenseBlocked(false)
        return
      }
      
      // Calcular días transcurridos
      const startDate = new Date(licenseDate)
      const currentDate = new Date()
      const diffTime = currentDate.getTime() - startDate.getTime()
      const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24))
      const remaining = 10 - diffDays
      
      setDaysRemaining(remaining)
      
      if (remaining <= 0) {
        // Bloquear el sistema
        setIsLicenseBlocked(true)
      }
    }
    
    checkLicenseStatus()
    // Verificar cada minuto
    const interval = setInterval(checkLicenseStatus, 60000)
    return () => clearInterval(interval)
  }, [])

  // Aplicar tema
  useEffect(() => {
    const root = document.documentElement
    if (isDarkMode) {
      root.classList.remove('light')
      root.classList.add('dark')
    } else {
      root.classList.remove('dark')
      root.classList.add('light')
    }
  }, [isDarkMode])

  // Copia de seguridad automática al cerrar/cargar la página
  useEffect(() => {
    const backupData = () => {
      try {
        // Recopilar todos los datos
        const data = {
          products: JSON.parse(localStorage.getItem('pos_products') || '[]'),
          sales: JSON.parse(localStorage.getItem('pos_sales') || '[]'),
          clients: JSON.parse(localStorage.getItem('pos_clients') || '[]'),
          settings: {
            userProfile: JSON.parse(localStorage.getItem('pos_user_profile') || '{}'),
            companyConfig: JSON.parse(localStorage.getItem('pos_company_config') || '{}'),
            isDarkMode: localStorage.getItem('pos_dark_mode') === 'true',
          },
          users: JSON.parse(localStorage.getItem('pos_users') || '[]'),
          license: {
            isValid: localStorage.getItem('pos_license') === 'valid',
            key: localStorage.getItem('pos_license_key') || '',
            days: localStorage.getItem('pos_license_days') || '',
            date: localStorage.getItem('pos_license_date') || '',
            device: localStorage.getItem('pos_license_device') || '',
          },
          firstUse: localStorage.getItem('pos_first_use') || '',
          deviceId: localStorage.getItem('pos_device_id') || '',
          backupDate: new Date().toISOString()
        }
        
        localStorage.setItem('pos_auto_backup', JSON.stringify(data))
        console.log('Backup automatico guardado')
      } catch (error) {
        console.error('Error en backup automatico:', error)
      }
    }

    // Guardar cada 5 minutos
    const interval = setInterval(backupData, 5 * 60 * 1000)
    
    // Guardar al cerrar la página
    window.addEventListener('beforeunload', backupData)
    
    return () => {
      clearInterval(interval)
      window.removeEventListener('beforeunload', backupData)
    }
  }, [])

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    setLoginError('')
    
    // Validar que los campos no estén vacíos
    if (!loginData.username.trim() || !loginData.password.trim()) {
      setLoginError('Por favor, ingresa usuario y contrasena')
      return
    }
    
    const savedUsers = JSON.parse(localStorage.getItem('pos_users') || '[]') as User[]
    
    if (savedUsers.length === 0) {
      // Primer uso - crear usuario con las credenciales ingresadas
      const newUser: User = {
        id: Date.now().toString(),
        username: loginData.username.trim(),
        password: loginData.password.trim(),
        role: 'admin'
      }
      localStorage.setItem('pos_users', JSON.stringify([newUser]))
      
      // Incrementar contador de sesión en cada login exitoso
      const currentCount = parseInt(localStorage.getItem('pos_session_count') || '0', 10)
      const newCount = currentCount + 1
      localStorage.setItem('pos_session_count', newCount.toString())
      setSessionCount(newCount)
      
      setIsAuthenticated(true)
      localStorage.setItem('pos_authenticated', 'true')
    } else {
      // Verificar credenciales
      const user = savedUsers.find((u: User) => 
        u.username === loginData.username && u.password === loginData.password
      )
      
      if (user) {
        // Incrementar contador de sesión en cada login exitoso
        const currentCount = parseInt(localStorage.getItem('pos_session_count') || '0', 10)
        const newCount = currentCount + 1
        localStorage.setItem('pos_session_count', newCount.toString())
        setSessionCount(newCount)
        
        setIsAuthenticated(true)
        localStorage.setItem('pos_authenticated', 'true')
      } else {
        setLoginError('Usuario o contrasena incorrectos')
      }
    }
  }

  const handleLicenseActivation = () => {
    setLicenseError('')
    
    if (!licenseKey.trim()) {
      // Solo enfocar el campo, no mostrar error
      document.getElementById('licenseKey')?.focus()
      return
    }
    
    // Validar formato de licencia (ejemplo: XXXX-XXXX-XXXX-XXXX)
    const licensePattern = /^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/
    const cleanedKey = licenseKey.toUpperCase().trim()
    
    if (!licensePattern.test(cleanedKey)) {
      setLicenseError('Formato de licencia inválido')
      return
    }
    
    // Obtener device ID
    let deviceId = localStorage.getItem('pos_device_id')
    if (!deviceId) {
      deviceId = 'DEV-' + Math.random().toString(36).substring(2, 15)
      localStorage.setItem('pos_device_id', deviceId)
    }
    
    // Validar licencia (aquí puedes agregar tu lógica de validación)
    // Por ahora, aceptamos cualquier licencia con el formato correcto
    localStorage.setItem('pos_license', 'valid')
    localStorage.setItem('pos_license_key', cleanedKey)
    localStorage.setItem('pos_license_date', new Date().toISOString())
    localStorage.setItem('pos_license_device', deviceId)
    
    setIsLicenseBlocked(false)
    setLicenseKey('')
    alert('✅ Licencia activada correctamente')
  }

  const renderLicenseBlockScreen = () => (
    <div className="login-screen" style={{ 
      minHeight: '100vh', 
      width: '100vw',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '15px',
      boxSizing: 'border-box'
    }}>
      <div className="login-container" style={{ 
        maxWidth: '550px', 
        width: '100%',
        padding: '25px 20px'
      }}>
        <div className="login-header" style={{ marginBottom: '20px' }}>
          <div className="login-icon" style={{ fontSize: '60px', marginBottom: '12px' }}>🔒</div>
          <h1 style={{ 
            color: '#dc2626', 
            fontSize: '26px',
            fontWeight: '900',
            marginBottom: '10px',
            letterSpacing: '0.5px'
          }}>
            SISTEMA BLOQUEADO
          </h1>
          <p style={{ 
            fontSize: '15px', 
            color: 'rgba(255,255,255,0.9)',
            fontWeight: '500',
            lineHeight: '1.4'
          }}>
            El período de prueba de 10 días ha expirado
          </p>
        </div>
        
        <div style={{ 
          background: 'rgba(220, 38, 38, 0.15)', 
          border: '2px solid #dc2626', 
          borderRadius: '12px', 
          padding: '20px 18px', 
          marginBottom: '25px',
          textAlign: 'center',
          boxShadow: '0 6px 18px rgba(220, 38, 38, 0.3)'
        }}>
          <div style={{ fontSize: '48px', marginBottom: '10px' }}>⚠️</div>
          <div style={{ 
            fontSize: '18px', 
            fontWeight: '800', 
            color: '#dc2626', 
            marginBottom: '8px',
            textShadow: '0 2px 4px rgba(0,0,0,0.2)'
          }}>
            Licencia Requerida
          </div>
          <div style={{ 
            fontSize: '14px', 
            color: 'rgba(255,255,255,0.95)',
            lineHeight: '1.5',
            fontWeight: '500'
          }}>
            Para continuar usando el sistema, debe activar una licencia válida
          </div>
        </div>

        <form className="login-form" onSubmit={(e) => { 
          e.preventDefault(); 
          if (!licenseKey.trim()) {
            setShowLicenseError(true)
            document.getElementById('licenseKey')?.focus()
            return
          }
          setShowLicenseError(false)
          handleLicenseActivation(); 
        }}>
          <div className="login-field" style={{ marginBottom: '15px', position: 'relative' }}>
            <label htmlFor="licenseKey" style={{ 
              fontSize: '14px', 
              fontWeight: '700', 
              marginBottom: '8px', 
              display: 'block',
              color: 'rgba(255,255,255,0.95)',
              textTransform: 'uppercase',
              letterSpacing: '0.3px'
            }}>
              Clave de Licencia
            </label>
            <input
              id="licenseKey"
              type="text"
              value={licenseKey}
              onChange={(e) => {
                setLicenseKey(e.target.value.toUpperCase())
                setShowLicenseError(false)
              }}
              placeholder="XXXX-XXXX-XXXX-XXXX"
              maxLength={19}
              title="Ingrese su clave de licencia en formato XXXX-XXXX-XXXX-XXXX"
              style={{ 
                textAlign: 'center', 
                letterSpacing: '2px', 
                fontWeight: '700',
                fontSize: '15px',
                padding: '12px 16px',
                width: '100%',
                boxSizing: 'border-box',
                borderRadius: '8px',
                border: '2px solid rgba(255,255,255,0.2)',
                background: 'rgba(255,255,255,0.05)',
                color: '#ffffff',
                transition: 'all 0.3s'
              }}
              onFocus={(e) => {
                e.target.style.border = '2px solid #3b82f6'
                e.target.style.background = 'rgba(59,130,246,0.1)'
              }}
              onBlur={(e) => {
                e.target.style.border = '2px solid rgba(255,255,255,0.2)'
                e.target.style.background = 'rgba(255,255,255,0.05)'
              }}
              aria-required="true"
            />
          </div>
          
          <button type="submit" className="login-btn" style={{ 
            marginTop: '18px',
            padding: '14px 28px',
            fontSize: '16px',
            fontWeight: '800',
            borderRadius: '10px',
            background: showLicenseError 
              ? 'linear-gradient(135deg, #dc2626 0%, #991b1b 100%)'
              : 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)',
            border: 'none',
            color: '#ffffff',
            width: '100%',
            cursor: 'pointer',
            transition: 'all 0.3s',
            boxShadow: showLicenseError
              ? '0 4px 16px rgba(220, 38, 38, 0.4)'
              : '0 4px 16px rgba(59, 130, 246, 0.4)',
            textTransform: 'uppercase',
            letterSpacing: '0.8px'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'translateY(-2px)'
            if (showLicenseError) {
              e.currentTarget.style.boxShadow = '0 6px 20px rgba(220, 38, 38, 0.6)'
            } else {
              e.currentTarget.style.boxShadow = '0 6px 20px rgba(59, 130, 246, 0.6)'
            }
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translateY(0)'
            if (showLicenseError) {
              e.currentTarget.style.boxShadow = '0 4px 16px rgba(220, 38, 38, 0.4)'
            } else {
              e.currentTarget.style.boxShadow = '0 4px 16px rgba(59, 130, 246, 0.4)'
            }
          }}
          >
            🔓 Activar Licencia
          </button>
          
          <div style={{ 
            marginTop: '25px', 
            padding: '16px', 
            background: 'rgba(59, 130, 246, 0.15)', 
            borderRadius: '10px',
            fontSize: '13px',
            color: 'rgba(255,255,255,0.9)',
            textAlign: 'center',
            border: '2px solid rgba(59, 130, 246, 0.3)',
            lineHeight: '1.5'
          }}>
            <div style={{ marginBottom: '8px', fontSize: '14px', fontWeight: '600' }}>
              📞 Contacte al proveedor para obtener su licencia
            </div>
            <div style={{ fontWeight: '800', color: '#60a5fa', fontSize: '15px', letterSpacing: '0.3px' }}>
              ING.NARVAEZ IRIARTE .M
            </div>
          </div>
        </form>
      </div>
    </div>
  )

  const renderLoginScreen = () => (
    <div className="login-screen">
      <div className="login-container">
        <div className="login-header">
          <div className="login-icon">💻</div>
          <h1>SISTEMA DE FACTURACIÓN</h1>
          <p>Ingresa tus credenciales para continuar</p>
        </div>
        
        {!showRecovery ? (
          <form className="login-form" onSubmit={handleLogin}>
            <div className="login-field">
              <label htmlFor="username">Usuario</label>
              <input
                id="username"
                type="text"
                value={loginData.username}
                onChange={(e) => setLoginData(prev => ({ ...prev, username: e.target.value }))}
                onInvalid={(e) => {
                  e.preventDefault()
                  setLoginError('Ingrese su usuario')
                }}
                placeholder="Ingresa tu usuario"
                aria-required="true"
              />
            </div>
            
            <div className="login-field">
              <label htmlFor="password">Contraseña</label>
              <input
                id="password"
                type="password"
                value={loginData.password}
                onChange={(e) => setLoginData(prev => ({ ...prev, password: e.target.value }))}
                onInvalid={(e) => {
                  e.preventDefault()
                  setLoginError('Ingrese su contraseña')
                }}
                placeholder="Ingresa tu contraseña"
                aria-required="true"
              />
            </div>
            
            {loginError && (
              <div className="login-error" role="alert">
                {loginError}
              </div>
            )}
            
            <button type="submit" className="login-btn">
              Ingresar
            </button>
            
            <div style={{ textAlign: 'center', marginTop: '15px' }}>
              <button
                type="button"
                className="login-link"
                onClick={() => setShowRecovery(true)}
              >
                ¿Olvidaste tu contraseña?
              </button>
            </div>
          </form>
        ) : (
          <div className="recovery-form">
            <h3 style={{ textAlign: 'center', marginBottom: '25px', color: '#ffffff' }}>Recuperar Contraseña</h3>
            
            {recoveryStep === 'method' && (
              <>
                <p style={{ textAlign: 'center', marginBottom: '25px', color: 'rgba(255,255,255,0.8)', fontSize: '14px' }}>
                  Selecciona el método de recuperación:
                </p>
                <button
                  className="login-btn"
                  onClick={() => {
                    setRecoveryMethod('email')
                    setRecoveryStep('verify')
                  }}
                  style={{ background: 'rgba(255,255,255,0.1)', color: '#ffffff', border: '2px solid rgba(255,255,255,0.3)', marginBottom: '12px' }}
                >
                  📧 Recuperar por Email
                </button>
                <button
                  className="login-btn"
                  onClick={() => {
                    setRecoveryMethod('phone')
                    setRecoveryStep('verify')
                  }}
                  style={{ background: 'rgba(255,255,255,0.1)', color: '#ffffff', border: '2px solid rgba(255,255,255,0.3)', marginBottom: '12px' }}
                >
                  📱 Recuperar por Teléfono
                </button>
                <button
                  type="button"
                  className="login-link"
                  onClick={() => {
                    setShowRecovery(false)
                    setRecoveryStep('method')
                  }}
                  style={{ display: 'block', margin: '15px auto 0' }}
                >
                  ← Volver al login
                </button>
              </>
            )}
            
            {recoveryStep === 'verify' && (
              <>
                <p style={{ textAlign: 'center', marginBottom: '20px', color: 'rgba(255,255,255,0.8)', fontSize: '14px' }}>
                  Ingresa tu {recoveryMethod === 'email' ? 'email' : 'teléfono'} 
                  para recibir el código:
                </p>
                <div className="login-field">
                  <input
                    type={recoveryMethod === 'email' ? 'email' : 'tel'}
                    value={recoveryInput}
                    onChange={(e) => setRecoveryInput(e.target.value)}
                    placeholder={recoveryMethod === 'email' ? 'tu@email.com' : '3001234567'}
                  />
                </div>
                <button
                  className="login-btn"
                  onClick={async () => {
                    if (!recoveryInput) {
                      setRecoveryError('Por favor ingresa tu ' + (recoveryMethod === 'email' ? 'email' : 'teléfono'))
                      return
                    }
                    
                    setIsSendingCode(true)
                    setRecoveryError('')
                    
                    // Generar código
                    const code = Math.floor(100000 + Math.random() * 900000).toString()
                    localStorage.setItem(`pos_recovery_code_${recoveryMethod}`, code)
                    
                    // Guardar código en localStorage para verificar
                    localStorage.setItem('pos_verify_code', code)
                    
                    if (recoveryMethod === 'email') {
                      // Configuración EmailJS - REGISTRATE EN https://www.emailjs.com/
                      const serviceID = 'service_test123'
                      const templateID = 'template_test123'
                      const publicKey = 'YOUR_PUBLIC_KEY'
                      
                      try {
                        // Mostrar código en consola para pruebas
                        console.log('📧 Código de verificación:', code)
                        console.log('📧 Enviando a:', recoveryInput)
                        
                        // Intentar enviar con EmailJS (requiere credenciales)
                        try {
                          await emailjs.send(
                            serviceID,
                            templateID,
                            {
                              to_email: recoveryInput,
                              code: code,
                              from_name: 'Facturación Pro'
                            },
                            publicKey
                          )
                          setRecoveryMessage(`✓ Código enviado a ${recoveryInput}`)
                        } catch (emailError) {
                          // Si falla EmailJS, solo muestra enviado
                          setRecoveryMessage(`✓ Código enviado a ${recoveryInput}`)
                        }
                        
                        setCodeSent(true)
                        setRecoveryStep('reset')
                      } catch (error) {
                        setRecoveryMessage(`✓ Código enviado a ${recoveryInput}`)
                        setCodeSent(true)
                        setRecoveryStep('reset')
                      }
                    } else {
                      // Para SMS
                      console.log('📱 Código SMS:', code)
                      console.log('📱 Enviando a:', recoveryInput)
                      
                      setRecoveryMessage(`✓ Código enviado a ${recoveryInput}`)
                      setCodeSent(true)
                      setRecoveryStep('reset')
                    }
                    
                    setIsSendingCode(false)
                  }}
                  disabled={isSendingCode}
                  style={{ marginTop: '20px', opacity: isSendingCode ? 0.7 : 1 }}
                >
                  {isSendingCode ? 'Enviando...' : 'Enviar Código'}
                </button>
              </>
            )}
            
            {recoveryStep === 'reset' && (
              <>
                <p style={{ textAlign: 'center', marginBottom: '15px', color: 'rgba(255,255,255,0.8)', fontSize: '14px' }}>
                  Ingresa el código de 6 dígitos:
                </p>
                <div className="login-field">
                  <input
                    type="text"
                    value={verificationCode}
                    onChange={(e) => setVerificationCode(e.target.value)}
                    placeholder="000000"
                    maxLength={6}
                    style={{ textAlign: 'center', letterSpacing: '8px', fontWeight: '600' }}
                  />
                </div>
                <div className="login-field" style={{ marginTop: '15px' }}>
                  <label>Nueva contraseña:</label>
                  <input
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Nueva contraseña"
                  />
                </div>
                <div className="login-field" style={{ marginTop: '15px' }}>
                  <label>Confirmar contraseña:</label>
                  <input
                    type="password"
                    value={confirmNewPassword}
                    onChange={(e) => setConfirmNewPassword(e.target.value)}
                    placeholder="Confirmar contraseña"
                  />
                </div>
                
                {recoveryMessage && (
                  <p className="recovery-message" style={{ color: '#059669', background: '#d1fae5', padding: '12px', borderRadius: '10px', marginTop: '15px', fontSize: '14px', textAlign: 'center' }}>
                    {recoveryMessage}
                  </p>
                )}
                {recoveryError && (
                  <p className="login-error" style={{ marginTop: '15px' }}>
                    {recoveryError}
                  </p>
                )}
                
                <button
                  className="login-btn"
                  onClick={() => {
                    const storedCode = localStorage.getItem(`pos_recovery_code_${recoveryMethod}`)
                    
                    if (verificationCode !== storedCode) {
                      setRecoveryError('Código de verificación incorrecto')
                      return
                    }
                    
                    if (newPassword !== confirmNewPassword) {
                      setRecoveryError('Las contraseñas no coinciden')
                      return
                    }
                    
                    const savedUsers = JSON.parse(localStorage.getItem('pos_users') || '[]') as User[]
                    const updatedUsers = savedUsers.map((u: User) => {
                      if (recoveryMethod === 'email' ? u.email === recoveryInput : u.phone === recoveryInput) {
                        return { ...u, password: newPassword }
                      }
                      return u
                    })
                    
                    localStorage.setItem('pos_users', JSON.stringify(updatedUsers))
                    setRecoveryMessage('✓ Contraseña actualizada exitosamente')
                    setTimeout(() => {
                      setShowRecovery(false)
                      setRecoveryStep('method')
                      setRecoveryInput('')
                      setVerificationCode('')
                      setNewPassword('')
                      setConfirmNewPassword('')
                      setRecoveryMessage('')
                      setRecoveryError('')
                    }, 2500)
                  }}
                  style={{ marginTop: '20px' }}
                >
                  Restablecer Contraseña
                </button>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  )



  // Renderizar pantalla de login si no está autenticado
  if (!isAuthenticated) {
    return (
      <>
        {renderLoginScreen()}
      </>
    )
  }

  // Renderizar pantalla de bloqueo si la licencia expiró
  if (isLicenseBlocked) {
    return (
      <>
        {renderLicenseBlockScreen()}
      </>
    )
  }
  const handleLogout = () => {
    try {
      // Crear respaldo automático antes de cerrar sesión
      const autoBackupEnabled = localStorage.getItem('pos_auto_backup') === 'true'
      
      if (autoBackupEnabled) {
        const backupData = {
          timestamp: new Date().toISOString(),
          data: {}
        }

        // Recopilar todos los datos de localStorage
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i)
          if (key && key.startsWith('pos_')) {
            backupData.data[key] = localStorage.getItem(key)
          }
        }

        // Guardar en localStorage con timestamp
        const date = new Date()
        const dateStr = date.toISOString().split('T')[0]
        const timeStr = date.toTimeString().split(' ')[0].replace(/:/g, '-')
        const backupKey = `pos_backup_${dateStr}_${timeStr}`
        
        try {
          localStorage.setItem(backupKey, JSON.stringify(backupData))
          console.log(`[Backup] Respaldo automático guardado al cerrar sesión: ${backupKey}`)
          
          // Mantener solo los últimos 5 respaldos
          const allKeys = Object.keys(localStorage)
          const backupKeys = allKeys.filter(k => k.startsWith('pos_backup_')).sort().reverse()
          if (backupKeys.length > 5) {
            backupKeys.slice(5).forEach(k => {
              localStorage.removeItem(k)
              console.log(`[Backup] Respaldo antiguo eliminado: ${k}`)
            })
          }
        } catch (err) {
          console.error('[Backup] Error guardando respaldo:', err)
        }
      }
      
      // Limpiar estado de sesión
      localStorage.removeItem('pos_authenticated')
      // Opcional: limpiar otros datos de sesión
      setIsAuthenticated(false)
    } catch (e) {
      setIsAuthenticated(false)
    }
  }

  return (
    <div className={`app-container ${isDarkMode ? 'dark' : ''}`}>
      {/* Verificador de actualizaciones */}
      <UpdateChecker />
      
      {/* Sidebar */}
      <Sidebar
        activeModule={activeModule}
        onModuleChange={setActiveModule}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        isDarkMode={isDarkMode}
        toggleTheme={toggleTheme}
        userName={userProfile?.name}
        userPhoto={userProfile?.photo}
        onLogout={handleLogout}
      />

      {/* Contenido principal */}
      <main className="main-content">
        {/* Header */}
        <header className="app-header" style={{ position: 'fixed', top: 0, left: '220px', right: 0, zIndex: 100, background: isDarkMode ? '#0f172a' : '#ffffff', padding: '0.35rem 1rem', boxShadow: isDarkMode ? '0 1px 3px rgba(0, 0, 0, 0.6)' : '0 1px 3px rgba(0, 0, 0, 0.1)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          {/* Botón hamburguesa para móviles */}
          <button
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            style={{
              display: 'none',
              background: 'transparent',
              border: 'none',
              fontSize: '24px',
              cursor: 'pointer',
              padding: '4px 8px',
              color: isDarkMode ? '#fff' : '#333'
            }}
            className="hamburger-btn"
          >
            ☰
          </button>
          
          <h2 className="app-title" style={{ margin: 0, fontSize: '1.1rem', fontWeight: '700', color: isDarkMode ? '#f8fafc' : '#1e293b' }}>
            {activeModule === 'dashboard' && '📊 INICIO'}
            {activeModule === 'sales' && '💳 PUNTO DE VENTA'}
            {activeModule === 'quotes' && '📋 COTIZACIÓN'}
            {activeModule === 'clients' && '👥 CLIENTES'}
            {activeModule === 'products' && '📦 PRODUCTOS'}
            {activeModule === 'reports' && '📈 REPORTES'}
            {activeModule === 'archives' && '📁 ARCHIVOS'}
            {activeModule === 'settings' && '⚙️ CONFIGURACIÓN'}
          </h2>
          
        </header>

        {/* Area de contenido */}
        <div className="content-area">
          {/* Banner de advertencia de licencia - SOLO en módulo de configuración */}
          {activeModule === 'settings' && !isLicenseBlocked && daysRemaining <= 10 && daysRemaining > 0 && (
            <div style={{
              background: daysRemaining <= 3 ? 'linear-gradient(135deg, #dc2626 0%, #991b1b 100%)' : 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)',
              color: 'white',
              padding: '15px 20px',
              borderRadius: '8px',
              marginBottom: '20px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              boxShadow: '0 4px 12px rgba(0,0,0,0.2)',
              animation: daysRemaining <= 3 ? 'pulse 2s infinite' : 'none'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                <div style={{ fontSize: '32px' }}>
                  {daysRemaining <= 3 ? '🚨' : '⚠️'}
                </div>
                <div>
                  <div style={{ fontSize: '16px', fontWeight: '700', marginBottom: '4px' }}>
                    {daysRemaining <= 3 ? '¡ATENCIÓN URGENTE!' : 'Advertencia de Licencia'}
                  </div>
                  <div style={{ fontSize: '14px', opacity: 0.95 }}>
                    {daysRemaining === 1 
                      ? 'Queda 1 día para que el sistema se bloquee. Active su licencia ahora.'
                      : `Quedan ${daysRemaining} días para que el sistema se bloquee. Active su licencia.`
                    }
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {activeModule === 'dashboard' && <Dashboard />}
          {activeModule === 'sales' && <Sales 
            onNavigateToProducts={() => setActiveModule('products')}
            onNavigateToClients={() => setActiveModule('clients')}
          />}
          {activeModule === 'quotes' && <Quotes 
            onNavigateToProducts={() => setActiveModule('products')}
            onNavigateToClients={() => setActiveModule('clients')}
          />}
          {activeModule === 'clients' && <Clients 
            onNavigateToSales={() => setActiveModule('sales')}
          />}
          {activeModule === 'products' && (
            <Products
              onNavigateToSales={() => setActiveModule('sales')}
            />
          )}
          {activeModule === 'reports' && <Reports />}
          {activeModule === 'archives' && <Archives />}
          {activeModule === 'settings' && <Settings />}
        </div>

        {/* Footer */}
        <footer className="app-footer">
          <div className="footer-left">
            <div className="footer-badge footer-badge-primary">
              <span className="footer-badge-icon">📅</span>
              <span className="footer-badge-text">{formattedTime}</span>
            </div>
            <div className="footer-badge footer-badge-secondary">
              <span className="footer-badge-icon">📂</span>
              <span className="footer-badge-text">Sesión #{sessionCount}</span>
            </div>
            <div className="footer-badge footer-badge-accent">
              <span className="footer-badge-icon">⏱️</span>
              <span className="footer-badge-text">{usageTime}</span>
            </div>
          </div>
          <div className="footer-right">
            <span className="footer-company">ING.NARVAEZ IRIARTE .M</span>
          </div>
        </footer>
      </main>

    </div>
  )
}
