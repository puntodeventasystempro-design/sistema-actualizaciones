# 📦 Cómo Publicar una Actualización

## 🎯 Cuando Tengas una Nueva Versión Lista

Sigue estos pasos para que tus usuarios reciban la notificación de actualización:

### Paso 1: Preparar la Nueva Versión

1. **Actualiza el código** con las nuevas características
2. **Prueba todo** para asegurarte que funciona
3. **Crea un archivo ZIP** con la nueva versión

### Paso 2: Subir el Archivo ZIP

Opciones para alojar tu archivo:

**Opción A: Google Drive** (Gratis y fácil)
1. Sube el archivo ZIP a Google Drive
2. Haz clic derecho → "Obtener enlace"
3. Cambia a "Cualquier persona con el enlace"
4. Copia el ID del archivo (la parte entre `/d/` y `/view`)
   - Ejemplo: `https://drive.google.com/file/d/1ABC123XYZ/view`
   - ID: `1ABC123XYZ`
5. La URL de descarga será: `https://drive.google.com/uc?export=download&id=1ABC123XYZ`

**Opción B: Tu Propio Servidor**
1. Sube el archivo a tu servidor web
2. Obtén la URL directa de descarga
   - Ejemplo: `https://tu-servidor.com/descargas/facturacion-v1.1.0.zip`

**Opción C: GitHub Releases** (Recomendado para proyectos públicos)
1. Ve a tu repositorio en GitHub
2. Crea un nuevo Release
3. Sube el archivo ZIP
4. Copia la URL del asset

### Paso 3: Actualizar el Archivo updates.json

Edita `public/updates.json` con la nueva información:

```json
{
  "version": "1.1.0",
  "latestVersion": "1.1.0",
  "releaseDate": "2026-03-15T12:00:00Z",
  "critical": false,
  "size": "16 MB",
  "downloadUrl": "https://drive.google.com/uc?export=download&id=TU_ID_AQUI",
  "features": [
    "Nueva característica 1",
    "Nueva característica 2",
    "Corrección de bug importante",
    "Mejoras de rendimiento"
  ],
  "changelog": [
    "Agregado módulo de inventario avanzado",
    "Mejorada la velocidad de carga en un 50%",
    "Corregido error en el cálculo de impuestos",
    "Nueva interfaz de reportes"
  ]
}
```

### Paso 4: Publicar

1. **Sube el archivo `updates.json` actualizado** a tu servidor
2. Los usuarios verán la notificación automáticamente en las próximas 6 horas
3. O pueden verificar manualmente desde Configuración → Actualizaciones

## 📋 Ejemplo Completo

### Escenario: Publicar versión 1.1.0

```json
{
  "version": "1.1.0",
  "latestVersion": "1.1.0",
  "releaseDate": "2026-03-15T12:00:00Z",
  "critical": false,
  "size": "16 MB",
  "downloadUrl": "https://drive.google.com/uc?export=download&id=1HNQtmruXm4N6xO88qzP1G3EYb6gAXGlS",
  "features": [
    "🎨 Nueva interfaz de usuario moderna",
    "📊 Reportes avanzados con gráficos",
    "🔒 Mejoras de seguridad",
    "⚡ Rendimiento optimizado",
    "🐛 Corrección de 15 bugs reportados"
  ],
  "changelog": [
    "Rediseño completo del módulo de ventas",
    "Agregado soporte para múltiples monedas",
    "Implementado sistema de backup automático",
    "Mejorada la impresión de facturas",
    "Agregado modo offline"
  ],
  "minVersion": "1.0.0",
  "platforms": {
    "windows": {
      "url": "https://drive.google.com/uc?export=download&id=WINDOWS_ID",
      "size": "16 MB"
    },
    "macos": {
      "url": "https://drive.google.com/uc?export=download&id=MACOS_ID",
      "size": "15 MB"
    },
    "linux": {
      "url": "https://drive.google.com/uc?export=download&id=LINUX_ID",
      "size": "14 MB"
    }
  }
}
```

## ⚠️ Importante

### Versionamiento Semántico

Usa el formato `MAJOR.MINOR.PATCH`:

- **MAJOR** (1.0.0 → 2.0.0): Cambios incompatibles
- **MINOR** (1.0.0 → 1.1.0): Nuevas características compatibles
- **PATCH** (1.0.0 → 1.0.1): Correcciones de bugs

### Actualización Crítica

Si es una actualización de seguridad urgente:

```json
{
  "version": "1.0.1",
  "critical": true,
  "features": [
    "🔴 ACTUALIZACIÓN DE SEGURIDAD CRÍTICA",
    "Corregida vulnerabilidad importante",
    "Se recomienda actualizar inmediatamente"
  ]
}
```

## 🔄 Flujo Completo

```
1. Desarrollas nueva versión (1.1.0)
   ↓
2. Creas archivo ZIP con la aplicación
   ↓
3. Subes el ZIP a Google Drive/Servidor
   ↓
4. Obtienes la URL de descarga
   ↓
5. Actualizas public/updates.json con:
   - Nueva versión (1.1.0)
   - URL de descarga
   - Lista de características
   ↓
6. Subes updates.json a tu servidor
   ↓
7. Los usuarios reciben notificación automática
   ↓
8. Usuarios descargan e instalan
```

## 🧪 Probar Antes de Publicar

Antes de publicar para todos:

1. Cambia temporalmente la versión a 1.1.0 en tu `updates.json` local
2. Prueba que la notificación aparece correctamente
3. Verifica que el botón de descarga funciona
4. Confirma que la información se muestra bien
5. Revierte a 1.0.0 si aún no estás listo para publicar

## 📍 Ubicación de los Archivos

- **Archivo de configuración**: `public/updates.json`
- **Servicio de actualizaciones**: `modules/common/services/updateService.ts`
- **Componente de notificación**: `modules/common/components/UpdateChecker.tsx`
- **Panel de configuración**: `modules/settings/components/UpdateSettings.tsx`

## 💡 Consejos

1. **Siempre prueba la descarga** antes de publicar
2. **Usa URLs permanentes** que no cambien
3. **Mantén un changelog** detallado
4. **Notifica a los usuarios** sobre cambios importantes
5. **Considera hacer backup** antes de actualizar

---

**Cuando estés listo para publicar una actualización real, simplemente edita `public/updates.json` con la nueva versión y URL de descarga.**
