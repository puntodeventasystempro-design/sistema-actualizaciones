import { useState, useEffect } from 'react'
import { updateService } from '../services/updateService'
import AutoUpdateInstaller from './AutoUpdateInstaller'
import './UpdateChecker.css'

interface UpdateInfo {
  available: boolean
  version: string
  currentVersion: string
  releaseDate: string
  features: string[]
  downloadUrl?: string
}

export default function UpdateChecker() {
  const [updateInfo, setUpdateInfo] = useState<UpdateInfo | null>(null)
  const [showNotification, setShowNotification] = useState(false)
  const [showInstaller, setShowInstaller] = useState(false)
  
  // Forzar recarga - versión actualizada

  // Verificar actualizaciones al cargar
  useEffect(() => {
    checkForUpdates()
    
    // Verificar cada 6 horas
    const interval = setInterval(() => {
      checkForUpdates()
    }, 6 * 60 * 60 * 1000)
    
    // Escuchar evento personalizado de actualización disponible
    const handleUpdateEvent = (event: CustomEvent) => {
      console.log('[UpdateChecker] Evento de actualización recibido:', event.detail)
      setUpdateInfo(event.detail)
      setShowNotification(true)
    }
    
    window.addEventListener('update-available', handleUpdateEvent as EventListener)
    
    return () => {
      clearInterval(interval)
      window.removeEventListener('update-available', handleUpdateEvent as EventListener)
    }
  }, [])

  const checkForUpdates = async () => {
    try {
      console.log('[UpdateChecker] Verificando actualizaciones...')
      const response = await updateService.checkForUpdates()
      console.log('[UpdateChecker] Respuesta:', response)
      
      if (response.available) {
        setUpdateInfo(response)
        setShowNotification(true)
        
        // Guardar en localStorage que hay actualización disponible
        localStorage.setItem('pos_update_available', JSON.stringify(response))
      } else {
        setUpdateInfo(null)
        localStorage.removeItem('pos_update_available')
      }
    } catch (error) {
      console.error('[UpdateChecker] Error al verificar actualizaciones:', error)
    }
  }

  const handleDownloadUpdate = async () => {
    // Mostrar el instalador automático
    setShowInstaller(true)
  }

  if (showInstaller && updateInfo) {
    return (
      <AutoUpdateInstaller
        downloadUrl={updateInfo.downloadUrl || ''}
        version={updateInfo.version}
        onClose={() => setShowInstaller(false)}
      />
    )
  }

  const dismissNotification = () => {
    setShowNotification(false)
    // Recordar que el usuario cerró la notificación
    localStorage.setItem('pos_update_dismissed', new Date().toISOString())
  }

  if (!showNotification || !updateInfo?.available) {
    return null
  }

  return (
    <div className="update-notification">
      <div className="update-content">
        <div className="update-header">
          <div className="update-icon">🔔</div>
          <div className="update-title">
            <h3>Nueva Actualización Disponible</h3>
            <p>Versión {updateInfo.version}</p>
          </div>
          <button 
            className="update-close"
            onClick={dismissNotification}
            aria-label="Cerrar notificación"
          >
            ✕
          </button>
        </div>
        
        <div className="update-body">
          <div className="update-version-info">
            <span className="version-badge current">
              Actual: v{updateInfo.currentVersion}
            </span>
            <span className="version-arrow">→</span>
            <span className="version-badge new">
              Nueva: v{updateInfo.version}
            </span>
          </div>
          
          <div className="update-features">
            <h4>Novedades:</h4>
            <ul>
              {updateInfo.features.map((feature, index) => (
                <li key={index}>{feature}</li>
              ))}
            </ul>
          </div>
          
          <div className="update-actions">
            <button 
              className="btn-update-now"
              onClick={handleDownloadUpdate}
            >
              Descargar Actualización
            </button>
            <button 
              className="btn-update-later"
              onClick={dismissNotification}
            >
              Recordar más tarde
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
