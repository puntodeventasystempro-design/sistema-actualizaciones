// Servicio para gestionar actualizaciones del sistema

export interface UpdateInfo {
  available: boolean
  version: string
  currentVersion: string
  releaseDate: string
  features: string[]
  downloadUrl?: string
  critical?: boolean // Si es una actualización crítica
  size?: string // Tamaño del archivo
}

export interface UpdateConfig {
  serverUrl: string // URL de tu servidor de actualizaciones
  checkInterval: number // Intervalo en milisegundos
  autoCheck: boolean // Verificar automáticamente
}

class UpdateService {
  private config: UpdateConfig
  private currentVersion: string
  
  constructor() {
    // Configuración por defecto
    this.config = {
      serverUrl: 'https://tu-servidor.com/api/updates',
      checkInterval: 6 * 60 * 60 * 1000, // 6 horas
      autoCheck: true
    }
    
    // Obtener versión del package.json
    this.currentVersion = '1.0.0'
  }
  
  // Configurar el servicio
  configure(config: Partial<UpdateConfig>) {
    this.config = { ...this.config, ...config }
  }
  
  // Verificar si hay actualizaciones disponibles
  async checkForUpdates(): Promise<UpdateInfo> {
    console.log('[UpdateService] Iniciando verificación de actualizaciones...')
    console.log('[UpdateService] Versión actual:', this.currentVersion)
    
    try {
      // Usar directamente el archivo JSON de Google Drive
      const response = await this.checkFromJSON()
      console.log('[UpdateService] Respuesta:', response)
      return response
      
    } catch (error) {
      console.error('[UpdateService] Error al verificar actualizaciones:', error)
      return this.getNoUpdateInfo()
    }
  }
  
  // Verificar desde servidor API
  private async checkFromServer(): Promise<UpdateInfo> {
    try {
      const response = await fetch(`${this.config.serverUrl}/check`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          currentVersion: this.currentVersion,
          platform: this.getPlatform(),
          deviceId: this.getDeviceId()
        })
      })
      
      if (!response.ok) {
        throw new Error('Error en la respuesta del servidor')
      }
      
      const data = await response.json()
      return this.parseUpdateInfo(data)
      
    } catch (error) {
      console.error('Error al consultar servidor:', error)
      // Si falla, intentar con archivo JSON estático
      return this.checkFromJSON()
    }
  }
  
  // Verificar desde archivo JSON estático
  private async checkFromJSON(): Promise<UpdateInfo> {
    try {
      // Intentar múltiples métodos para obtener el archivo
      
      // Método 1: Archivo local en public/
      try {
        console.log('[UpdateService] Intentando archivo local: /updates.json')
        const localResponse = await fetch('/updates.json?' + Date.now(), {
          cache: 'no-cache',
          headers: {
            'Cache-Control': 'no-cache, no-store, must-revalidate',
            'Pragma': 'no-cache'
          }
        })
        
        if (localResponse.ok) {
          const data = await localResponse.json()
          console.log('[UpdateService] ✅ Datos obtenidos del archivo local:', data)
          return this.parseUpdateInfo(data)
        }
      } catch (localError) {
        console.log('[UpdateService] ⚠️ Archivo local no disponible:', localError)
      }
      
      // Método 2: Google Drive con URL directa
      try {
        const driveId = '1HNQtmruXm4N6xO88qzP1G3EYb6gAXGlS'
        const driveUrl = `https://drive.google.com/uc?export=download&id=${driveId}&timestamp=${Date.now()}`
        
        console.log('[UpdateService] Intentando Google Drive:', driveUrl)
        
        const driveResponse = await fetch(driveUrl, {
          method: 'GET',
          cache: 'no-cache',
          headers: {
            'Cache-Control': 'no-cache'
          }
        })
        
        if (driveResponse.ok) {
          const text = await driveResponse.text()
          console.log('[UpdateService] Respuesta de Google Drive (primeros 200 chars):', text.substring(0, 200))
          
          // Intentar parsear como JSON
          try {
            const data = JSON.parse(text)
            console.log('[UpdateService] ✅ Datos obtenidos de Google Drive:', data)
            return this.parseUpdateInfo(data)
          } catch (parseError) {
            console.error('[UpdateService] ❌ Error al parsear JSON de Google Drive:', parseError)
            console.log('[UpdateService] Contenido recibido:', text)
          }
        } else {
          console.log('[UpdateService] ⚠️ Google Drive respondió con status:', driveResponse.status)
        }
      } catch (driveError) {
        console.log('[UpdateService] ⚠️ Error al consultar Google Drive:', driveError)
      }
      
      // Método 3: URL alternativa de Google Drive
      try {
        const driveId = '1HNQtmruXm4N6xO88qzP1G3EYb6gAXGlS'
        const altUrl = `https://www.googleapis.com/drive/v3/files/${driveId}?alt=media&key=AIzaSyDummy`
        
        console.log('[UpdateService] Intentando URL alternativa de Google Drive')
        
        const altResponse = await fetch(altUrl, {
          cache: 'no-cache'
        })
        
        if (altResponse.ok) {
          const data = await altResponse.json()
          console.log('[UpdateService] ✅ Datos obtenidos de URL alternativa:', data)
          return this.parseUpdateInfo(data)
        }
      } catch (altError) {
        console.log('[UpdateService] ⚠️ URL alternativa no disponible:', altError)
      }
      
      console.log('[UpdateService] ❌ Todos los métodos fallaron')
      return this.getNoUpdateInfo()
      
    } catch (error) {
      console.error('[UpdateService] ❌ Error general al verificar actualizaciones:', error)
      return this.getNoUpdateInfo()
    }
  }
  
  // Parsear información de actualización
  private parseUpdateInfo(data: any): UpdateInfo {
    const latestVersion = data.version || data.latestVersion
    const available = this.isNewerVersion(latestVersion, this.currentVersion)
    
    return {
      available,
      version: latestVersion,
      currentVersion: this.currentVersion,
      releaseDate: data.releaseDate || new Date().toISOString(),
      features: data.features || data.changelog || [],
      downloadUrl: data.downloadUrl || data.url,
      critical: data.critical || false,
      size: data.size || 'Desconocido'
    }
  }
  
  // Comparar versiones (formato: X.Y.Z)
  private isNewerVersion(newVersion: string, currentVersion: string): boolean {
    console.log('[UpdateService] Comparando versiones:')
    console.log('  Nueva:', newVersion)
    console.log('  Actual:', currentVersion)
    
    const newParts = newVersion.split('.').map(Number)
    const currentParts = currentVersion.split('.').map(Number)
    
    console.log('  Partes nueva:', newParts)
    console.log('  Partes actual:', currentParts)
    
    for (let i = 0; i < 3; i++) {
      const newPart = newParts[i] || 0
      const currentPart = currentParts[i] || 0
      
      console.log(`  Comparando posición ${i}: ${newPart} vs ${currentPart}`)
      
      if (newPart > currentPart) {
        console.log('  ✅ Nueva versión es mayor')
        return true
      }
      if (newPart < currentPart) {
        console.log('  ❌ Nueva versión es menor')
        return false
      }
    }
    
    console.log('  ⚠️ Versiones son iguales')
    return false
  }
  
  // Obtener información cuando no hay actualización
  private getNoUpdateInfo(): UpdateInfo {
    return {
      available: false,
      version: this.currentVersion,
      currentVersion: this.currentVersion,
      releaseDate: new Date().toISOString(),
      features: []
    }
  }
  
  // Obtener plataforma
  private getPlatform(): string {
    const userAgent = navigator.userAgent.toLowerCase()
    
    if (userAgent.includes('win')) return 'windows'
    if (userAgent.includes('mac')) return 'macos'
    if (userAgent.includes('linux')) return 'linux'
    
    return 'unknown'
  }
  
  // Obtener o crear ID de dispositivo
  private getDeviceId(): string {
    let deviceId = localStorage.getItem('pos_device_id')
    
    if (!deviceId) {
      deviceId = 'DEV-' + Math.random().toString(36).substring(2, 15)
      localStorage.setItem('pos_device_id', deviceId)
    }
    
    return deviceId
  }
  
  // Descargar actualización
  async downloadUpdate(url: string): Promise<void> {
    try {
      // Abrir en nueva pestaña
      window.open(url, '_blank')
      
      // Registrar descarga
      this.logUpdateDownload()
      
    } catch (error) {
      console.error('Error al descargar actualización:', error)
      throw error
    }
  }
  
  // Registrar descarga de actualización
  private logUpdateDownload() {
    const downloads = JSON.parse(localStorage.getItem('pos_update_downloads') || '[]')
    downloads.push({
      date: new Date().toISOString(),
      version: this.currentVersion
    })
    localStorage.setItem('pos_update_downloads', JSON.stringify(downloads))
  }
  
  // Obtener historial de verificaciones
  getCheckHistory(): any[] {
    return JSON.parse(localStorage.getItem('pos_update_checks') || '[]')
  }
  
  // Guardar verificación en historial
  saveCheckHistory(updateInfo: UpdateInfo) {
    const history = this.getCheckHistory()
    history.push({
      date: new Date().toISOString(),
      available: updateInfo.available,
      version: updateInfo.version
    })
    
    // Mantener solo últimas 50 verificaciones
    if (history.length > 50) {
      history.shift()
    }
    
    localStorage.setItem('pos_update_checks', JSON.stringify(history))
  }
}

// Exportar instancia única
export const updateService = new UpdateService()
