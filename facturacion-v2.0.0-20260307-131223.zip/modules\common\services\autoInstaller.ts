// Servicio de instalación automática de actualizaciones

export interface InstallProgress {
  step: 'downloading' | 'extracting' | 'installing' | 'complete' | 'error'
  progress: number // 0-100
  message: string
}

class AutoInstaller {
  private onProgress?: (progress: InstallProgress) => void
  
  // Configurar callback de progreso
  setProgressCallback(callback: (progress: InstallProgress) => void) {
    this.onProgress = callback
  }
  
  // Descargar e instalar actualización automáticamente
  async downloadAndInstall(downloadUrl: string, version: string): Promise<boolean> {
    try {
      // Paso 1: Descargar
      this.reportProgress('downloading', 0, 'Descargando actualización...')
      
      const blob = await this.downloadFile(downloadUrl, (progress) => {
        this.reportProgress('downloading', progress, `Descargando... ${progress}%`)
      })
      
      if (!blob) {
        throw new Error('Error al descargar el archivo')
      }
      
      // Paso 2: Guardar localmente
      this.reportProgress('downloading', 100, 'Descarga completada')
      
      // Paso 3: Preparar instalación
      this.reportProgress('extracting', 0, 'Preparando instalación...')
      
      // Crear enlace de descarga
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = `facturacion-v${version}.zip`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      window.URL.revokeObjectURL(url)
      
      // Paso 4: Mostrar instrucciones
      this.reportProgress('installing', 50, 'Archivo descargado')
      
      // Guardar que hay una actualización pendiente
      localStorage.setItem('pos_pending_update', JSON.stringify({
        version,
        downloadedAt: new Date().toISOString()
      }))
      
      this.reportProgress('complete', 100, '¡Actualización lista para instalar!')
      
      return true
      
    } catch (error) {
      console.error('Error en instalación automática:', error)
      this.reportProgress('error', 0, 'Error al descargar la actualización')
      return false
    }
  }
  
  // Descargar archivo con progreso
  private async downloadFile(
    url: string, 
    onProgress: (progress: number) => void
  ): Promise<Blob | null> {
    try {
      const response = await fetch(url)
      
      if (!response.ok) {
        throw new Error('Error en la descarga')
      }
      
      const contentLength = response.headers.get('content-length')
      const total = contentLength ? parseInt(contentLength, 10) : 0
      
      if (!response.body) {
        throw new Error('No se pudo acceder al contenido')
      }
      
      const reader = response.body.getReader()
      const chunks: Uint8Array[] = []
      let receivedLength = 0
      
      while (true) {
        const { done, value } = await reader.read()
        
        if (done) break
        
        chunks.push(value)
        receivedLength += value.length
        
        if (total > 0) {
          const progress = Math.round((receivedLength / total) * 100)
          onProgress(progress)
        }
      }
      
      // Combinar chunks en un solo Blob
      const blob = new Blob(chunks)
      return blob
      
    } catch (error) {
      console.error('Error al descargar archivo:', error)
      return null
    }
  }
  
  // Reportar progreso
  private reportProgress(
    step: InstallProgress['step'], 
    progress: number, 
    message: string
  ) {
    if (this.onProgress) {
      this.onProgress({ step, progress, message })
    }
  }
  
  // Verificar si hay actualización pendiente
  hasPendingUpdate(): boolean {
    return localStorage.getItem('pos_pending_update') !== null
  }
  
  // Obtener información de actualización pendiente
  getPendingUpdate(): { version: string; downloadedAt: string } | null {
    const data = localStorage.getItem('pos_pending_update')
    return data ? JSON.parse(data) : null
  }
  
  // Marcar actualización como instalada
  markAsInstalled() {
    localStorage.removeItem('pos_pending_update')
  }
  
  // Instalar actualización (requiere permisos del sistema)
  async installUpdate(): Promise<boolean> {
    try {
      // Esta función requeriría acceso al sistema de archivos
      // En un navegador web, el usuario debe instalar manualmente
      
      // Para Electron o aplicación de escritorio:
      const w = window as any
      if (w.electronAPI && w.electronAPI.installUpdate) {
        return await w.electronAPI.installUpdate()
      }
      
      // Para navegador: mostrar instrucciones
      this.showInstallInstructions()
      return true
      
    } catch (error) {
      console.error('Error al instalar:', error)
      return false
    }
  }
  
  // Mostrar instrucciones de instalación
  private showInstallInstructions() {
    const instructions = `
📦 INSTALACIÓN DE ACTUALIZACIÓN

PASOS:
1. ✅ El archivo se descargó en tu carpeta "Descargas"
2. 🔒 Cierra este programa completamente
3. 📂 Busca el archivo ZIP descargado
4. 📦 Extrae el contenido del ZIP
5. 📋 Copia todos los archivos extraídos
6. 📁 Ve a la carpeta donde está instalado el programa
7. 📝 Pega los archivos (reemplazar cuando pregunte)
8. 🚀 Abre el programa de nuevo

¡La actualización estará instalada!

💡 TIP: Si no sabes dónde está instalado el programa,
busca el acceso directo y haz clic derecho → "Abrir ubicación"
    `.trim()
    
    alert(instructions)
  }
}

// Exportar instancia única
export const autoInstaller = new AutoInstaller()
