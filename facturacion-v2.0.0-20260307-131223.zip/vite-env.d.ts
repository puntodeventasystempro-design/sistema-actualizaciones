/// <reference types="vite/client" />

// Declare modules for CSS imports
declare module '*.css' {
  const content: { [key: string]: string }
  export default content
}

// Declare modules for other asset imports
declare module '*.svg' {
  const content: string
  export default content
}

declare module '*.png' {
  const content: string
  export default content
}

declare module '*.jpg' {
  const content: string
  export default content
}

// Electron API types
interface ElectronAPI {
  saveInvoiceToFolder: (filename: string, htmlContent: string) => Promise<{ success: boolean; path?: string; error?: string }>
  printInvoice: (htmlContent: string) => Promise<{ success: boolean; error?: string }>
  printAndSaveInvoice: (filename: string, htmlContent: string) => Promise<{ success: boolean; path?: string; error?: string }>
  getInvoicesFolder: () => Promise<string>
}

interface Window {
  electronAPI?: ElectronAPI;
}
